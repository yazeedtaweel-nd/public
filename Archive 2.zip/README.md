# DWH table comparison

A small SQL Server framework that compares one table in a source database with the same table in a target database. It reports missing keys, value differences, exact matches, duplicate business keys, and row counts.

It does not move data. There is no ETL, sync, or scheduling.

`SourceValue` is the value from `@SourceDatabase` (DWH in the examples). `TargetValue` is the value from `@TargetDatabase` (DWH2). The names stay stable when the database names change.

## Requirements

- SQL Server 2016 SP1 or later
- A utility database to hold the procedures (they do not need to live in DWH or DWH2)
- `SELECT` on both tables for the login that runs the comparison
- A user mapping in both databases. Cross-database ownership chaining is not required.
- For another instance: a SQL Server linked server with data access, Windows Authentication (`useself`), and a Windows login that can `SELECT` the remote table. SQL Server Authentication is not supported.
- For the batch workbook: Python 3.9 or later, `pip install -r requirements.txt`, and a Microsoft SQL Server ODBC driver on the machine that runs the script.

## Deploy

Create a utility database, then run [`sql/install.sql`](sql/install.sql) in it.

```sql
IF DB_ID(N'DwhCompare') IS NULL
    CREATE DATABASE DwhCompare;
GO
USE DwhCompare;
GO
```

```bash
sqlcmd -S YourServer -d DwhCompare -i sql/install.sql
```

In SSMS, open `sql/install.sql` and execute it against `DwhCompare`.

Optional:

```sql
GRANT EXECUTE ON dbo.CompareTables TO YourReader;
GRANT EXECUTE ON dbo.FindDuplicates TO YourReader;
GRANT EXECUTE ON dbo.CompareTableCounts TO YourReader;
```

## Calls

```sql
EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID';

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'POLICY_LIMIT',
    @KeyColumns = N'POLICY_BK,LIMIT_BK';

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @ExcludedColumns = N'CREATED_DATE,UPDATED_DATE';

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @Output = N'DIFF';

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @IgnoreCase = 1;

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @TargetServer = N'DWH2_LINK';
```

The same calls are in [`sql/examples.sql`](sql/examples.sql). They run only when `DWH` and `DWH2` exist on the instance. The last call also needs a linked server named `DWH2_LINK`.

Optional arguments:

| Argument | Default | Purpose |
| --- | --- | --- |
| `@ExcludedColumns` | none | Comma-separated columns to skip. Keys cannot be excluded. |
| `@IncludeMatches` | `1` | `0` omits `MATCH` rows from the detail. The summary still counts them. Ignored when `@Output` is `DIFF`. |
| `@Output` | `ALL` | `ALL`, `DETAIL`, `DIFF`, `DUPLICATES`, or `SUMMARY`. Use a single section when inserting the result into a table. |
| `@Debug` | `0` | Prints the generated batch. |
| `@IgnoreCase` | `0` | `1` compares `char`, `varchar`, `nchar`, `nvarchar`, `text`, and `ntext` without case. This includes string keys. Trailing spaces still differ. Numbers, dates, and binary values stay exact. |
| `@SourceServer` | local | SQL Server linked server name from `sys.servers`. Omit or pass the local server name for this instance. |
| `@TargetServer` | local | Same as `@SourceServer` for the target table. |

## Batch from CSV or Excel

[`python/compare_from_csv.py`](python/compare_from_csv.py) reads a list of tables and writes one workbook: `_Summary`, `_Duplicates` when any exist, and one sheet per table with the comparison detail.

The control file needs these columns (aliases such as `Table` / `Keys` / `Excluded` also work):

| Column | Required | Purpose |
| --- | --- | --- |
| `TableName` | yes | `@TableName` |
| `KeyColumns` | yes | `@KeyColumns`, comma-separated for a composite key |
| `ExcludedColumns` | no | `@ExcludedColumns` |
| `SchemaName` | no | Overrides the default schema for that row |
| `Output` | no | Overrides the default `@Output` for that row |
| `IncludeMatches` | no | `1` / `0` for that row |
| `IgnoreCase` | no | `1` / `0` for that row. Overrides `--ignore-case`. |

```csv
TableName,KeyColumns,ExcludedColumns
DIM_COUNTRY,CTRY_COUNTRY_CODE,"CTRY_SRGT,CREATED_DATE_SRGT,UPDATED_DATE_SRGT,CTRY_SRE_REGION_NAME"
DIM_USER,USER_BK,"USER_SRGT,CREATED_DATE_SRGT,UPDATED_DATE_SRGT"
```

A starter file is [`python/tables.example.csv`](python/tables.example.csv). An `.xlsx` file works the same way: put those headers on the first sheet.

```bash
pip install -r requirements.txt

python python/compare_from_csv.py \
    --tables python/tables.example.csv \
    --server YourServer \
    --database DwhCompare \
    --source-database SaudiRe_DWW \
    --target-database SaudiRe_DWW \
    --target-server HO_DWW_UAT
```

That call matches the usual single-table `EXEC`: same source and target database, a linked target server, and one scan per table. Default `@Output` is `ALL` with `MATCH` rows omitted, so each table sheet gets differences only, `_Duplicates` gets duplicate keys, and `_Summary` gets the counts.

Useful switches:

| Switch | Purpose |
| --- | --- |
| `--workbook path.xlsx` | Output path. Default is `compare-results-YYYYmmdd-HHMMSS.xlsx` in the current directory. |
| `--output DIFF` | Detail sheets only. `_Summary` then has row counts only when the procedure returns them. |
| `--include-matches` | Keep `MATCH` rows on the table sheets. |
| `--ignore-case` | Compare string keys and string values without case. A row's `IgnoreCase` column overrides this. |
| `--schema dbo` | Default schema when the control file omits `SchemaName`. |
| `--source-server` | `@SourceServer` when the source table is remote. |
| `--dry-run` | Print the resolved table list and do not connect. |

The script uses Windows / trusted authentication by default, which is required for a linked-server compare. A table that fails validation is written as `FAILED` on `_Summary` and the rest of the list still runs. If a table has more than 1,048,575 detail rows, the sheet is truncated and the full result is written next to the workbook as CSV.

`FindDuplicates` takes `@ServerName` with the same meaning.

Cross-server compare accepts only a Microsoft SQL Server linked server and only Windows Authentication. Create the linked server, enable data access, and pass through the current Windows login:

```sql
EXEC sp_addlinkedserver
    @server = N'DWH2_LINK',
    @srvproduct = N'',
    @provider = N'MSOLEDBSQL',
    @datasrc = N'TargetHost';

EXEC sp_addlinkedsrvlogin
    @rmtsrvname = N'DWH2_LINK',
    @useself = N'true';

EXEC sp_serveroption
    @server = N'DWH2_LINK',
    @optname = N'data access',
    @optvalue = N'true';
```

`@useself = 'true'` is required. Stored remote SQL logins (`@rmtuser` / `@rmtpassword`) are rejected. The session that runs `CompareTables` must itself be a Windows login.

`ALL` returns three result sets, in this order:

1. Comparison detail
2. Duplicate keys
3. Summary

`DIFF` returns only the comparison detail, and only the non-match rows: `ONLY_IN_SOURCE`, `ONLY_IN_TARGET`, and `VALUE_MISMATCH`. It is the insertable form of “ALL without MATCH”. Use `ALL` with `@IncludeMatches = 0` if you still want the duplicate and summary result sets.

Fast helpers, when you do not need a column diff:

```sql
EXEC dbo.CompareTableCounts
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER';

EXEC dbo.FindDuplicates
    @DatabaseName = N'DWH',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID';
```

`CompareTableCounts` is only `COUNT(*)` on each table. Matching-row and mismatch counts come from `CompareTables`, because they require the key join.

## Result shape

Comparison detail:

| Table | Key | Status | Column | SourceValue | TargetValue |
| --- | --- | --- | --- | --- | --- |
| CUSTOMER | 1001 | MATCH | | | |
| CUSTOMER | 1002 | ONLY_IN_SOURCE | | | |
| CUSTOMER | 1003 | ONLY_IN_TARGET | | | |
| CUSTOMER | 1004 | VALUE_MISMATCH | FEE | 1.2500 | 9.0000 |
| CUSTOMER | 1004 | VALUE_MISMATCH | NAME | Ahmed | Ahmad |
| CUSTOMER | 1004 | VALUE_MISMATCH | STATUS | ACTIVE | INACTIVE |
| CUSTOMER | 1006 | VALUE_MISMATCH | NAME | | Hana |
| CUSTOMER | 1010 | VALUE_MISMATCH | NAME | Ann | Ann |

`1010` differs by a trailing space on the target (`Ann` versus `Ann `). Blank `SourceValue` on key `1006` is NULL, not an empty string. Mismatch columns are listed in name order. Composite keys are shown as `P1 | L1`. A NULL key part is shown as `<NULL>`.

Duplicate keys:

| Table | Key | Status | RecordCount |
| --- | --- | --- | --- |
| CUSTOMER | 1007 | DUPLICATE_SOURCE | 2 |
| CUSTOMER | 1009 | DUPLICATE_TARGET | 2 |

Summary:

| Table | SourceRowCount | TargetRowCount | CountDifference | MatchingRows | OnlyInSource | OnlyInTarget | ValueMismatch | DuplicateSourceKeys | DuplicateTargetKeys |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CUSTOMER | 9 | 9 | 0 | 3 | 1 | 1 | 3 | 1 | 1 |

`ValueMismatch` counts distinct keys, not differing columns. Key `1004` is one mismatched key and three detail rows.

Duplicate keys are removed before the join, so they appear only in the duplicate result. A duplicated key is not also counted as `ONLY_IN_SOURCE` or `VALUE_MISMATCH`. For the rows that remain:

```text
MatchingRows + OnlyInSource + ValueMismatch = distinct source keys that occur once
MatchingRows + OnlyInTarget + ValueMismatch = distinct target keys that occur once
```

`SourceRowCount` and `TargetRowCount` include every physical row, duplicates included.

Messages (not result sets) name the columns being compared, the columns that exist on only one side, and any excluded columns.

## How the dynamic SQL works

`CompareTables` does not trust the text you pass as an identifier.

1. Database, schema, and table names are looked up in `sys.databases`, `sys.schemas`, and `sys.tables`. When `@SourceServer` or `@TargetServer` is set, the name must exist in `sys.servers`, must be a SQL Server linked server, and must use Windows Authentication (`useself`). The local server is treated as local (three-part names). A linked server is queried with four-part names. The lookup parameters are passed to `sp_executesql`. The name that is concatenated later is the name returned by the catalog, wrapped in `QUOTENAME`.
2. Key and excluded names are split, then matched to `sys.columns`. Only a column that exists is quoted into the batch. A missing name, a repeated name, or an incompatible type raises a clear error before the comparison batch runs.
3. The procedure reads `sys.columns` and `sys.types` from both databases and keeps the columns that exist on both sides, minus keys and `@ExcludedColumns`.
4. It builds one batch that:
   - scans each table once and writes a narrow temp table of business keys plus two SHA-256 hashes
   - aggregates duplicate keys from that temp table
   - full-outer-joins the remaining keys
   - for `VALUE_MISMATCH` only, joins back to the base tables and unpivots each column
5. `@Output`, `@IncludeMatches`, and the result table name are parameters of `sp_executesql`. They are not pasted into the SQL text.

`@Debug = 1` prints that batch. Validation errors are `THROW 50001` with a message such as `Key column 'CUSTOMER_ID' does not exist in the target table.` or `Column 'QTY' is not compatible. Source type: varchar(20). Target type: int.`

## Performance

Large tables are not compared cell by cell.

**Stage 1.** Each row is reduced to its business key and a SHA-256 of the other columns. NULL becomes 33 zero bytes. Any other value becomes `0x01` plus the SHA-256 of a canonical representation (so NULL and `''` do not collide, and a delimiter inside a string cannot shift the next column). Those fingerprints are concatenated as `varbinary(max)` and hashed again. `CHECKSUM` is not used. If the two row hashes are equal, the key is `MATCH` and the column values are not read again.

**Stage 2.** Only keys whose hashes differ are joined back to the source and target tables. Each compared column is tested with a `NULL`-safe expression, and one result row is returned per different column.

Duplicate detection groups the stage-1 key set. It does not scan the base tables a second time.

The stage-1 tables live in `tempdb`: about one row per source row and one per target row, each holding the key plus 64 bytes of hash. An index on the business key of the real table helps the stage-2 lookup when many keys differ.

The read runs under the session's isolation level, normally read committed. It is not one snapshot across two databases. If the tables are being loaded during the run, run it when both sides are quiet, or enable snapshot isolation on the session first if both databases allow it.

## Comparison rules

- NULL equals NULL. NULL does not equal a value.
- Strings are exact, including case and trailing spaces, unless `@IgnoreCase = 1`. `Ahmed` and `AHMED` differ by default and match when case is ignored. `Ann` and `Ann ` differ either way. `varchar` and `nvarchar` of the same text still match. With `@IgnoreCase = 1`, string keys that differ only by case are the same key, and two such keys on one side are duplicates.
- `tinyint`, `smallint`, `int`, and `bigint` can be compared with each other. `decimal` and `numeric` can be compared across precision and scale (`10.50` matches `10.5000`, `101.00` does not match `110.0000`). `money` and `smallmoney` can be compared with each other.
- `char` / `varchar` / `nchar` / `nvarchar` / `text` / `ntext` can be compared with each other.
- Other types must be the same type. `datetime2`, `time`, and `datetimeoffset` must also use the same scale. `binary` and `varbinary` must be the same length. `datetime` is not treated as `datetime2`.
- `geography`, `geometry`, `hierarchyid`, and `sql_variant` are rejected unless excluded.
- Columns that exist on only one side are skipped and named in a message.
- Views are not compared. The object must be a table.
- A SHA-256 collision could theoretically hide a difference. That is not a practical risk, and a hash match is the equality test for the row. Column output is produced only when the hashes differ.

## Test

[`sql/test.sql`](sql/test.sql) creates `DwhCompare_Src` and `DwhCompare_Tgt` and checks:

- matching rows, including NULL equals NULL
- source-only and target-only keys
- column-level mismatches, including NULL versus a value and a trailing space
- case-insensitive string keys and values when `@IgnoreCase = 1`, while trailing spaces still differ
- excluded audit columns
- duplicate keys on either side
- composite keys, including a NULL key part
- decimal scale differences, including values that must stay distinct (`101` versus `110`)
- `int` versus `bigint` keys
- incompatible types, missing objects, identifier injection, an unknown linked server, a non-SQL linked server, and a SQL Authentication mapping

Run it from the utility database after install:

```bash
sqlcmd -S YourServer -d DwhCompare -b -i sql/test.sql
```

It throws if a result is wrong and prints `All comparison framework tests passed.` when it is not. [`sql/teardown.sql`](sql/teardown.sql) drops the two test databases.

The CSV reader and workbook layout have tests that do not need SQL Server:

```bash
python -m unittest discover -s python
```

These tests were run against SQL Server 2022.
