import tempfile
import unittest
from pathlib import Path

from compare_from_csv import (
    TableJob,
    TableResult,
    classify_result_set,
    excel_sheet_name,
    group_jobs,
    grouped_workbook_path,
    map_row,
    read_table_list,
    resolve_workbook_base,
    write_result_workbooks,
    write_workbook,
)


class ReadTableListTests(unittest.TestCase):
    def test_reads_csv_aliases_and_skips_comments(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Table,Keys,Excluded\n"
                "# ignored,x,y\n"
                "DIM_COUNTRY,CTRY_COUNTRY_CODE,\"CTRY_SRGT,CREATED_DATE_SRGT\"\n"
                "\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].table_name, "DIM_COUNTRY")
        self.assertEqual(jobs[0].key_columns, "CTRY_COUNTRY_CODE")
        self.assertEqual(jobs[0].excluded_columns, "CTRY_SRGT,CREATED_DATE_SRGT")
        self.assertIsNone(jobs[0].ignore_case)

    def test_reads_group_and_package_aliases(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Group,TableName,KeyColumns\n"
                "Party,DIM_PARTY,PARTY_BK\n"
                "Policy,DIM_POLICY,POLICY_BK\n"
                ",DIM_COUNTRY,CTRY_COUNTRY_CODE\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].group_name, "Party")
        self.assertEqual(jobs[1].group_name, "Policy")
        self.assertEqual(jobs[2].group_name, "Policy")

    def test_fills_blank_group_and_collects_scattered_package_rows(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Title row to ignore\n"
                "Group,TableName,KeyColumns\n"
                "Party,DIM_PARTY,PARTY_BK\n"
                ",DIM_PARTY_ROLE,ROLE_BK\n"
                "Policy,DIM_POLICY,POLICY_BK\n"
                "Party,DIM_CONTACT,CONTACT_BK\n"
                ",DIM_ADDRESS,ADDR_BK\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(
            [job.table_name for job in jobs],
            ["DIM_PARTY", "DIM_PARTY_ROLE", "DIM_POLICY", "DIM_CONTACT", "DIM_ADDRESS"],
        )
        self.assertEqual(jobs[0].group_name, "Party")
        self.assertEqual(jobs[1].group_name, "Party")
        self.assertEqual(jobs[2].group_name, "Policy")
        self.assertEqual(jobs[3].group_name, "Party")
        self.assertEqual(jobs[4].group_name, "Party")

        groups = group_jobs(jobs)
        self.assertEqual([name for name, _ in groups], ["Party", "Policy"])
        self.assertEqual(
            [job.table_name for job in groups[0][1]],
            ["DIM_PARTY", "DIM_PARTY_ROLE", "DIM_CONTACT", "DIM_ADDRESS"],
        )

    def test_unnamed_first_column_is_group(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                ",TableName,KeyColumns\n"
                "Party,DIM_PARTY,PARTY_BK\n"
                ",DIM_PARTY_ROLE,ROLE_BK\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].group_name, "Party")
        self.assertEqual(jobs[1].group_name, "Party")

    def test_reads_excel_groups_from_all_sheets(self) -> None:
        from openpyxl import Workbook

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.xlsx"
            workbook = Workbook()
            party = workbook.active
            party.title = "Party"
            party.append(["TableName", "KeyColumns"])
            party.append(["DIM_PARTY", "PARTY_BK"])
            party.append(["DIM_PARTY_ROLE", "ROLE_BK"])
            policy = workbook.create_sheet("Policy")
            policy.append(["TableName", "KeyColumns"])
            policy.append(["DIM_POLICY", "POLICY_BK"])
            workbook.save(path)
            workbook.close()
            jobs = read_table_list(path)

        self.assertEqual([job.group_name for job in jobs], ["Party", "Party", "Policy"])
        self.assertEqual(
            [job.table_name for job in jobs],
            ["DIM_PARTY", "DIM_PARTY_ROLE", "DIM_POLICY"],
        )

    def test_reads_ignore_case_flag(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "TableName,KeyColumns,IgnoreCase\n"
                "DIM_COUNTRY,CTRY_COUNTRY_CODE,1\n"
                "DIM_USER,USER_BK,0\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertTrue(jobs[0].ignore_case)
        self.assertFalse(jobs[1].ignore_case)

    def test_utf8_bom_and_optional_schema(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_bytes(
                b"\xef\xbb\xbfTableName,KeyColumns,SchemaName\n"
                b"DIM_USER,USER_BK,mart\n"
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].schema_name, "mart")

    def test_missing_key_columns_raises(self) -> None:
        with self.assertRaisesRegex(ValueError, "KeyColumns"):
            map_row(["TableName", "KeyColumns"], ["DIM_COUNTRY", ""], 2)


class SheetNameTests(unittest.TestCase):
    def test_truncates_and_avoids_collisions(self) -> None:
        used: set[str] = set()
        first = excel_sheet_name("DIM_POLICY_COVERAGE_LIMIT_DETAIL", used)
        second = excel_sheet_name("DIM_POLICY_COVERAGE_LIMIT_DETAIL", used)
        self.assertEqual(first, "DIM_POLICY_COVERAGE_LIMIT_DETAI")
        self.assertEqual(len(first), 31)
        self.assertEqual(second, "DIM_POLICY_COVERAGE_LIMIT_DET_2")
        self.assertLessEqual(len(second), 31)

    def test_replaces_invalid_characters(self) -> None:
        used: set[str] = set()
        self.assertEqual(excel_sheet_name("FACT[CLAIM]/2024", used), "FACT_CLAIM__2024")


class ClassifyTests(unittest.TestCase):
    def test_classifies_procedure_result_sets(self) -> None:
        self.assertEqual(
            classify_result_set(["Table", "Key", "Status", "Column", "SourceValue", "TargetValue"]),
            "detail",
        )
        self.assertEqual(
            classify_result_set(["Table", "Key", "Status", "RecordCount"]),
            "duplicates",
        )
        self.assertEqual(
            classify_result_set(["Table", "SourceRowCount", "TargetRowCount", "MatchingRows"]),
            "summary",
        )


class WorkbookTests(unittest.TestCase):
    def test_writes_summary_first_and_one_sheet_per_table(self) -> None:
        results = [
            TableResult(
                job=TableJob("DIM_COUNTRY", "CTRY_COUNTRY_CODE"),
                status="OK",
                schema_name="dbo",
                detail_rows=[
                    ("DIM_COUNTRY", "SA", "ONLY_IN_SOURCE", None, None, None),
                ],
                duplicate_rows=[("DIM_COUNTRY", "XX", "DUPLICATE_SOURCE", 2)],
                summary={"SourceRowCount": 10, "TargetRowCount": 9, "OnlyInSource": 1, "ValueMismatch": 0},
            ),
            TableResult(
                job=TableJob("DIM_USER", "USER_BK"),
                status="FAILED",
                schema_name="dbo",
                error="Key column 'USER_BK' does not exist in the target table.",
            ),
        ]

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "out.xlsx"
            write_workbook(path, results)
            from openpyxl import load_workbook

            workbook = load_workbook(path)
            self.assertEqual(workbook.sheetnames[0], "_Summary")
            self.assertEqual(workbook.sheetnames[1], "_Duplicates")
            self.assertIn("DIM_COUNTRY", workbook.sheetnames)
            self.assertNotIn("DIM_USER", workbook.sheetnames)
            self.assertEqual(workbook["_Summary"]["A1"].value, "Group")
            self.assertIsNone(workbook["_Summary"]["A2"].value)
            self.assertEqual(workbook["_Summary"]["B2"].value, "DIM_COUNTRY")
            self.assertEqual(workbook["_Summary"]["F2"].value, "OK")
            self.assertEqual(workbook["_Summary"]["B3"].value, "DIM_USER")
            self.assertEqual(workbook["_Summary"]["F3"].value, "FAILED")
            workbook.close()


class GroupJobsTests(unittest.TestCase):
    def test_batches_interleaved_rows_in_first_seen_order(self) -> None:
        jobs = [
            TableJob("DIM_PARTY", "PARTY_BK", group_name="Party"),
            TableJob("DIM_POLICY", "POLICY_BK", group_name="Policy"),
            TableJob("DIM_PARTY_ROLE", "ROLE_BK", group_name="party"),
        ]

        groups = group_jobs(jobs)

        self.assertEqual([name for name, _ in groups], ["Party", "Policy"])
        self.assertEqual(
            [job.table_name for job in groups[0][1]],
            ["DIM_PARTY", "DIM_PARTY_ROLE"],
        )
        self.assertEqual([job.table_name for job in groups[1][1]], ["DIM_POLICY"])


class GroupedWorkbookTests(unittest.TestCase):
    def test_grouped_path_uses_group_name(self) -> None:
        self.assertEqual(
            grouped_workbook_path(Path("compare-results.xlsx"), "Party", True),
            Path("Party.xlsx"),
        )
        self.assertEqual(
            grouped_workbook_path(Path("output"), "Party", True),
            Path("output") / "Party.xlsx",
        )
        self.assertEqual(
            grouped_workbook_path(Path("out.xlsx"), None, False),
            Path("out.xlsx"),
        )

    def test_resolve_workbook_base_uses_folder_when_grouped(self) -> None:
        self.assertEqual(resolve_workbook_base(None, True), Path("."))
        self.assertEqual(resolve_workbook_base(Path("results"), True), Path("results"))
        self.assertEqual(resolve_workbook_base(Path("out.xlsx"), True), Path("out.xlsx"))
        self.assertEqual(resolve_workbook_base(Path("out"), False), Path("out.xlsx"))

    def test_writes_one_workbook_per_group(self) -> None:
        results = [
            TableResult(
                job=TableJob("DIM_PARTY", "PARTY_BK", group_name="Party"),
                status="OK",
                schema_name="dbo",
                detail_rows=[("DIM_PARTY", "1", "ONLY_IN_SOURCE", None, None, None)],
            ),
            TableResult(
                job=TableJob("DIM_PARTY_ROLE", "ROLE_BK", group_name="party"),
                status="OK",
                schema_name="dbo",
                detail_rows=[("DIM_PARTY_ROLE", "2", "ONLY_IN_TARGET", None, None, None)],
            ),
            TableResult(
                job=TableJob("DIM_POLICY", "POLICY_BK", group_name="Policy"),
                status="OK",
                schema_name="dbo",
                detail_rows=[("DIM_POLICY", "3", "VALUE_MISMATCH", "FEE", "1", "2")],
            ),
        ]

        with tempfile.TemporaryDirectory() as folder:
            paths = write_result_workbooks(Path(folder), results)
            from openpyxl import load_workbook

            self.assertEqual([path.name for path in paths], ["Party.xlsx", "Policy.xlsx"])

            party = load_workbook(paths[0])
            self.assertEqual(party.sheetnames[0], "_Summary")
            self.assertIn("DIM_PARTY", party.sheetnames)
            self.assertIn("DIM_PARTY_ROLE", party.sheetnames)
            self.assertNotIn("DIM_POLICY", party.sheetnames)
            self.assertEqual(party["_Summary"]["A2"].value, "Party")
            self.assertEqual(party["_Summary"]["B2"].value, "DIM_PARTY")
            self.assertEqual(party["_Summary"]["A3"].value, "party")
            self.assertEqual(party["_Summary"]["B3"].value, "DIM_PARTY_ROLE")
            party.close()

            policy = load_workbook(paths[1])
            self.assertIn("DIM_POLICY", policy.sheetnames)
            self.assertNotIn("DIM_PARTY", policy.sheetnames)
            policy.close()


if __name__ == "__main__":
    unittest.main()
