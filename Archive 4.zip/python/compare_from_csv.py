#!/usr/bin/env python3
"""Compare many tables from a CSV or Excel list and write one workbook per group."""

from __future__ import annotations

import argparse
import csv
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence, TextIO, TypeVar

EXCEL_MAX_ROWS = 1_048_576
EXCEL_MAX_SHEET = 31
PROGRESS_EVERY = 100_000
INVALID_SHEET_CHARS = re.compile(r"[\[\]*:/\\?]")
INVALID_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*]')
RESERVED_SHEETS = ("_Summary", "_Schema", "_Duplicates")
DEFAULT_GROUP_NAME = "Ungrouped"
T = TypeVar("T")

DETAIL_HEADERS = ("Table", "Key", "Status", "Column", "SourceValue", "TargetValue")
DUPLICATE_HEADERS = ("Table", "Key", "Status", "RecordCount")
SCHEMA_HEADERS = ("Table", "Column", "Side", "Role", "SourceType", "TargetType")
SUMMARY_HEADERS = (
    "Group",
    "Table",
    "Schema",
    "KeyColumns",
    "ExcludedColumns",
    "Filter",
    "Status",
    "HasDifferences",
    "DurationSec",
    "SourceRowCount",
    "TargetRowCount",
    "CountDifference",
    "MatchingRows",
    "OnlyInSource",
    "OnlyInTarget",
    "ValueMismatch",
    "DuplicateSourceKeys",
    "DuplicateTargetKeys",
    "DetailRows",
    "DuplicateRows",
    "SchemaRows",
    "OverflowFile",
    "Error",
)

_LOG_FILE: TextIO | None = None

COLUMN_ALIASES = {
    "tablename": "table_name",
    "table": "table_name",
    "table_name": "table_name",
    "keycolumns": "key_columns",
    "keycolumn": "key_columns",
    "key": "key_columns",
    "keys": "key_columns",
    "key_columns": "key_columns",
    "excludedcolumns": "excluded_columns",
    "excludedcolumn": "excluded_columns",
    "excluded": "excluded_columns",
    "excluded_columns": "excluded_columns",
    "schemaname": "schema_name",
    "schema": "schema_name",
    "schema_name": "schema_name",
    "output": "output",
    "includematches": "include_matches",
    "include_matches": "include_matches",
    "ignorecase": "ignore_case",
    "ignore_case": "ignore_case",
    "filter": "row_filter",
    "where": "row_filter",
    "predicate": "row_filter",
    "rowfilter": "row_filter",
    "row_filter": "row_filter",
    "group": "group_name",
    "package": "group_name",
    "groupname": "group_name",
    "packagename": "group_name",
    "group_name": "group_name",
    "module": "group_name",
    "subject": "group_name",
    "subjectarea": "group_name",
    "domain": "group_name",
    "area": "group_name",
}

GENERIC_SHEET_NAMES = {"sheet", "sheet1", "sheet2", "sheet3", "tables", "table", "list", "data"}

ODBC_DRIVERS = (
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "ODBC Driver 13 for SQL Server",
    "SQL Server",
)


@dataclass
class TableJob:
    table_name: str
    key_columns: str
    excluded_columns: str | None = None
    schema_name: str | None = None
    output: str | None = None
    include_matches: bool | None = None
    ignore_case: bool | None = None
    row_filter: str | None = None
    group_name: str | None = None
    line_number: int = 0


@dataclass
class ResultSet:
    kind: str
    columns: list[str]
    rows: list[tuple[Any, ...]]


@dataclass
class TableResult:
    job: TableJob
    status: str
    schema_name: str = "dbo"
    duration_sec: float = 0.0
    error: str | None = None
    detail_columns: list[str] = field(default_factory=lambda: list(DETAIL_HEADERS))
    detail_rows: list[tuple[Any, ...]] = field(default_factory=list)
    duplicate_rows: list[tuple[Any, ...]] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)
    schema_rows: list[tuple[Any, ...]] = field(default_factory=list)
    overflow_file: str | None = None
    output: str | None = None


def log(message: str) -> None:
    print(message, flush=True)
    handle = _LOG_FILE
    if handle is not None:
        handle.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  {message}\n")
        handle.flush()


def resolve_log_path(log_path: Path | None, workbook: Path | None, use_groups: bool) -> Path:
    if log_path is not None:
        return log_path
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if workbook is None:
        return Path(f"compare-{stamp}.log")
    folder = workbook.parent if workbook.suffix.lower() == ".xlsx" else workbook
    if use_groups or workbook.suffix.lower() != ".xlsx":
        return Path(folder) / f"compare-{stamp}.log"
    return workbook.with_suffix(".log")


def run_exit_code(results: Sequence[TableResult], fail_on_diff: bool) -> int:
    failed = sum(1 for result in results if result.status != "OK")
    if failed:
        return 2
    if fail_on_diff and any(has_differences(result) == "Yes" for result in results):
        return 3
    return 0


def normalize_header(name: str | None) -> str:
    if name is None:
        return ""
    return re.sub(r"[\s_\-]+", "", str(name).strip().lower())


def parse_bool(value: Any) -> bool | None:
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"", "none"}:
        return None
    if text in {"1", "true", "yes", "y"}:
        return True
    if text in {"0", "false", "no", "n"}:
        return False
    raise ValueError(f"Cannot parse boolean value {value!r}.")


def blank_to_none(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def map_row(headers: Sequence[str], values: Sequence[Any], line_number: int) -> TableJob | None:
    mapped: dict[str, Any] = {}
    for header, value in zip(headers, values):
        key = COLUMN_ALIASES.get(normalize_header(header))
        if key:
            mapped[key] = value

    table_name = blank_to_none(mapped.get("table_name"))
    key_columns = blank_to_none(mapped.get("key_columns"))
    if table_name is None and key_columns is None:
        return None
    if table_name is None:
        raise ValueError(f"Row {line_number}: TableName is required.")
    if key_columns is None:
        raise ValueError(f"Row {line_number}: KeyColumns is required for {table_name}.")

    output = blank_to_none(mapped.get("output"))
    if output:
        output = output.upper()

    return TableJob(
        table_name=table_name,
        key_columns=key_columns,
        excluded_columns=blank_to_none(mapped.get("excluded_columns")),
        schema_name=blank_to_none(mapped.get("schema_name")),
        output=output,
        include_matches=parse_bool(mapped.get("include_matches")),
        ignore_case=parse_bool(mapped.get("ignore_case")),
        row_filter=blank_to_none(mapped.get("row_filter")),
        group_name=blank_to_none(mapped.get("group_name")),
        line_number=line_number,
    )


def header_values(row: Sequence[Any] | None) -> list[str]:
    if row is None:
        return []
    return ["" if value is None else str(value) for value in row]


def mapped_header(name: str) -> str | None:
    return COLUMN_ALIASES.get(normalize_header(name))


def looks_like_header_row(row: Sequence[Any] | None) -> bool:
    mapped = {mapped_header(header) for header in header_values(row)}
    return "table_name" in mapped and "key_columns" in mapped


def ensure_group_header(headers: list[str]) -> list[str]:
    if any(mapped_header(header) == "group_name" for header in headers):
        return headers
    if headers and mapped_header(headers[0]) is None:
        headers = list(headers)
        headers[0] = "Group"
    return headers


def pad_values(values: Sequence[Any], length: int) -> list[Any]:
    padded = list(values)
    if len(padded) < length:
        padded.extend([None] * (length - len(padded)))
    return padded[:length]


def sheet_default_group(title: str | None) -> str | None:
    name = blank_to_none(title)
    if name is None or normalize_header(name) in GENERIC_SHEET_NAMES:
        return None
    return name


def parse_table_rows(
    rows: Sequence[Sequence[Any] | None],
    default_group: str | None = None,
) -> list[TableJob]:
    header_index = next((index for index, row in enumerate(rows) if looks_like_header_row(row)), None)
    if header_index is None:
        raise ValueError("The table list must have TableName and KeyColumns columns.")

    headers = ensure_group_header(header_values(rows[header_index]))
    jobs: list[TableJob] = []
    last_group = default_group
    for index, raw in enumerate(rows[header_index + 1 :], start=header_index + 2):
        if raw is None:
            continue
        values = pad_values(raw, len(headers))
        first = blank_to_none(values[0]) if values else None
        if first and first.startswith("#"):
            continue
        job = map_row(headers, values, index)
        if not job:
            continue
        if job.group_name:
            last_group = job.group_name
        elif last_group:
            job.group_name = last_group
        jobs.append(job)
    return jobs


def read_table_list(path: Path) -> list[TableJob]:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        jobs = _read_excel_jobs(path)
    elif suffix in {".csv", ".txt"}:
        jobs = parse_table_rows(_read_csv_rows(path))
    else:
        raise ValueError(f"Unsupported table list type: {path.suffix}. Use .csv or .xlsx.")

    if not jobs:
        raise ValueError(f"{path} has a header row but no tables.")
    return jobs


def _read_csv_rows(path: Path) -> list[list[Any]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return [list(row) for row in csv.reader(handle)]


def _read_excel_jobs(path: Path) -> list[TableJob]:
    from openpyxl import load_workbook

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        jobs: list[TableJob] = []
        found_header = False
        for sheet in workbook.worksheets:
            rows = [tuple(row) for row in sheet.iter_rows(values_only=True)]
            if not any(looks_like_header_row(row) for row in rows):
                continue
            found_header = True
            jobs.extend(parse_table_rows(rows, default_group=sheet_default_group(sheet.title)))
        if not found_header:
            raise ValueError("The table list must have TableName and KeyColumns columns.")
        return jobs
    finally:
        workbook.close()


def classify_result_set(columns: Sequence[str]) -> str:
    names = {str(column) for column in columns}
    if {"SourceValue", "TargetValue"} <= names:
        return "detail"
    if {"Side", "Role"} <= names:
        return "schema"
    if "RecordCount" in names:
        return "duplicates"
    if "SourceRowCount" in names:
        return "summary"
    return "unknown"


def safe_filename(name: str) -> str:
    cleaned = INVALID_FILENAME_CHARS.sub("_", name).strip(" .")
    return cleaned or DEFAULT_GROUP_NAME


def group_sort_key(name: str | None) -> str | None:
    return name.casefold() if name else None


def group_by_name(
    items: Sequence[T],
    get_name: Callable[[T], str | None],
) -> list[tuple[str | None, list[T]]]:
    grouped: dict[str | None, list[T]] = {}
    labels: dict[str | None, str | None] = {}
    order: list[str | None] = []
    for item in items:
        name = get_name(item)
        key = group_sort_key(name)
        if key not in grouped:
            grouped[key] = []
            labels[key] = name
            order.append(key)
        grouped[key].append(item)
    return [(labels[key], grouped[key]) for key in order]


def group_jobs(jobs: Sequence[TableJob]) -> list[tuple[str | None, list[TableJob]]]:
    return group_by_name(jobs, lambda job: job.group_name)


def group_results(results: Sequence[TableResult]) -> list[tuple[str | None, list[TableResult]]]:
    return group_by_name(results, lambda result: result.job.group_name)


def has_named_groups(items: Sequence[TableJob] | Sequence[TableResult]) -> bool:
    return any(
        item.group_name if isinstance(item, TableJob) else item.job.group_name
        for item in items
    )


def grouped_workbook_path(base: Path, group_name: str | None, use_groups: bool) -> Path:
    if not use_groups:
        return base if base.suffix.lower() == ".xlsx" else base.with_suffix(".xlsx")
    name = safe_filename(group_name) if group_name else DEFAULT_GROUP_NAME
    folder = base.parent if base.suffix.lower() == ".xlsx" else base
    return folder / f"{name}.xlsx"


def excel_sheet_name(name: str, used: set[str]) -> str:
    cleaned = INVALID_SHEET_CHARS.sub("_", name).strip("' ") or "Sheet"
    cleaned = cleaned[:EXCEL_MAX_SHEET]
    candidate = cleaned
    index = 2
    while candidate.lower() in used:
        suffix = f"_{index}"
        candidate = f"{cleaned[: EXCEL_MAX_SHEET - len(suffix)]}{suffix}"
        index += 1
    used.add(candidate.lower())
    return candidate


def cell_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.hex()
    return value


def has_differences(result: TableResult) -> str:
    if result.status != "OK":
        return "Unknown"
    if result.output == "PREFLIGHT":
        return "Preflight"
    summary = result.summary
    counts = [
        summary.get("OnlyInSource"),
        summary.get("OnlyInTarget"),
        summary.get("ValueMismatch"),
        summary.get("DuplicateSourceKeys"),
        summary.get("DuplicateTargetKeys"),
    ]
    if any(count is not None for count in counts):
        return "Yes" if any((count or 0) > 0 for count in counts) else "No"
    if result.detail_rows or result.duplicate_rows:
        return "Yes"
    return "No"


def pick_driver(preferred: str | None) -> str:
    try:
        import pyodbc
    except ImportError as exc:
        raise SystemExit("pyodbc is required. Install dependencies with: pip install -r requirements.txt") from exc

    installed = set(pyodbc.drivers())
    candidates = (([preferred] if preferred else []) + list(ODBC_DRIVERS))
    for driver in candidates:
        if driver in installed:
            return driver
    available = ", ".join(sorted(installed)) or "none"
    raise SystemExit(
        "No supported SQL Server ODBC driver is installed. "
        f"Available drivers: {available}."
    )


def connect(
    server: str,
    database: str,
    driver: str,
    username: str | None,
    password: str | None,
    timeout: int,
    trust_cert: bool,
) -> Any:
    import pyodbc

    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
        f"DATABASE={database}",
    ]
    if username:
        parts.append(f"UID={username}")
        parts.append(f"PWD={password or ''}")
    else:
        parts.append("Trusted_Connection=yes")
    if driver.startswith("ODBC Driver 18") or driver.startswith("ODBC Driver 17"):
        parts.append("Encrypt=yes")
        parts.append(f"TrustServerCertificate={'yes' if trust_cert else 'no'}")

    connection = pyodbc.connect(";".join(parts), timeout=timeout)
    connection.timeout = timeout
    return connection


def fetch_result_sets(cursor: Any) -> list[ResultSet]:
    sets: list[ResultSet] = []
    while True:
        if cursor.description is not None:
            columns = [column[0] for column in cursor.description]
            kind = classify_result_set(columns)
            rows: list[tuple[Any, ...]] = []
            while True:
                batch = cursor.fetchmany(PROGRESS_EVERY)
                if not batch:
                    break
                rows.extend(tuple(row) for row in batch)
                if len(rows) >= PROGRESS_EVERY:
                    log(f"  Reading {kind}: {len(rows):,} rows")
            sets.append(ResultSet(kind, columns, rows))
        if not cursor.nextset():
            break
    return sets


def print_sql_messages(connection: Any) -> None:
    messages = getattr(connection, "messages", None)
    if not messages:
        return
    for message in messages:
        text = message[1] if isinstance(message, tuple) and len(message) > 1 else str(message)
        text = str(text).strip()
        if text:
            log(text)
    connection.messages.clear()


def compare_table(
    cursor: Any,
    connection: Any,
    job: TableJob,
    args: argparse.Namespace,
) -> TableResult:
    output = "PREFLIGHT" if args.preflight else (job.output or args.output)
    include_matches = args.include_matches if job.include_matches is None else job.include_matches
    ignore_case = args.ignore_case if job.ignore_case is None else job.ignore_case
    schema_name = job.schema_name or args.schema
    started = datetime.now()

    sql = """
EXEC dbo.CompareTables
    @SourceDatabase = ?,
    @TargetDatabase = ?,
    @SchemaName = ?,
    @TableName = ?,
    @KeyColumns = ?,
    @ExcludedColumns = ?,
    @IncludeMatches = ?,
    @Output = ?,
    @SourceServer = ?,
    @TargetServer = ?,
    @IgnoreCase = ?,
    @Filter = ?,
    @MaxDetailRows = ?;
"""
    cursor.execute(
        sql,
        args.source_database,
        args.target_database,
        schema_name,
        job.table_name,
        job.key_columns,
        job.excluded_columns,
        1 if include_matches else 0,
        output,
        args.source_server,
        args.target_server,
        1 if ignore_case else 0,
        job.row_filter,
        args.max_detail_rows,
    )
    log("  Query returned. Reading result sets...")
    print_sql_messages(connection)
    sets = fetch_result_sets(cursor)
    duration = (datetime.now() - started).total_seconds()

    result = TableResult(
        job=job,
        status="OK",
        schema_name=schema_name,
        duration_sec=duration,
        output=output,
    )
    for result_set in sets:
        if result_set.kind == "detail":
            result.detail_columns = result_set.columns
            result.detail_rows = result_set.rows
        elif result_set.kind == "duplicates":
            result.duplicate_rows = result_set.rows
        elif result_set.kind == "schema":
            result.schema_rows = result_set.rows
        elif result_set.kind == "summary" and result_set.rows:
            result.summary = dict(zip(result_set.columns, result_set.rows[0]))
    return result


def summary_row(result: TableResult) -> list[Any]:
    summary = result.summary
    return [
        result.job.group_name,
        result.job.table_name,
        result.schema_name,
        result.job.key_columns,
        result.job.excluded_columns,
        result.job.row_filter,
        result.status,
        has_differences(result),
        round(result.duration_sec, 2),
        summary.get("SourceRowCount"),
        summary.get("TargetRowCount"),
        summary.get("CountDifference"),
        summary.get("MatchingRows"),
        summary.get("OnlyInSource"),
        summary.get("OnlyInTarget"),
        summary.get("ValueMismatch"),
        summary.get("DuplicateSourceKeys"),
        summary.get("DuplicateTargetKeys"),
        len(result.detail_rows),
        len(result.duplicate_rows),
        len(result.schema_rows),
        result.overflow_file,
        result.error,
    ]


def write_sheet(
    workbook: Any,
    title: str,
    used: set[str],
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    overflow_dir: Path,
    table_name: str | None = None,
) -> str | None:
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    sheet_title = excel_sheet_name(title, used)
    sheet = workbook.create_sheet(sheet_title)
    overflow_file = None
    written_rows: Sequence[Sequence[Any]] = rows
    max_data_rows = EXCEL_MAX_ROWS - 1

    if len(rows) > max_data_rows:
        overflow_path = overflow_dir / f"{table_name or sheet_title}.csv"
        log(f"  {sheet_title}: {len(rows):,} rows exceed Excel's limit. Writing the full result to CSV...")
        _write_csv(overflow_path, headers, rows)
        overflow_file = str(overflow_path)
        written_rows = rows[:max_data_rows]
        log(f"  Full result written to {overflow_path}")
        log(f"  {sheet_title}: writing the first {len(written_rows):,} rows into Excel")

    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)
    sheet.append(list(headers))
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(vertical="center")

    status_fills = {
        "OK": PatternFill("solid", fgColor="C6EFCE"),
        "FAILED": PatternFill("solid", fgColor="FFC7CE"),
        "MATCH": PatternFill("solid", fgColor="C6EFCE"),
        "ONLY_IN_SOURCE": PatternFill("solid", fgColor="BDD7EE"),
        "ONLY_IN_TARGET": PatternFill("solid", fgColor="FCE4D6"),
        "VALUE_MISMATCH": PatternFill("solid", fgColor="F8CBAD"),
        "DUPLICATE_SOURCE": PatternFill("solid", fgColor="E2D5F1"),
        "DUPLICATE_TARGET": PatternFill("solid", fgColor="E2D5F1"),
        "Yes": PatternFill("solid", fgColor="F8CBAD"),
        "No": PatternFill("solid", fgColor="C6EFCE"),
        "Unknown": PatternFill("solid", fgColor="D9D9D9"),
    }
    status_index = next((i for i, header in enumerate(headers, start=1) if header == "Status"), None)
    diff_index = next((i for i, header in enumerate(headers, start=1) if header == "HasDifferences"), None)

    total_rows = len(written_rows)
    if total_rows >= PROGRESS_EVERY:
        log(f"  Writing sheet {sheet_title}: 0 / {total_rows:,}")
    for index, row in enumerate(written_rows, start=1):
        sheet.append([cell_value(value) for value in row])
        current = sheet.max_row
        if total_rows >= PROGRESS_EVERY and index % PROGRESS_EVERY == 0:
            log(f"  Writing sheet {sheet_title}: {index:,} / {total_rows:,}")
        if status_index:
            status = sheet.cell(current, status_index).value
            fill = status_fills.get(str(status) if status is not None else "")
            if fill:
                sheet.cell(current, status_index).fill = fill
        if diff_index:
            value = sheet.cell(current, diff_index).value
            fill = status_fills.get(str(value) if value is not None else "")
            if fill:
                sheet.cell(current, diff_index).fill = fill

    sheet.freeze_panes = "A2"
    for index, header in enumerate(headers, start=1):
        width = len(str(header)) + 2
        for row in sheet.iter_rows(min_row=2, min_col=index, max_col=index, max_row=min(sheet.max_row, 200)):
            value = row[0].value
            if value is not None:
                width = min(max(width, len(str(value)) + 2), 60)
        sheet.column_dimensions[get_column_letter(index)].width = width
    if sheet.max_row >= 1:
        sheet.auto_filter.ref = sheet.dimensions
    return overflow_file


def _write_csv(path: Path, headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    total_rows = len(rows)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        for index, row in enumerate(rows, start=1):
            writer.writerow(["" if value is None else value for value in row])
            if total_rows >= PROGRESS_EVERY and index % PROGRESS_EVERY == 0:
                log(f"  Writing CSV {path.name}: {index:,} / {total_rows:,}")


def write_workbook(path: Path, results: Sequence[TableResult]) -> None:
    from openpyxl import Workbook

    detail_rows = sum(len(result.detail_rows) for result in results)
    log(f"Comparisons finished. Writing {path.name}: {len(results)} table(s), {detail_rows:,} detail rows.")
    workbook = Workbook()
    default = workbook.active
    workbook.remove(default)
    used: set[str] = set()
    overflow_dir = path.with_name(f"{path.stem}-overflow")

    duplicate_rows = [row for result in results for row in result.duplicate_rows]
    if duplicate_rows:
        log(f"  Sheet _Duplicates: {len(duplicate_rows):,} rows")
        write_sheet(workbook, "_Duplicates", used, DUPLICATE_HEADERS, duplicate_rows, overflow_dir)

    used_titles = {name.lower() for name in RESERVED_SHEETS}
    schema_rows = [row for result in results for row in result.schema_rows]
    if schema_rows:
        log(f"  Sheet _Schema: {len(schema_rows):,} rows")
        write_sheet(workbook, "_Schema", used, SCHEMA_HEADERS, schema_rows, overflow_dir)

    ok_results = [result for result in results if result.status == "OK" and result.output != "PREFLIGHT"]
    for sheet_index, result in enumerate(ok_results, start=1):
        title = result.job.table_name
        if title.lower() in used_titles:
            title = f"{result.schema_name}.{result.job.table_name}"
        log(f"  Sheet {sheet_index}/{len(ok_results)} {title}: {len(result.detail_rows):,} detail rows")
        overflow = write_sheet(
            workbook,
            title,
            used,
            result.detail_columns,
            result.detail_rows,
            overflow_dir,
            table_name=result.job.table_name,
        )
        if overflow:
            result.overflow_file = overflow
        used_titles.add(title.lower())

    write_sheet(
        workbook,
        "_Summary",
        used,
        SUMMARY_HEADERS,
        [summary_row(result) for result in results],
        overflow_dir,
    )
    workbook.move_sheet("_Summary", offset=-(len(workbook.sheetnames) - 1))
    if "_Schema" in workbook.sheetnames:
        schema_index = workbook.sheetnames.index("_Schema")
        if schema_index != 1:
            workbook.move_sheet("_Schema", offset=1 - schema_index)

    path.parent.mkdir(parents=True, exist_ok=True)
    log(f"Saving {path} ...")
    try:
        workbook.save(path)
    except OSError as exc:
        fallback = path.with_stem(f"{path.stem}-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
        log(f"Could not save {path}: {exc}. Writing {fallback} instead.")
        workbook.save(fallback)
        path = fallback
    log(f"Wrote {path}")


def write_result_workbooks(base: Path, results: Sequence[TableResult]) -> list[Path]:
    use_groups = has_named_groups(results)
    written: list[Path] = []
    for group_name, group in group_results(results):
        path = grouped_workbook_path(base, group_name, use_groups)
        if use_groups:
            label = group_name or DEFAULT_GROUP_NAME
            log(f"Group {label}: {len(group)} table(s) -> {path.name}")
        write_workbook(path, group)
        written.append(path)
    return written


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Read TableName, KeyColumns, and ExcludedColumns from a CSV or Excel "
            "file, run dbo.CompareTables for each row, and write one workbook "
            "per Group/Package with a _Summary sheet plus one sheet per table."
        )
    )
    parser.add_argument("--tables", required=True, type=Path, help="CSV or Excel control file.")
    parser.add_argument("--server", required=True, help="SQL Server that hosts the utility database.")
    parser.add_argument("--database", default="DwhCompare", help="Utility database. Default: DwhCompare.")
    parser.add_argument("--source-database", required=True, help="@SourceDatabase.")
    parser.add_argument("--target-database", required=True, help="@TargetDatabase.")
    parser.add_argument("--schema", default="dbo", help="Default @SchemaName. Default: dbo.")
    parser.add_argument("--source-server", help="Optional @SourceServer linked server.")
    parser.add_argument("--target-server", help="Optional @TargetServer linked server.")
    parser.add_argument(
        "--output",
        default="ALL",
        choices=("ALL", "DETAIL", "DIFF", "DUPLICATES", "SUMMARY", "PREFLIGHT"),
        help="Default @Output. ALL writes detail, duplicates, summary, and schema in one scan. Default: ALL.",
    )
    parser.add_argument(
        "--include-matches",
        action="store_true",
        help="Include MATCH rows in detail sheets. Default is to omit them. Ignored for DIFF.",
    )
    parser.add_argument(
        "--ignore-case",
        action="store_true",
        help="Compare string keys and string values without case. Trailing spaces still differ.",
    )
    parser.add_argument(
        "--workbook",
        type=Path,
        help=(
            "Output .xlsx path, or a directory when the table list has Group/Package. "
            "Default: compare-results-YYYYmmdd-HHMMSS.xlsx. "
            "With groups, each group is written as a separate workbook named after the group."
        ),
    )
    parser.add_argument("--driver", help="ODBC driver name. The first installed supported driver is used if omitted.")
    parser.add_argument("--username", help="SQL login. Omit to use Windows / trusted authentication.")
    parser.add_argument("--password", help="SQL login password.")
    parser.add_argument("--timeout", type=int, default=0, help="Query timeout in seconds. 0 means no timeout.")
    parser.add_argument(
        "--no-trust-cert",
        action="store_true",
        help="Require a trusted TLS certificate. Default is TrustServerCertificate=yes.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print the resolved table list and exit.")
    parser.add_argument(
        "--preflight",
        action="store_true",
        help="Validate keys, types, and filters without scanning rows. Writes _Summary and _Schema only.",
    )
    parser.add_argument(
        "--fail-on-diff",
        action="store_true",
        help="Exit 3 when any compared table has differences. Exit 2 still means a table failed to run.",
    )
    parser.add_argument(
        "--max-detail-rows",
        type=int,
        metavar="N",
        help="Keep at most N detail rows per table. Summary counts stay complete.",
    )
    parser.add_argument(
        "--log",
        type=Path,
        help="Run log path. Default: a .log file next to the workbook or in the output folder.",
    )
    args = parser.parse_args(argv)
    if args.max_detail_rows is not None and args.max_detail_rows < 1:
        parser.error("--max-detail-rows must be greater than 0.")
    return args


def default_workbook_path() -> Path:
    return Path(f"compare-results-{datetime.now().strftime('%Y%m%d-%H%M%S')}.xlsx")


def resolve_workbook_base(workbook: Path | None, use_groups: bool) -> Path:
    if workbook is None:
        return Path(".") if use_groups else default_workbook_path()
    if use_groups and (workbook.is_dir() or workbook.suffix.lower() != ".xlsx"):
        return workbook
    if workbook.suffix.lower() != ".xlsx":
        return workbook.with_suffix(".xlsx")
    return workbook


def compare_one_job(
    cursor: Any,
    connection: Any,
    job: TableJob,
    args: argparse.Namespace,
) -> TableResult:
    schema = job.schema_name or args.schema
    started = datetime.now()
    try:
        result = compare_table(cursor, connection, job, args)
        extra = ""
        if job.row_filter:
            extra += f", filter={job.row_filter}"
        if result.schema_rows:
            extra += f", {len(result.schema_rows)} schema"
        log(
            f"  {result.status} in {result.duration_sec:.1f}s "
            f"({len(result.detail_rows):,} detail, {len(result.duplicate_rows):,} duplicate{extra})"
        )
        return result
    except Exception as exc:
        result = TableResult(
            job=job,
            status="FAILED",
            schema_name=schema,
            duration_sec=(datetime.now() - started).total_seconds(),
            error=str(exc).splitlines()[0],
            output="PREFLIGHT" if args.preflight else (job.output or args.output),
        )
        log(f"  FAILED: {result.error}")
        return result


def run_jobs(
    jobs: Iterable[TableJob],
    args: argparse.Namespace,
    workbook_base: Path | None = None,
) -> list[TableResult]:
    job_list = list(jobs)
    use_groups = has_named_groups(job_list)
    groups = group_jobs(job_list)
    driver = pick_driver(args.driver)
    log(f"Connecting to {args.server} / {args.database} with {driver}")
    connection = connect(
        server=args.server,
        database=args.database,
        driver=driver,
        username=args.username,
        password=args.password,
        timeout=args.timeout,
        trust_cert=not args.no_trust_cert,
    )
    results: list[TableResult] = []
    index = 0
    try:
        cursor = connection.cursor()
        for group_index, (group_name, group) in enumerate(groups, start=1):
            label = group_name or DEFAULT_GROUP_NAME
            path = (
                grouped_workbook_path(workbook_base, group_name, use_groups)
                if workbook_base is not None
                else None
            )
            if use_groups:
                names = ", ".join(job.table_name for job in group)
                log(f"Group {group_index}/{len(groups)} {label}: {len(group)} table(s) [{names}]")
            group_results: list[TableResult] = []
            for job in group:
                index += 1
                schema = job.schema_name or args.schema
                output = "PREFLIGHT" if args.preflight else (job.output or args.output)
                group_tag = f" [{job.group_name}]" if job.group_name else ""
                filter_tag = f" filter={job.row_filter}" if job.row_filter else ""
                log(f"[{index}/{len(job_list)}] {schema}.{job.table_name}{group_tag} ({output}){filter_tag}")
                result = compare_one_job(cursor, connection, job, args)
                group_results.append(result)
                results.append(result)
                if path is not None and (len(group_results) == 1 or len(group_results) == len(group)):
                    if use_groups and len(group_results) == len(group):
                        log(f"Group {label} finished. Writing {path} now, then starting the next group.")
                    elif use_groups:
                        log(f"  Writing {path} after the first {label} table.")
                    write_workbook(path, group_results)
        cursor.close()
    finally:
        connection.close()
    return results


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if not args.tables.exists():
        print(f"Table list not found: {args.tables}", file=sys.stderr)
        return 1

    try:
        jobs = read_table_list(args.tables)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    groups = group_jobs(jobs)
    if args.dry_run:
        log(f"Loaded {len(jobs)} table(s) in {len(groups)} group(s) from {args.tables}")
        for group_name, group in groups:
            label = group_name or DEFAULT_GROUP_NAME
            log(f"  {label}: {', '.join(job.table_name for job in group)}")
        return 0

    workbook = resolve_workbook_base(args.workbook, has_named_groups(jobs))
    log_path = resolve_log_path(args.log, workbook, has_named_groups(jobs))
    log_path.parent.mkdir(parents=True, exist_ok=True)
    global _LOG_FILE
    _LOG_FILE = log_path.open("a", encoding="utf-8")
    try:
        log(
            "start"
            + (" preflight" if args.preflight else "")
            + f" server={args.server} database={args.database}"
            + f" source={args.source_database} target={args.target_database}"
            + (f" source-server={args.source_server}" if args.source_server else "")
            + (f" target-server={args.target_server}" if args.target_server else "")
            + f" output={args.output}"
            + (f" max-detail-rows={args.max_detail_rows}" if args.max_detail_rows else "")
        )
        log(f"Loaded {len(jobs)} table(s) in {len(groups)} group(s) from {args.tables}")
        for group_name, group in groups:
            label = group_name or DEFAULT_GROUP_NAME
            log(f"  {label}: {', '.join(job.table_name for job in group)}")
        results = run_jobs(jobs, args, workbook)
        failed = sum(1 for result in results if result.status != "OK")
        differed = sum(1 for result in results if has_differences(result) == "Yes")
        code = run_exit_code(results, args.fail_on_diff)
        if failed:
            log(f"{failed} of {len(results)} table(s) failed.")
            print(f"{failed} of {len(results)} table(s) failed.", file=sys.stderr)
        if differed:
            log(f"{differed} of {len(results)} table(s) have differences.")
            if args.fail_on_diff and code == 3:
                print(f"{differed} of {len(results)} table(s) have differences.", file=sys.stderr)
        log(f"finished exit={code} log={log_path}")
        return code
    finally:
        _LOG_FILE.close()
        _LOG_FILE = None


if __name__ == "__main__":
    sys.exit(main())
