# DWH table comparison

Compares the same table in a source and target SQL Server database. It reports missing keys, value differences, matches, duplicate keys, and row counts.

It does not move data. There is no ETL or scheduler.

`SourceValue` comes from `@SourceDatabase`. `TargetValue` comes from `@TargetDatabase`.

## Install

Needs SQL Server 2016 SP1 or later, `SELECT` on both tables, and a utility database for the procedures.

```sql
IF DB_ID(N'DwhCompare') IS NULL
    CREATE DATABASE DwhCompare;
```

```bash
sqlcmd -S YourServer -d DwhCompare -i sql/install.sql
```

Or open [`sql/install.sql`](sql/install.sql) in SSMS and run it in `DwhCompare`.

For a list of tables, also install Python 3.9+, `pip install -r requirements.txt`, and a Microsoft SQL Server ODBC driver.

## Compare one table

```sql
EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName     = N'dbo',
    @TableName      = N'CUSTOMER',
    @KeyColumns     = N'CUSTOMER_ID';
```

More examples are in [`sql/examples.sql`](sql/examples.sql).

| Argument | Default | Purpose |
| --- | --- | --- |
| `@KeyColumns` | required | Business key. Comma-separated for a composite key. |
| `@ExcludedColumns` | none | Columns to skip. Keys cannot be excluded. |
| `@IncludedColumns` | none | If set, only these non-key columns are compared. Other common columns are `SKIPPED`. |
| `@ExcludePatterns` | none | Glob list to auto-exclude: `*_SRGT,CREATED_*,UPDATED_*`. A pattern that matches a key fails. |
| `@Output` | `ALL` | `ALL`, `DETAIL`, `DIFF`, `DUPLICATES`, `SUMMARY`, or `PREFLIGHT`. |
| `@IncludeMatches` | `1` | `0` hides `MATCH` rows. Summary still counts them. |
| `@IgnoreCase` | `0` | `1` ignores case on strings. Trailing spaces still differ. |
| `@IgnoreBlank` | `0` | `1` trims compared strings and treats NULL, empty, and whitespace-only text as equal. Keys stay exact. |
| `@Filter` | none | Same row slice on both sides, AND only: `STATUS = 'ACTIVE' AND LOAD_DATE >= '2026-01-01'`. |
| `@MaxDetailRows` | none | Cap detail rows. Summary counts stay complete. |
| `@SourceServer` / `@TargetServer` | local | Linked server name. Windows Authentication only. |

`PREFLIGHT` checks objects, keys, types, and the filter. It does not scan rows.

Helpers when you do not need a column diff: `dbo.CompareTableCounts` and `dbo.FindDuplicates`.

## Compare many tables

Put the list in CSV or Excel ([`python/tables.example.csv`](python/tables.example.csv)):

```csv
Group,TableName,KeyColumns,ExcludedColumns,ExcludePatterns,Filter
Party,DIM_COUNTRY,CTRY_COUNTRY_CODE,"CTRY_SRGT,CREATED_DATE_SRGT,UPDATED_DATE_SRGT,CTRY_SRE_REGION_NAME",,
Policy,FACT_PREMIUM,PREMIUM_BK,PREMIUM_SRGT,"*_SRGT,CREATED_*",LOAD_DATE >= '2026-01-01'
```

`ExcludedColumns` is the same named list as before. Quote it when it contains commas. `ExcludePatterns` is optional. You can use either column, or both.

`Group` / `Package` is optional. Each group becomes its own workbook. Blank group cells keep the previous name. `Table` / `Keys` / `Excluded` / `Where` also work as headers.

```bash
python python/compare_from_csv.py \
    --tables python/tables.example.csv \
    --server YourServer \
    --source-database DWH \
    --target-database DWH2 \
    --workbook runs/nightly \
    --workers 4
```

The same settings can live in YAML or JSON. See [Config file](#config-file).

```bash
python python/compare_from_csv.py --config python/compare.example.yaml
```

Uses Windows authentication by default. A `.log` is written next to the workbook.

`--workbook` is the Excel output. With groups it is a folder (`Party.xlsx`, `Policy.xlsx` inside). Without groups it is one `.xlsx` file.

A state folder is created next to that output so a later run can skip tables that already finished:

- folder `--workbook runs/nightly` → `runs/nightly/state`
- file `--workbook out.xlsx` → `out.state`

If a table fails or the process stops, continue with the same path:

```bash
python python/compare_from_csv.py \
    --tables python/tables.example.csv \
    --server YourServer \
    --source-database DWH \
    --target-database DWH2 \
    --resume runs/nightly \
    --workers 2
```

`--resume` uses that path as `--workbook`. Tables with status `OK` are skipped. `FAILED` tables and tables with no saved result run again. Compare settings (databases, `--preflight`, `--ignore-case`, `--ignore-blank`, and so on) must match the first run.

`--dry-run --resume PATH` prints `RUN` or `SKIP` for each table.

Excel stays the human report. To keep a queryable history in the utility database, add `--persist`. That writes `compare.Run` and `compare.RunTable`. Detail, duplicates, and schema rows are opt-in and can be large:

```bash
python python/compare_from_csv.py \
    --tables python/tables.example.csv \
    --server YourServer \
    --source-database DWH \
    --target-database DWH2 \
    --workbook runs/nightly \
    --persist \
    --persist-schema
```

| Switch | Purpose |
| --- | --- |
| `--config file` | YAML or JSON servers, databases, and defaults. Command-line flags override the file. |
| `--workbook path` | Output file, or a folder when the list has groups. |
| `--resume path` | Continue a previous run. Same path you passed to `--workbook`. |
| `--workers N` | Compare up to N tables at once. Default: 1. Large facts can fill tempdb. |
| `--persist` | Write `compare.Run` and `compare.RunTable`. Excel is still written. |
| `--persist-detail` | Also write `compare.RunDetail`. Implies `--persist`. |
| `--persist-duplicates` | Also write `compare.RunDuplicate`. Implies `--persist`. |
| `--persist-schema` | Also write `compare.RunSchema`. Implies `--persist`. |
| `--preflight` | Validate only. Writes `_Summary` and `_Schema`. |
| `--fail-on-diff` | Exit `3` if any table differs. |
| `--max-detail-rows N` | Keep at most N detail rows per table. |
| `--ignore-case` | Ignore string case. |
| `--ignore-blank` | Trim compared strings. NULL, empty, and spaces compare equal. Keys stay exact. |
| `--include-matches` | Keep `MATCH` rows on table sheets. |
| `--include-columns` | Default include-list for every table. CSV `IncludedColumns` overrides. |
| `--exclude-columns` | Default named exclude-list for every table. CSV `ExcludedColumns` overrides. |
| `--exclude-patterns` | Default auto-exclude globs, e.g. `*_SRGT,CREATED_*,UPDATED_*`. CSV `ExcludePatterns` overrides. |
| `--target-server NAME` | Linked target server. |
| `--dry-run` | Print the table list and exit. |

Exit codes: `0` ok, `1` bad list or resume mismatch, `2` a table failed, `3` differences (`--fail-on-diff`).

A failed table is marked `FAILED` on `_Summary`. The rest of the list still runs.

## Config file

`--config` accepts `.yaml`, `.yml`, or `.json`. Paths in the file are relative to the file. A flag on the command line overrides the file. `DWH_COMPARE_PASSWORD` supplies the password when the command line and the file leave it unset.

```yaml
server: YourServer
database: DwhCompare
source:
  database: DWH
target:
  database: DWH2
tables: tables.example.csv
defaults:
  workers: 4
  exclude_patterns: "*_SRGT,CREATED_*,UPDATED_*"
  fail_on_diff: true
```

`source.database` is `@SourceDatabase`. `source.server` is the linked server. The same names work at the top level (`source_database` or `source-database`). Unknown keys are an error. [`python/compare.example.yaml`](python/compare.example.yaml) is a full copy. The same keys work in JSON.

A flag set to true in the file stays on for every run that loads the file. Leave `preflight` out of a shared file. The pipeline passes `--preflight` only on the validation step.

## CI

[`.github/workflows/dwh-compare.yml`](.github/workflows/dwh-compare.yml) and [`ci/azure-pipelines.yml`](ci/azure-pipelines.yml) run two steps on a self-hosted agent that has the ODBC driver and can reach SQL Server:

1. `--preflight` checks objects, keys, types, and filters. Exit `2` stops the pipeline.
2. `--fail-on-diff` compares rows. Exit `3` stops the pipeline when any table differs.

Copy [`python/compare.example.yaml`](python/compare.example.yaml) to `compare.yaml`. The steps use different `--workbook` paths so both reports are kept. For a SQL login, store the password in `DWH_COMPARE_PASSWORD`. Windows authentication needs no password. The GitHub workflow stays on `workflow_dispatch` until the agent is ready. The Azure pipeline has `trigger: none`.

## Results

The workbook has `_Summary`, `_Schema` (column drift), `_Duplicates` when needed, and one sheet per table. `--persist` also writes that summary to `compare.Run` and `compare.RunTable` in the utility database. Optional `--persist-detail`, `--persist-duplicates`, and `--persist-schema` fill the matching child tables.

| Status | Meaning |
| --- | --- |
| `MATCH` | Key exists on both sides and compared columns match. |
| `ONLY_IN_SOURCE` / `ONLY_IN_TARGET` | Key exists on one side only. |
| `VALUE_MISMATCH` | Same key, different column value. One row per different column. |
| `DUPLICATE_SOURCE` / `DUPLICATE_TARGET` | Business key is not unique. |

`ValueMismatch` counts keys, not columns. Duplicate keys are dropped from the join and appear only under duplicates. Composite keys look like `P1 | L1`. NULL is shown as `<NULL>`.

A missing column on one side is not a value mismatch. Check `_Schema` before treating `HasDifferences = No` as a full sign-off.

`ALL` returns detail, duplicates, summary, then schema. `INSERT...EXEC` with `DETAIL`, `DIFF`, `DUPLICATES`, or `SUMMARY` still returns one result set.

## Rules

- NULL equals NULL. `Ann` and `Ann ` differ unless `@IgnoreBlank = 1`, which trims compared strings and treats NULL, empty, and spaces as equal. A blank key still does not match a NULL key.
- Integers can mix widths. `decimal` / `numeric` match across scale (`10.50` = `10.5000`). Other types must match.
- Exclude `geography`, `geometry`, `hierarchyid`, and `sql_variant`. Views are not compared.
- Run when both sides are quiet, or use snapshot isolation. This is not one snapshot across two databases.
- Another instance needs a SQL Server linked server, data access, and `@useself = 'true'`. SQL Authentication is not supported.

## Test

```bash
sqlcmd -S YourServer -d DwhCompare -b -i sql/test.sql
python -m unittest discover -s python
```

[`sql/teardown.sql`](sql/teardown.sql) drops the two test databases. Tested on SQL Server 2022.
