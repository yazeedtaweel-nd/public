# DWH table comparison

A small SQL Server framework that compares one table in a source database with the same table in a target database. It reports missing keys, value differences, exact matches, duplicate business keys, and row counts.

It does not move data. There is no ETL, sync, or scheduling.

`SourceValue` is the value from `@SourceDatabase` (DWH in the examples). `TargetValue` is the value from `@TargetDatabase` (DWH2). The names stay stable when the database names change.

## Requirements

- SQL Server 2016 SP1 or later
- A utility database to hold the procedures (they do not need to live in DWH or DWH2)
- `SELECT` on both tables for the login that runs the comparison
- A user mapping in both databases. Cross-database ownership chaining is not required.

## Deploy

Create a utility database, then run [`sql/install.sql`](sql/install.sql) in it.

```sql
IF DB_ID(N'DwhCompare') IS NULL
    CREATE DATABASE DwhCompare;
GO
USE DwhCompare;
GO
```

```bash
sqlcmd -S YourServer -d DwhCompare -i sql/install.sql
```

In SSMS, open `sql/install.sql` and execute it against `DwhCompare`.

Optional:

```sql
GRANT EXECUTE ON dbo.CompareTables TO YourReader;
GRANT EXECUTE ON dbo.FindDuplicates TO YourReader;
GRANT EXECUTE ON dbo.CompareTableCounts TO YourReader;
```

## Calls

```sql
EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID';

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'POLICY_LIMIT',
    @KeyColumns = N'POLICY_BK,LIMIT_BK';

EXEC dbo.CompareTables
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @ExcludedColumns = N'CREATED_DATE,UPDATED_DATE';
```

The same calls are in [`sql/examples.sql`](sql/examples.sql). They run only when `DWH` and `DWH2` exist on the instance.

Optional arguments:

| Argument | Default | Purpose |
| --- | --- | --- |
| `@ExcludedColumns` | none | Comma-separated columns to skip. Keys cannot be excluded. |
| `@IncludeMatches` | `1` | `0` omits `MATCH` rows from the detail. The summary still counts them. |
| `@Output` | `ALL` | `ALL`, `DETAIL`, `DUPLICATES`, or `SUMMARY`. Use a single section when inserting the result into a table. |
| `@Debug` | `0` | Prints the generated batch. |

`ALL` returns three result sets, in this order:

1. Comparison detail
2. Duplicate keys
3. Summary

Fast helpers, when you do not need a column diff:

```sql
EXEC dbo.CompareTableCounts
    @SourceDatabase = N'DWH',
    @TargetDatabase = N'DWH2',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER';

EXEC dbo.FindDuplicates
    @DatabaseName = N'DWH',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID';
```

`CompareTableCounts` is only `COUNT(*)` on each table. Matching-row and mismatch counts come from `CompareTables`, because they require the key join.

## Result shape

Comparison detail:

| Table | Key | Status | Column | SourceValue | TargetValue |
| --- | --- | --- | --- | --- | --- |
| CUSTOMER | 1001 | MATCH | | | |
| CUSTOMER | 1002 | ONLY_IN_SOURCE | | | |
| CUSTOMER | 1003 | ONLY_IN_TARGET | | | |
| CUSTOMER | 1004 | VALUE_MISMATCH | FEE | 1.2500 | 9.0000 |
| CUSTOMER | 1004 | VALUE_MISMATCH | NAME | Ahmed | Ahmad |
| CUSTOMER | 1004 | VALUE_MISMATCH | STATUS | ACTIVE | INACTIVE |
| CUSTOMER | 1006 | VALUE_MISMATCH | NAME | | Hana |
| CUSTOMER | 1010 | VALUE_MISMATCH | NAME | Ann | Ann |

`1010` differs by a trailing space on the target (`Ann` versus `Ann `). Blank `SourceValue` on key `1006` is NULL, not an empty string. Mismatch columns are listed in name order. Composite keys are shown as `P1 | L1`. A NULL key part is shown as `<NULL>`.

Duplicate keys:

| Table | Key | Status | RecordCount |
| --- | --- | --- | --- |
| CUSTOMER | 1007 | DUPLICATE_SOURCE | 2 |
| CUSTOMER | 1009 | DUPLICATE_TARGET | 2 |

Summary:

| Table | SourceRowCount | TargetRowCount | CountDifference | MatchingRows | OnlyInSource | OnlyInTarget | ValueMismatch | DuplicateSourceKeys | DuplicateTargetKeys |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CUSTOMER | 9 | 9 | 0 | 3 | 1 | 1 | 3 | 1 | 1 |

`ValueMismatch` counts distinct keys, not differing columns. Key `1004` is one mismatched key and three detail rows.

Duplicate keys are removed before the join, so they appear only in the duplicate result. A duplicated key is not also counted as `ONLY_IN_SOURCE` or `VALUE_MISMATCH`. For the rows that remain:

```text
MatchingRows + OnlyInSource + ValueMismatch = distinct source keys that occur once
MatchingRows + OnlyInTarget + ValueMismatch = distinct target keys that occur once
```

`SourceRowCount` and `TargetRowCount` include every physical row, duplicates included.

Messages (not result sets) name the columns being compared, the columns that exist on only one side, and any excluded columns.

## How the dynamic SQL works

`CompareTables` does not trust the text you pass as an identifier.

1. Database, schema, and table names are looked up in `sys.databases`, `sys.schemas`, and `sys.tables`. The lookup parameters are passed to `sp_executesql`. The name that is concatenated later is the name returned by the catalog, wrapped in `QUOTENAME`.
2. Key and excluded names are split, then matched to `sys.columns`. Only a column that exists is quoted into the batch. A missing name, a repeated name, or an incompatible type raises a clear error before the comparison batch runs.
3. The procedure reads `sys.columns` and `sys.types` from both databases and keeps the columns that exist on both sides, minus keys and `@ExcludedColumns`.
4. It builds one batch that:
   - scans each table once and writes a narrow temp table of business keys plus two SHA-256 hashes
   - aggregates duplicate keys from that temp table
   - full-outer-joins the remaining keys
   - for `VALUE_MISMATCH` only, joins back to the base tables and unpivots each column
5. `@Output`, `@IncludeMatches`, and the result table name are parameters of `sp_executesql`. They are not pasted into the SQL text.

`@Debug = 1` prints that batch. Validation errors are `THROW 50001` with a message such as `Key column 'CUSTOMER_ID' does not exist in the target table.` or `Column 'QTY' is not compatible. Source type: varchar(20). Target type: int.`

## Performance

Large tables are not compared cell by cell.

**Stage 1.** Each row is reduced to its business key and a SHA-256 of the other columns. NULL becomes 33 zero bytes. Any other value becomes `0x01` plus the SHA-256 of a canonical representation (so NULL and `''` do not collide, and a delimiter inside a string cannot shift the next column). Those fingerprints are concatenated as `varbinary(max)` and hashed again. `CHECKSUM` is not used. If the two row hashes are equal, the key is `MATCH` and the column values are not read again.

**Stage 2.** Only keys whose hashes differ are joined back to the source and target tables. Each compared column is tested with a `NULL`-safe expression, and one result row is returned per different column.

Duplicate detection groups the stage-1 key set. It does not scan the base tables a second time.

The stage-1 tables live in `tempdb`: about one row per source row and one per target row, each holding the key plus 64 bytes of hash. An index on the business key of the real table helps the stage-2 lookup when many keys differ.

The read runs under the session's isolation level, normally read committed. It is not one snapshot across two databases. If the tables are being loaded during the run, run it when both sides are quiet, or enable snapshot isolation on the session first if both databases allow it.

## Comparison rules

- NULL equals NULL. NULL does not equal a value.
- Strings are exact, including trailing spaces. `Ann` and `Ann ` differ. `varchar` and `nvarchar` of the same text still match.
- `tinyint`, `smallint`, `int`, and `bigint` can be compared with each other. `decimal` and `numeric` can be compared across precision and scale (`10.50` matches `10.5000`, `101.00` does not match `110.0000`). `money` and `smallmoney` can be compared with each other.
- `char` / `varchar` / `nchar` / `nvarchar` / `text` / `ntext` can be compared with each other.
- Other types must be the same type. `datetime2`, `time`, and `datetimeoffset` must also use the same scale. `binary` and `varbinary` must be the same length. `datetime` is not treated as `datetime2`.
- `geography`, `geometry`, `hierarchyid`, and `sql_variant` are rejected unless excluded.
- Columns that exist on only one side are skipped and named in a message.
- Views are not compared. The object must be a table.
- A SHA-256 collision could theoretically hide a difference. That is not a practical risk, and a hash match is the equality test for the row. Column output is produced only when the hashes differ.

## Test

[`sql/test.sql`](sql/test.sql) creates `DwhCompare_Src` and `DwhCompare_Tgt` and checks:

- matching rows, including NULL equals NULL
- source-only and target-only keys
- column-level mismatches, including NULL versus a value and a trailing space
- excluded audit columns
- duplicate keys on either side
- composite keys, including a NULL key part
- decimal scale differences, including values that must stay distinct (`101` versus `110`)
- `int` versus `bigint` keys
- incompatible types, missing objects, and identifier injection

Run it from the utility database after install:

```bash
sqlcmd -S YourServer -d DwhCompare -b -i sql/test.sql
```

It throws if a result is wrong and prints `All comparison framework tests passed.` when it is not. [`sql/teardown.sql`](sql/teardown.sql) drops the two test databases.

These tests were run against SQL Server 2022.
