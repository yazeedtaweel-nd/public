import tempfile
import unittest
from pathlib import Path

from compare_from_csv import (
    TableJob,
    TableResult,
    classify_result_set,
    excel_sheet_name,
    map_row,
    read_table_list,
    write_workbook,
)


class ReadTableListTests(unittest.TestCase):
    def test_reads_csv_aliases_and_skips_comments(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Table,Keys,Excluded\n"
                "# ignored,x,y\n"
                "DIM_COUNTRY,CTRY_COUNTRY_CODE,\"CTRY_SRGT,CREATED_DATE_SRGT\"\n"
                "\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].table_name, "DIM_COUNTRY")
        self.assertEqual(jobs[0].key_columns, "CTRY_COUNTRY_CODE")
        self.assertEqual(jobs[0].excluded_columns, "CTRY_SRGT,CREATED_DATE_SRGT")

    def test_utf8_bom_and_optional_schema(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_bytes(
                b"\xef\xbb\xbfTableName,KeyColumns,SchemaName\n"
                b"DIM_USER,USER_BK,mart\n"
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].schema_name, "mart")

    def test_missing_key_columns_raises(self) -> None:
        with self.assertRaisesRegex(ValueError, "KeyColumns"):
            map_row(["TableName", "KeyColumns"], ["DIM_COUNTRY", ""], 2)


class SheetNameTests(unittest.TestCase):
    def test_truncates_and_avoids_collisions(self) -> None:
        used: set[str] = set()
        first = excel_sheet_name("DIM_POLICY_COVERAGE_LIMIT_DETAIL", used)
        second = excel_sheet_name("DIM_POLICY_COVERAGE_LIMIT_DETAIL", used)
        self.assertEqual(first, "DIM_POLICY_COVERAGE_LIMIT_DETAI")
        self.assertEqual(len(first), 31)
        self.assertEqual(second, "DIM_POLICY_COVERAGE_LIMIT_DET_2")
        self.assertLessEqual(len(second), 31)

    def test_replaces_invalid_characters(self) -> None:
        used: set[str] = set()
        self.assertEqual(excel_sheet_name("FACT[CLAIM]/2024", used), "FACT_CLAIM__2024")


class ClassifyTests(unittest.TestCase):
    def test_classifies_procedure_result_sets(self) -> None:
        self.assertEqual(
            classify_result_set(["Table", "Key", "Status", "Column", "SourceValue", "TargetValue"]),
            "detail",
        )
        self.assertEqual(
            classify_result_set(["Table", "Key", "Status", "RecordCount"]),
            "duplicates",
        )
        self.assertEqual(
            classify_result_set(["Table", "SourceRowCount", "TargetRowCount", "MatchingRows"]),
            "summary",
        )


class WorkbookTests(unittest.TestCase):
    def test_writes_summary_first_and_one_sheet_per_table(self) -> None:
        results = [
            TableResult(
                job=TableJob("DIM_COUNTRY", "CTRY_COUNTRY_CODE"),
                status="OK",
                schema_name="dbo",
                detail_rows=[
                    ("DIM_COUNTRY", "SA", "ONLY_IN_SOURCE", None, None, None),
                ],
                duplicate_rows=[("DIM_COUNTRY", "XX", "DUPLICATE_SOURCE", 2)],
                summary={"SourceRowCount": 10, "TargetRowCount": 9, "OnlyInSource": 1, "ValueMismatch": 0},
            ),
            TableResult(
                job=TableJob("DIM_USER", "USER_BK"),
                status="FAILED",
                schema_name="dbo",
                error="Key column 'USER_BK' does not exist in the target table.",
            ),
        ]

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "out.xlsx"
            write_workbook(path, results)
            from openpyxl import load_workbook

            workbook = load_workbook(path)
            self.assertEqual(workbook.sheetnames[0], "_Summary")
            self.assertEqual(workbook.sheetnames[1], "_Duplicates")
            self.assertIn("DIM_COUNTRY", workbook.sheetnames)
            self.assertNotIn("DIM_USER", workbook.sheetnames)
            self.assertEqual(workbook["_Summary"]["A2"].value, "DIM_COUNTRY")
            self.assertEqual(workbook["_Summary"]["E2"].value, "OK")
            self.assertEqual(workbook["_Summary"]["A3"].value, "DIM_USER")
            self.assertEqual(workbook["_Summary"]["E3"].value, "FAILED")
            workbook.close()


if __name__ == "__main__":
    unittest.main()
