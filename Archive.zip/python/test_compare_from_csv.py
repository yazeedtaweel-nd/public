from __future__ import annotations

import tempfile
import time
import unittest
from pathlib import Path

from compare_from_csv import (
    PersistError,
    ResumeError,
    SqlRunStore,
    TableJob,
    TableResult,
    classify_result_set,
    excel_sheet_name,
    group_jobs,
    grouped_workbook_path,
    has_differences,
    job_id,
    load_ok_result,
    map_row,
    parse_args,
    persist_enabled,
    persist_table_result,
    read_table_list,
    resolve_log_path,
    resolve_state_dir,
    resolve_workbook_base,
    run_exit_code,
    run_jobs,
    settings_mismatch_message,
    write_result_workbooks,
    write_workbook,
)


class ReadTableListTests(unittest.TestCase):
    def test_reads_csv_aliases_and_skips_comments(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Table,Keys,Excluded\n"
                "# ignored,x,y\n"
                "DIM_COUNTRY,CTRY_COUNTRY_CODE,\"CTRY_SRGT,CREATED_DATE_SRGT\"\n"
                "\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(len(jobs), 1)
        self.assertEqual(jobs[0].table_name, "DIM_COUNTRY")
        self.assertEqual(jobs[0].key_columns, "CTRY_COUNTRY_CODE")
        self.assertEqual(jobs[0].excluded_columns, "CTRY_SRGT,CREATED_DATE_SRGT")
        self.assertIsNone(jobs[0].ignore_case)

    def test_reads_group_and_package_aliases(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Group,TableName,KeyColumns\n"
                "Party,DIM_PARTY,PARTY_BK\n"
                "Policy,DIM_POLICY,POLICY_BK\n"
                ",DIM_COUNTRY,CTRY_COUNTRY_CODE\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].group_name, "Party")
        self.assertEqual(jobs[1].group_name, "Policy")
        self.assertEqual(jobs[2].group_name, "Policy")

    def test_fills_blank_group_and_collects_scattered_package_rows(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "Title row to ignore\n"
                "Group,TableName,KeyColumns\n"
                "Party,DIM_PARTY,PARTY_BK\n"
                ",DIM_PARTY_ROLE,ROLE_BK\n"
                "Policy,DIM_POLICY,POLICY_BK\n"
                "Party,DIM_CONTACT,CONTACT_BK\n"
                ",DIM_ADDRESS,ADDR_BK\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(
            [job.table_name for job in jobs],
            ["DIM_PARTY", "DIM_PARTY_ROLE", "DIM_POLICY", "DIM_CONTACT", "DIM_ADDRESS"],
        )
        self.assertEqual(jobs[0].group_name, "Party")
        self.assertEqual(jobs[1].group_name, "Party")
        self.assertEqual(jobs[2].group_name, "Policy")
        self.assertEqual(jobs[3].group_name, "Party")
        self.assertEqual(jobs[4].group_name, "Party")

        groups = group_jobs(jobs)
        self.assertEqual([name for name, _ in groups], ["Party", "Policy"])
        self.assertEqual(
            [job.table_name for job in groups[0][1]],
            ["DIM_PARTY", "DIM_PARTY_ROLE", "DIM_CONTACT", "DIM_ADDRESS"],
        )

    def test_unnamed_first_column_is_group(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                ",TableName,KeyColumns\n"
                "Party,DIM_PARTY,PARTY_BK\n"
                ",DIM_PARTY_ROLE,ROLE_BK\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].group_name, "Party")
        self.assertEqual(jobs[1].group_name, "Party")

    def test_reads_excel_groups_from_all_sheets(self) -> None:
        from openpyxl import Workbook

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.xlsx"
            workbook = Workbook()
            party = workbook.active
            party.title = "Party"
            party.append(["TableName", "KeyColumns"])
            party.append(["DIM_PARTY", "PARTY_BK"])
            party.append(["DIM_PARTY_ROLE", "ROLE_BK"])
            policy = workbook.create_sheet("Policy")
            policy.append(["TableName", "KeyColumns"])
            policy.append(["DIM_POLICY", "POLICY_BK"])
            workbook.save(path)
            workbook.close()
            jobs = read_table_list(path)

        self.assertEqual([job.group_name for job in jobs], ["Party", "Party", "Policy"])
        self.assertEqual(
            [job.table_name for job in jobs],
            ["DIM_PARTY", "DIM_PARTY_ROLE", "DIM_POLICY"],
        )

    def test_reads_ignore_case_flag(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "TableName,KeyColumns,IgnoreCase\n"
                "DIM_COUNTRY,CTRY_COUNTRY_CODE,1\n"
                "DIM_USER,USER_BK,0\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertTrue(jobs[0].ignore_case)
        self.assertFalse(jobs[1].ignore_case)

    def test_reads_filter_alias(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text(
                "TableName,KeyColumns,Where\n"
                "FACT_PREMIUM,PREMIUM_BK,LOAD_DATE >= '2026-01-01'\n",
                encoding="utf-8",
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].row_filter, "LOAD_DATE >= '2026-01-01'")

    def test_utf8_bom_and_optional_schema(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_bytes(
                b"\xef\xbb\xbfTableName,KeyColumns,SchemaName\n"
                b"DIM_USER,USER_BK,mart\n"
            )
            jobs = read_table_list(path)

        self.assertEqual(jobs[0].schema_name, "mart")

    def test_missing_key_columns_raises(self) -> None:
        with self.assertRaisesRegex(ValueError, "KeyColumns"):
            map_row(["TableName", "KeyColumns"], ["DIM_COUNTRY", ""], 2)


class SheetNameTests(unittest.TestCase):
    def test_truncates_and_avoids_collisions(self) -> None:
        used: set[str] = set()
        first = excel_sheet_name("DIM_POLICY_COVERAGE_LIMIT_DETAIL", used)
        second = excel_sheet_name("DIM_POLICY_COVERAGE_LIMIT_DETAIL", used)
        self.assertEqual(first, "DIM_POLICY_COVERAGE_LIMIT_DETAI")
        self.assertEqual(len(first), 31)
        self.assertEqual(second, "DIM_POLICY_COVERAGE_LIMIT_DET_2")
        self.assertLessEqual(len(second), 31)

    def test_replaces_invalid_characters(self) -> None:
        used: set[str] = set()
        self.assertEqual(excel_sheet_name("FACT[CLAIM]/2024", used), "FACT_CLAIM__2024")


class ClassifyTests(unittest.TestCase):
    def test_classifies_procedure_result_sets(self) -> None:
        self.assertEqual(
            classify_result_set(["Table", "Key", "Status", "Column", "SourceValue", "TargetValue"]),
            "detail",
        )
        self.assertEqual(
            classify_result_set(["Table", "Key", "Status", "RecordCount"]),
            "duplicates",
        )
        self.assertEqual(
            classify_result_set(["Table", "SourceRowCount", "TargetRowCount", "MatchingRows"]),
            "summary",
        )
        self.assertEqual(
            classify_result_set(["Table", "Column", "Side", "Role", "SourceType", "TargetType"]),
            "schema",
        )


class WorkbookTests(unittest.TestCase):
    def test_writes_summary_first_and_one_sheet_per_table(self) -> None:
        results = [
            TableResult(
                job=TableJob("DIM_COUNTRY", "CTRY_COUNTRY_CODE"),
                status="OK",
                schema_name="dbo",
                detail_rows=[
                    ("DIM_COUNTRY", "SA", "ONLY_IN_SOURCE", None, None, None),
                ],
                duplicate_rows=[("DIM_COUNTRY", "XX", "DUPLICATE_SOURCE", 2)],
                summary={"SourceRowCount": 10, "TargetRowCount": 9, "OnlyInSource": 1, "ValueMismatch": 0},
            ),
            TableResult(
                job=TableJob("DIM_USER", "USER_BK"),
                status="FAILED",
                schema_name="dbo",
                error="Key column 'USER_BK' does not exist in the target table.",
            ),
        ]

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "out.xlsx"
            write_workbook(path, results)
            from openpyxl import load_workbook

            workbook = load_workbook(path)
            self.assertEqual(workbook.sheetnames[0], "_Summary")
            self.assertEqual(workbook.sheetnames[1], "_Duplicates")
            self.assertIn("DIM_COUNTRY", workbook.sheetnames)
            self.assertNotIn("DIM_USER", workbook.sheetnames)
            self.assertEqual(workbook["_Summary"]["A1"].value, "Group")
            self.assertEqual(workbook["_Summary"]["F1"].value, "Filter")
            self.assertIsNone(workbook["_Summary"]["A2"].value)
            self.assertEqual(workbook["_Summary"]["B2"].value, "DIM_COUNTRY")
            self.assertEqual(workbook["_Summary"]["G2"].value, "OK")
            self.assertEqual(workbook["_Summary"]["B3"].value, "DIM_USER")
            self.assertEqual(workbook["_Summary"]["G3"].value, "FAILED")
            workbook.close()

    def test_writes_schema_sheet_and_skips_preflight_detail(self) -> None:
        results = [
            TableResult(
                job=TableJob("DIM_COUNTRY", "CTRY_COUNTRY_CODE", row_filter="CODE = 'SA'"),
                status="OK",
                schema_name="dbo",
                output="PREFLIGHT",
                schema_rows=[
                    ("DIM_COUNTRY", "CODE", "BOTH", "KEY", "varchar(2)", "varchar(2)"),
                    ("DIM_COUNTRY", "NOTES", "SOURCE_ONLY", "SOURCE_ONLY", "varchar(100)", None),
                ],
            ),
        ]

        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "out.xlsx"
            write_workbook(path, results)
            from openpyxl import load_workbook

            workbook = load_workbook(path)
            self.assertEqual(workbook.sheetnames[0], "_Summary")
            self.assertEqual(workbook.sheetnames[1], "_Schema")
            self.assertNotIn("DIM_COUNTRY", workbook.sheetnames)
            self.assertEqual(workbook["_Summary"]["F2"].value, "CODE = 'SA'")
            self.assertEqual(workbook["_Summary"]["H2"].value, "Preflight")
            self.assertEqual(workbook["_Schema"]["A2"].value, "DIM_COUNTRY")
            self.assertEqual(workbook["_Schema"]["C3"].value, "SOURCE_ONLY")
            workbook.close()


class GroupJobsTests(unittest.TestCase):
    def test_batches_interleaved_rows_in_first_seen_order(self) -> None:
        jobs = [
            TableJob("DIM_PARTY", "PARTY_BK", group_name="Party"),
            TableJob("DIM_POLICY", "POLICY_BK", group_name="Policy"),
            TableJob("DIM_PARTY_ROLE", "ROLE_BK", group_name="party"),
        ]

        groups = group_jobs(jobs)

        self.assertEqual([name for name, _ in groups], ["Party", "Policy"])
        self.assertEqual(
            [job.table_name for job in groups[0][1]],
            ["DIM_PARTY", "DIM_PARTY_ROLE"],
        )
        self.assertEqual([job.table_name for job in groups[1][1]], ["DIM_POLICY"])


class GroupedWorkbookTests(unittest.TestCase):
    def test_grouped_path_uses_group_name(self) -> None:
        self.assertEqual(
            grouped_workbook_path(Path("compare-results.xlsx"), "Party", True),
            Path("Party.xlsx"),
        )
        self.assertEqual(
            grouped_workbook_path(Path("output"), "Party", True),
            Path("output") / "Party.xlsx",
        )
        self.assertEqual(
            grouped_workbook_path(Path("out.xlsx"), None, False),
            Path("out.xlsx"),
        )

    def test_resolve_workbook_base_uses_folder_when_grouped(self) -> None:
        self.assertEqual(resolve_workbook_base(None, True), Path("."))
        self.assertEqual(resolve_workbook_base(Path("results"), True), Path("results"))
        self.assertEqual(resolve_workbook_base(Path("out.xlsx"), True), Path("out.xlsx"))
        self.assertEqual(resolve_workbook_base(Path("out"), False), Path("out.xlsx"))

    def test_writes_one_workbook_per_group(self) -> None:
        results = [
            TableResult(
                job=TableJob("DIM_PARTY", "PARTY_BK", group_name="Party"),
                status="OK",
                schema_name="dbo",
                detail_rows=[("DIM_PARTY", "1", "ONLY_IN_SOURCE", None, None, None)],
            ),
            TableResult(
                job=TableJob("DIM_PARTY_ROLE", "ROLE_BK", group_name="party"),
                status="OK",
                schema_name="dbo",
                detail_rows=[("DIM_PARTY_ROLE", "2", "ONLY_IN_TARGET", None, None, None)],
            ),
            TableResult(
                job=TableJob("DIM_POLICY", "POLICY_BK", group_name="Policy"),
                status="OK",
                schema_name="dbo",
                detail_rows=[("DIM_POLICY", "3", "VALUE_MISMATCH", "FEE", "1", "2")],
            ),
        ]

        with tempfile.TemporaryDirectory() as folder:
            paths = write_result_workbooks(Path(folder), results)
            from openpyxl import load_workbook

            self.assertEqual([path.name for path in paths], ["Party.xlsx", "Policy.xlsx"])

            party = load_workbook(paths[0])
            self.assertEqual(party.sheetnames[0], "_Summary")
            self.assertIn("DIM_PARTY", party.sheetnames)
            self.assertIn("DIM_PARTY_ROLE", party.sheetnames)
            self.assertNotIn("DIM_POLICY", party.sheetnames)
            self.assertEqual(party["_Summary"]["A2"].value, "Party")
            self.assertEqual(party["_Summary"]["B2"].value, "DIM_PARTY")
            self.assertEqual(party["_Summary"]["A3"].value, "party")
            self.assertEqual(party["_Summary"]["B3"].value, "DIM_PARTY_ROLE")
            party.close()

            policy = load_workbook(paths[1])
            self.assertIn("DIM_POLICY", policy.sheetnames)
            self.assertNotIn("DIM_PARTY", policy.sheetnames)
            policy.close()


class ExitCodeTests(unittest.TestCase):
    def test_fail_on_diff_uses_existing_difference_flag(self) -> None:
        ok = TableResult(job=TableJob("A", "K"), status="OK", summary={"OnlyInSource": 0, "ValueMismatch": 0})
        diff = TableResult(job=TableJob("B", "K"), status="OK", summary={"OnlyInSource": 1, "ValueMismatch": 0})
        failed = TableResult(job=TableJob("C", "K"), status="FAILED", error="missing key")
        preflight = TableResult(job=TableJob("D", "K"), status="OK", output="PREFLIGHT", schema_rows=[("D", "K", "BOTH", "KEY", "int", "int")])

        self.assertEqual(has_differences(ok), "No")
        self.assertEqual(has_differences(diff), "Yes")
        self.assertEqual(has_differences(failed), "Unknown")
        self.assertEqual(has_differences(preflight), "Preflight")
        self.assertEqual(run_exit_code([ok], True), 0)
        self.assertEqual(run_exit_code([ok, diff], False), 0)
        self.assertEqual(run_exit_code([ok, diff], True), 3)
        self.assertEqual(run_exit_code([failed, diff], True), 2)
        self.assertEqual(run_exit_code([preflight], True), 0)


class CliTests(unittest.TestCase):
    def test_parses_new_switches(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text("TableName,KeyColumns\nDIM_USER,USER_BK\n", encoding="utf-8")
            args = parse_args(
                [
                    "--tables",
                    str(path),
                    "--server",
                    "localhost",
                    "--source-database",
                    "DWH",
                    "--target-database",
                    "DWH2",
                    "--preflight",
                    "--fail-on-diff",
                    "--max-detail-rows",
                    "5000",
                    "--log",
                    str(Path(folder) / "run.log"),
                ]
            )

        self.assertTrue(args.preflight)
        self.assertTrue(args.fail_on_diff)
        self.assertEqual(args.max_detail_rows, 5000)
        self.assertEqual(args.workers, 1)
        self.assertIsNone(args.resume)

    def test_rejects_non_positive_max_detail_rows(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text("TableName,KeyColumns\nDIM_USER,USER_BK\n", encoding="utf-8")
            with self.assertRaises(SystemExit):
                parse_args(
                    [
                        "--tables",
                        str(path),
                        "--server",
                        "localhost",
                        "--source-database",
                        "DWH",
                        "--target-database",
                        "DWH2",
                        "--max-detail-rows",
                        "0",
                    ]
                )

    def test_log_path_follows_workbook(self) -> None:
        self.assertEqual(
            resolve_log_path(None, Path("out.xlsx"), False),
            Path("out.log"),
        )
        self.assertEqual(
            resolve_log_path(Path("custom.log"), Path("out.xlsx"), False),
            Path("custom.log"),
        )

    def test_resume_fills_workbook_and_rejects_zero_workers(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text("TableName,KeyColumns\nDIM_USER,USER_BK\n", encoding="utf-8")
            args = parse_args(
                [
                    "--tables",
                    str(path),
                    "--server",
                    "localhost",
                    "--source-database",
                    "DWH",
                    "--target-database",
                    "DWH2",
                    "--resume",
                    str(Path(folder) / "nightly"),
                    "--workers",
                    "4",
                ]
            )
            self.assertEqual(args.resume, Path(folder) / "nightly")
            self.assertEqual(args.workbook, Path(folder) / "nightly")
            self.assertEqual(args.workers, 4)
            with self.assertRaises(SystemExit):
                parse_args(
                    [
                        "--tables",
                        str(path),
                        "--server",
                        "localhost",
                        "--source-database",
                        "DWH",
                        "--target-database",
                        "DWH2",
                        "--workers",
                        "0",
                    ]
                )


def _cli_args(folder: Path, **overrides: object):
    tables = folder / "tables.csv"
    if not tables.exists():
        tables.write_text("TableName,KeyColumns\nDIM_USER,USER_BK\n", encoding="utf-8")
    args = parse_args(
        [
            "--tables",
            str(tables),
            "--server",
            "localhost",
            "--source-database",
            "DWH",
            "--target-database",
            "DWH2",
        ]
    )
    for key, value in overrides.items():
        setattr(args, key, value)
    return args


def _ok_result(job: TableJob, status: str = "OK") -> TableResult:
    return TableResult(
        job=job,
        status=status,
        schema_name=job.schema_name or "dbo",
        output="ALL",
        detail_rows=[(job.table_name, "1", "ONLY_IN_SOURCE", None, None, None)] if status == "OK" else [],
        summary={"OnlyInSource": 1, "ValueMismatch": 0} if status == "OK" else {},
        error=None if status == "OK" else "boom",
    )


class StateDirTests(unittest.TestCase):
    def test_state_lives_next_to_the_workbook(self) -> None:
        self.assertEqual(resolve_state_dir(Path("out.xlsx")), Path("out.state"))
        self.assertEqual(resolve_state_dir(Path("runs") / "nightly"), Path("runs") / "nightly" / "state")

    def test_job_id_changes_when_keys_or_filter_change(self) -> None:
        base = TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")
        self.assertNotEqual(job_id(base, "dbo"), job_id(TableJob("DIM_PARTY", "OTHER_BK", group_name="Party"), "dbo"))
        self.assertNotEqual(
            job_id(base, "dbo"),
            job_id(TableJob("DIM_PARTY", "PARTY_BK", group_name="Party", row_filter="X = 1"), "dbo"),
        )
        self.assertEqual(job_id(base, "dbo"), job_id(TableJob("DIM_PARTY", "PARTY_BK", group_name="Party"), "dbo"))

    def test_persist_roundtrip_and_failed_is_not_skippable(self) -> None:
        job = TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")
        with tempfile.TemporaryDirectory() as folder:
            job_dir = Path(folder) / "job"
            persist_table_result(job_dir, _ok_result(job), "dbo")
            loaded = load_ok_result(job_dir, job, "dbo")
            self.assertIsNotNone(loaded)
            assert loaded is not None
            self.assertTrue(loaded.skipped)
            self.assertEqual(loaded.detail_rows[0][0], "DIM_PARTY")
            self.assertEqual(loaded.summary.get("OnlyInSource"), 1)

            persist_table_result(job_dir, _ok_result(job, "FAILED"), "dbo")
            self.assertIsNone(load_ok_result(job_dir, job, "dbo"))

    def test_settings_mismatch_lists_changed_fields(self) -> None:
        saved = {
            "source_database": "DWH",
            "target_database": "DWH2",
            "source_server": "",
            "target_server": "",
            "preflight": False,
            "output": "ALL",
            "ignore_case": False,
            "include_matches": False,
            "max_detail_rows": None,
            "schema": "dbo",
        }
        current = dict(saved)
        current["target_database"] = "OTHER"
        current["preflight"] = True
        message = settings_mismatch_message(saved, current)
        self.assertIsNotNone(message)
        assert message is not None
        self.assertIn("target_database", message)
        self.assertIn("preflight", message)


class ResumeAndWorkersTests(unittest.TestCase):
    def test_resume_skips_ok_and_reruns_failed(self) -> None:
        jobs = [
            TableJob("OK_TABLE", "K", group_name="Party"),
            TableJob("FAIL_TABLE", "K", group_name="Party"),
        ]
        calls: list[str] = []

        def execute(job: TableJob, args: object) -> TableResult:
            calls.append(job.table_name)
            if job.table_name == "FAIL_TABLE":
                return _ok_result(job, "FAILED")
            return _ok_result(job)

        with tempfile.TemporaryDirectory() as folder:
            workbook = resolve_workbook_base(Path(folder) / "nightly", True)
            args = _cli_args(Path(folder), resume=None, workers=1)
            first = run_jobs(jobs, args, workbook, execute=execute)
            self.assertEqual(calls, ["OK_TABLE", "FAIL_TABLE"])
            self.assertEqual([result.status for result in first], ["OK", "FAILED"])
            self.assertTrue((workbook / "state" / "run.json").exists())
            self.assertTrue((workbook / "Party.xlsx").exists())

            calls.clear()
            args.resume = workbook
            second = run_jobs(jobs, args, workbook, execute=execute)
            self.assertEqual(calls, ["FAIL_TABLE"])
            self.assertTrue(second[0].skipped)
            self.assertEqual(second[0].status, "OK")
            self.assertEqual(second[1].status, "FAILED")
            self.assertFalse(second[1].skipped)

    def test_resume_rejects_changed_compare_settings(self) -> None:
        job = TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")

        def execute(job: TableJob, args: object) -> TableResult:
            return _ok_result(job)

        with tempfile.TemporaryDirectory() as folder:
            workbook = resolve_workbook_base(Path(folder) / "nightly", True)
            args = _cli_args(Path(folder), resume=None)
            run_jobs([job], args, workbook, execute=execute)
            args.resume = workbook
            args.target_database = "OTHER"
            with self.assertRaisesRegex(ResumeError, "target_database"):
                run_jobs([job], args, workbook, execute=execute)

    def test_changed_key_is_not_treated_as_the_same_job(self) -> None:
        calls: list[str] = []

        def execute(job: TableJob, args: object) -> TableResult:
            calls.append(job.key_columns)
            return _ok_result(job)

        with tempfile.TemporaryDirectory() as folder:
            workbook = resolve_workbook_base(Path(folder) / "nightly", True)
            args = _cli_args(Path(folder), resume=None)
            run_jobs([TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")], args, workbook, execute=execute)
            calls.clear()
            args.resume = workbook
            run_jobs([TableJob("DIM_PARTY", "OTHER_BK", group_name="Party")], args, workbook, execute=execute)
            self.assertEqual(calls, ["OTHER_BK"])

    def test_workers_preserve_csv_order(self) -> None:
        jobs = [
            TableJob("T1", "K", group_name="G"),
            TableJob("T2", "K", group_name="G"),
            TableJob("T3", "K", group_name="G"),
        ]

        def execute(job: TableJob, args: object) -> TableResult:
            if job.table_name == "T1":
                time.sleep(0.05)
            return _ok_result(job)

        with tempfile.TemporaryDirectory() as folder:
            workbook = resolve_workbook_base(Path(folder) / "nightly", True)
            args = _cli_args(Path(folder), resume=None, workers=3)
            results = run_jobs(jobs, args, workbook, execute=execute)
            self.assertEqual([result.job.table_name for result in results], ["T1", "T2", "T3"])
            self.assertFalse(any(result.skipped for result in results))
            from openpyxl import load_workbook

            book = load_workbook(workbook / "G.xlsx")
            self.assertEqual(book["_Summary"]["B2"].value, "T1")
            self.assertEqual(book["_Summary"]["B3"].value, "T2")
            self.assertEqual(book["_Summary"]["B4"].value, "T3")
            book.close()

    def test_resume_without_run_json_fails(self) -> None:
        job = TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")

        def execute(job: TableJob, args: object) -> TableResult:
            return _ok_result(job)

        with tempfile.TemporaryDirectory() as folder:
            workbook = resolve_workbook_base(Path(folder) / "nightly", True)
            args = _cli_args(Path(folder), resume=workbook)
            with self.assertRaisesRegex(ResumeError, "No previous run"):
                run_jobs([job], args, workbook, execute=execute)


class _FakeCursor:
    def __init__(self, object_id: int | None = 100) -> None:
        self.object_id = object_id
        self.statements: list[tuple[str, tuple]] = []
        self._next_id = 1
        self._last: tuple | None = None
        self.fast_executemany = False

    def execute(self, sql: str, *params: object) -> None:
        self.statements.append((sql, params))
        if "OBJECT_ID" in sql:
            self._last = (self.object_id,)
        elif "OUTPUT INSERTED" in sql:
            self._last = (self._next_id,)
            self._next_id += 1
        else:
            self._last = None

    def fetchone(self) -> tuple | None:
        return self._last

    def executemany(self, sql: str, rows: list) -> None:
        self.statements.append((sql, tuple(rows)))

    def close(self) -> None:
        return None


class _FakeConnection:
    def __init__(self, cursor: _FakeCursor) -> None:
        self._cursor = cursor
        self.autocommit = False
        self.commits = 0

    def cursor(self) -> _FakeCursor:
        return self._cursor

    def commit(self) -> None:
        self.commits += 1

    def close(self) -> None:
        return None


class PersistTests(unittest.TestCase):
    def test_optional_persist_flags_imply_persist(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "tables.csv"
            path.write_text("TableName,KeyColumns\nDIM_USER,USER_BK\n", encoding="utf-8")
            args = parse_args(
                [
                    "--tables",
                    str(path),
                    "--server",
                    "localhost",
                    "--source-database",
                    "DWH",
                    "--target-database",
                    "DWH2",
                    "--persist-schema",
                ]
            )
        self.assertTrue(args.persist)
        self.assertTrue(args.persist_schema)
        self.assertTrue(persist_enabled(args))

    def test_store_writes_summary_only_by_default(self) -> None:
        cursor = _FakeCursor()
        store = SqlRunStore(_FakeConnection(cursor))
        job = TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")
        with tempfile.TemporaryDirectory() as folder:
            args = _cli_args(
                Path(folder),
                persist=True,
                persist_detail=False,
                persist_duplicates=False,
                persist_schema=False,
            )
            store.start_run(args, [job], Path(folder) / "nightly")
            store.save_table(_ok_result(job), args)
        sql = "\n".join(statement for statement, _ in cursor.statements)
        self.assertIn("compare.Run", sql)
        self.assertIn("compare.RunTable", sql)
        self.assertNotIn("compare.RunDetail", sql)
        self.assertNotIn("compare.RunDuplicate", sql)
        self.assertNotIn("compare.RunSchema", sql)
        self.assertEqual(store.run_id, 1)

    def test_store_writes_optional_children(self) -> None:
        cursor = _FakeCursor()
        store = SqlRunStore(_FakeConnection(cursor))
        job = TableJob("DIM_PARTY", "PARTY_BK", group_name="Party")
        result = _ok_result(job)
        result.duplicate_rows = [("DIM_PARTY", "X", "DUPLICATE_SOURCE", 2)]
        result.schema_rows = [("DIM_PARTY", "NOTES", "SOURCE_ONLY", "SOURCE_ONLY", "varchar(100)", None)]
        with tempfile.TemporaryDirectory() as folder:
            args = _cli_args(
                Path(folder),
                persist=True,
                persist_detail=True,
                persist_duplicates=True,
                persist_schema=True,
            )
            store.start_run(args, [job], Path(folder) / "nightly")
            store.save_table(result, args)
        sql = "\n".join(statement for statement, _ in cursor.statements)
        self.assertIn("compare.RunDetail", sql)
        self.assertIn("compare.RunDuplicate", sql)
        self.assertIn("compare.RunSchema", sql)

    def test_missing_history_tables_raise(self) -> None:
        store = SqlRunStore(_FakeConnection(_FakeCursor(object_id=None)))
        with tempfile.TemporaryDirectory() as folder:
            args = _cli_args(Path(folder), persist=True)
            with self.assertRaisesRegex(PersistError, "compare.Run"):
                store.start_run(args, [TableJob("DIM_PARTY", "PARTY_BK")], Path(folder) / "nightly")

    def test_run_jobs_saves_skipped_and_run_tables(self) -> None:
        jobs = [
            TableJob("OK_TABLE", "K", group_name="Party"),
            TableJob("FAIL_TABLE", "K", group_name="Party"),
        ]
        saved: list[str] = []

        class Store:
            def save_table(self, result: TableResult, args: object) -> None:
                saved.append(f"{result.job.table_name}:{result.status}:{int(result.skipped)}")

        def execute(job: TableJob, args: object) -> TableResult:
            if job.table_name == "FAIL_TABLE":
                return _ok_result(job, "FAILED")
            return _ok_result(job)

        with tempfile.TemporaryDirectory() as folder:
            workbook = resolve_workbook_base(Path(folder) / "nightly", True)
            args = _cli_args(Path(folder), resume=None, persist=True)
            run_jobs(jobs, args, workbook, execute=execute)
            args.resume = workbook
            run_jobs(jobs, args, workbook, execute=execute, store=Store())

        self.assertEqual(saved, ["OK_TABLE:OK:1", "FAIL_TABLE:FAILED:0"])


if __name__ == "__main__":
    unittest.main()
