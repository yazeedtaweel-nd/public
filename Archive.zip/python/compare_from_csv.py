#!/usr/bin/env python3
"""Compare many tables from a CSV or Excel list and write one workbook."""

from __future__ import annotations

import argparse
import csv
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Sequence

EXCEL_MAX_ROWS = 1_048_576
EXCEL_MAX_SHEET = 31
INVALID_SHEET_CHARS = re.compile(r"[\[\]*:/\\?]")
RESERVED_SHEETS = ("_Summary", "_Duplicates")

DETAIL_HEADERS = ("Table", "Key", "Status", "Column", "SourceValue", "TargetValue")
DUPLICATE_HEADERS = ("Table", "Key", "Status", "RecordCount")
SUMMARY_HEADERS = (
    "Table",
    "Schema",
    "KeyColumns",
    "ExcludedColumns",
    "Status",
    "HasDifferences",
    "DurationSec",
    "SourceRowCount",
    "TargetRowCount",
    "CountDifference",
    "MatchingRows",
    "OnlyInSource",
    "OnlyInTarget",
    "ValueMismatch",
    "DuplicateSourceKeys",
    "DuplicateTargetKeys",
    "DetailRows",
    "DuplicateRows",
    "OverflowFile",
    "Error",
)

COLUMN_ALIASES = {
    "tablename": "table_name",
    "table": "table_name",
    "table_name": "table_name",
    "keycolumns": "key_columns",
    "keycolumn": "key_columns",
    "key": "key_columns",
    "keys": "key_columns",
    "key_columns": "key_columns",
    "excludedcolumns": "excluded_columns",
    "excludedcolumn": "excluded_columns",
    "excluded": "excluded_columns",
    "excluded_columns": "excluded_columns",
    "schemaname": "schema_name",
    "schema": "schema_name",
    "schema_name": "schema_name",
    "output": "output",
    "includematches": "include_matches",
    "include_matches": "include_matches",
}

ODBC_DRIVERS = (
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
    "ODBC Driver 13 for SQL Server",
    "SQL Server",
)


@dataclass
class TableJob:
    table_name: str
    key_columns: str
    excluded_columns: str | None = None
    schema_name: str | None = None
    output: str | None = None
    include_matches: bool | None = None
    line_number: int = 0


@dataclass
class ResultSet:
    kind: str
    columns: list[str]
    rows: list[tuple[Any, ...]]


@dataclass
class TableResult:
    job: TableJob
    status: str
    schema_name: str = "dbo"
    duration_sec: float = 0.0
    error: str | None = None
    detail_columns: list[str] = field(default_factory=lambda: list(DETAIL_HEADERS))
    detail_rows: list[tuple[Any, ...]] = field(default_factory=list)
    duplicate_rows: list[tuple[Any, ...]] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)
    overflow_file: str | None = None


def normalize_header(name: str | None) -> str:
    if name is None:
        return ""
    return re.sub(r"[\s_\-]+", "", str(name).strip().lower())


def parse_bool(value: Any) -> bool | None:
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in {"", "none"}:
        return None
    if text in {"1", "true", "yes", "y"}:
        return True
    if text in {"0", "false", "no", "n"}:
        return False
    raise ValueError(f"Cannot parse boolean value {value!r}.")


def blank_to_none(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def map_row(headers: Sequence[str], values: Sequence[Any], line_number: int) -> TableJob | None:
    mapped: dict[str, Any] = {}
    for header, value in zip(headers, values):
        key = COLUMN_ALIASES.get(normalize_header(header))
        if key:
            mapped[key] = value

    table_name = blank_to_none(mapped.get("table_name"))
    key_columns = blank_to_none(mapped.get("key_columns"))
    if table_name is None and key_columns is None:
        return None
    if table_name is None:
        raise ValueError(f"Row {line_number}: TableName is required.")
    if key_columns is None:
        raise ValueError(f"Row {line_number}: KeyColumns is required for {table_name}.")

    output = blank_to_none(mapped.get("output"))
    if output:
        output = output.upper()

    return TableJob(
        table_name=table_name,
        key_columns=key_columns,
        excluded_columns=blank_to_none(mapped.get("excluded_columns")),
        schema_name=blank_to_none(mapped.get("schema_name")),
        output=output,
        include_matches=parse_bool(mapped.get("include_matches")),
        line_number=line_number,
    )


def read_table_list(path: Path) -> list[TableJob]:
    suffix = path.suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        rows = _read_excel_rows(path)
    elif suffix in {".csv", ".txt"}:
        rows = _read_csv_rows(path)
    else:
        raise ValueError(f"Unsupported table list type: {path.suffix}. Use .csv or .xlsx.")

    if not rows:
        raise ValueError(f"{path} is empty.")

    headers = ["" if value is None else str(value) for value in rows[0]]
    if not any(COLUMN_ALIASES.get(normalize_header(header)) == "table_name" for header in headers):
        raise ValueError("The table list must have a TableName column.")
    if not any(COLUMN_ALIASES.get(normalize_header(header)) == "key_columns" for header in headers):
        raise ValueError("The table list must have a KeyColumns column.")

    jobs: list[TableJob] = []
    for index, raw in enumerate(rows[1:], start=2):
        if raw is None:
            continue
        values = list(raw)
        first = blank_to_none(values[0]) if values else None
        if first and first.startswith("#"):
            continue
        job = map_row(headers, values, index)
        if job:
            jobs.append(job)

    if not jobs:
        raise ValueError(f"{path} has a header row but no tables.")
    return jobs


def _read_csv_rows(path: Path) -> list[list[Any]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return [list(row) for row in csv.reader(handle)]


def _read_excel_rows(path: Path) -> list[tuple[Any, ...]]:
    from openpyxl import load_workbook

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        sheet = workbook.active
        return [tuple(row) for row in sheet.iter_rows(values_only=True)]
    finally:
        workbook.close()


def classify_result_set(columns: Sequence[str]) -> str:
    names = {str(column) for column in columns}
    if {"SourceValue", "TargetValue"} <= names:
        return "detail"
    if "RecordCount" in names:
        return "duplicates"
    if "SourceRowCount" in names:
        return "summary"
    return "unknown"


def excel_sheet_name(name: str, used: set[str]) -> str:
    cleaned = INVALID_SHEET_CHARS.sub("_", name).strip("' ") or "Sheet"
    cleaned = cleaned[:EXCEL_MAX_SHEET]
    candidate = cleaned
    index = 2
    while candidate.lower() in used:
        suffix = f"_{index}"
        candidate = f"{cleaned[: EXCEL_MAX_SHEET - len(suffix)]}{suffix}"
        index += 1
    used.add(candidate.lower())
    return candidate


def cell_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.hex()
    return value


def has_differences(result: TableResult) -> str:
    if result.status != "OK":
        return "Unknown"
    summary = result.summary
    counts = [
        summary.get("OnlyInSource"),
        summary.get("OnlyInTarget"),
        summary.get("ValueMismatch"),
        summary.get("DuplicateSourceKeys"),
        summary.get("DuplicateTargetKeys"),
    ]
    if any(count is not None for count in counts):
        return "Yes" if any((count or 0) > 0 for count in counts) else "No"
    if result.detail_rows or result.duplicate_rows:
        return "Yes"
    return "No"


def pick_driver(preferred: str | None) -> str:
    try:
        import pyodbc
    except ImportError as exc:
        raise SystemExit("pyodbc is required. Install dependencies with: pip install -r requirements.txt") from exc

    installed = set(pyodbc.drivers())
    candidates = (([preferred] if preferred else []) + list(ODBC_DRIVERS))
    for driver in candidates:
        if driver in installed:
            return driver
    available = ", ".join(sorted(installed)) or "none"
    raise SystemExit(
        "No supported SQL Server ODBC driver is installed. "
        f"Available drivers: {available}."
    )


def connect(
    server: str,
    database: str,
    driver: str,
    username: str | None,
    password: str | None,
    timeout: int,
    trust_cert: bool,
) -> Any:
    import pyodbc

    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
        f"DATABASE={database}",
    ]
    if username:
        parts.append(f"UID={username}")
        parts.append(f"PWD={password or ''}")
    else:
        parts.append("Trusted_Connection=yes")
    if driver.startswith("ODBC Driver 18") or driver.startswith("ODBC Driver 17"):
        parts.append("Encrypt=yes")
        parts.append(f"TrustServerCertificate={'yes' if trust_cert else 'no'}")

    connection = pyodbc.connect(";".join(parts), timeout=timeout)
    connection.timeout = timeout
    return connection


def fetch_result_sets(cursor: Any) -> list[ResultSet]:
    sets: list[ResultSet] = []
    while True:
        if cursor.description is not None:
            columns = [column[0] for column in cursor.description]
            rows = [tuple(row) for row in cursor.fetchall()]
            sets.append(ResultSet(classify_result_set(columns), columns, rows))
        if not cursor.nextset():
            break
    return sets


def print_sql_messages(connection: Any) -> None:
    messages = getattr(connection, "messages", None)
    if not messages:
        return
    for message in messages:
        text = message[1] if isinstance(message, tuple) and len(message) > 1 else str(message)
        text = str(text).strip()
        if text:
            print(text)
    connection.messages.clear()


def compare_table(
    cursor: Any,
    connection: Any,
    job: TableJob,
    args: argparse.Namespace,
) -> TableResult:
    output = job.output or args.output
    include_matches = args.include_matches if job.include_matches is None else job.include_matches
    schema_name = job.schema_name or args.schema
    started = datetime.now()

    sql = """
EXEC dbo.CompareTables
    @SourceDatabase = ?,
    @TargetDatabase = ?,
    @SchemaName = ?,
    @TableName = ?,
    @KeyColumns = ?,
    @ExcludedColumns = ?,
    @IncludeMatches = ?,
    @Output = ?,
    @SourceServer = ?,
    @TargetServer = ?;
"""
    cursor.execute(
        sql,
        args.source_database,
        args.target_database,
        schema_name,
        job.table_name,
        job.key_columns,
        job.excluded_columns,
        1 if include_matches else 0,
        output,
        args.source_server,
        args.target_server,
    )
    print_sql_messages(connection)
    sets = fetch_result_sets(cursor)
    duration = (datetime.now() - started).total_seconds()

    result = TableResult(job=job, status="OK", schema_name=schema_name, duration_sec=duration)
    for result_set in sets:
        if result_set.kind == "detail":
            result.detail_columns = result_set.columns
            result.detail_rows = result_set.rows
        elif result_set.kind == "duplicates":
            result.duplicate_rows = result_set.rows
        elif result_set.kind == "summary" and result_set.rows:
            result.summary = dict(zip(result_set.columns, result_set.rows[0]))
    return result


def summary_row(result: TableResult) -> list[Any]:
    summary = result.summary
    return [
        result.job.table_name,
        result.schema_name,
        result.job.key_columns,
        result.job.excluded_columns,
        result.status,
        has_differences(result),
        round(result.duration_sec, 2),
        summary.get("SourceRowCount"),
        summary.get("TargetRowCount"),
        summary.get("CountDifference"),
        summary.get("MatchingRows"),
        summary.get("OnlyInSource"),
        summary.get("OnlyInTarget"),
        summary.get("ValueMismatch"),
        summary.get("DuplicateSourceKeys"),
        summary.get("DuplicateTargetKeys"),
        len(result.detail_rows),
        len(result.duplicate_rows),
        result.overflow_file,
        result.error,
    ]


def write_sheet(
    workbook: Any,
    title: str,
    used: set[str],
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    overflow_dir: Path,
    table_name: str | None = None,
) -> str | None:
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    sheet_title = excel_sheet_name(title, used)
    sheet = workbook.create_sheet(sheet_title)
    overflow_file = None
    written_rows: Sequence[Sequence[Any]] = rows
    max_data_rows = EXCEL_MAX_ROWS - 1

    if len(rows) > max_data_rows:
        overflow_path = overflow_dir / f"{table_name or sheet_title}.csv"
        _write_csv(overflow_path, headers, rows)
        overflow_file = str(overflow_path)
        written_rows = rows[:max_data_rows]
        print(f"  {len(rows)} rows exceed Excel's limit; full output written to {overflow_path}")

    header_fill = PatternFill("solid", fgColor="1F4E79")
    header_font = Font(color="FFFFFF", bold=True)
    sheet.append(list(headers))
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(vertical="center")

    status_fills = {
        "OK": PatternFill("solid", fgColor="C6EFCE"),
        "FAILED": PatternFill("solid", fgColor="FFC7CE"),
        "MATCH": PatternFill("solid", fgColor="C6EFCE"),
        "ONLY_IN_SOURCE": PatternFill("solid", fgColor="BDD7EE"),
        "ONLY_IN_TARGET": PatternFill("solid", fgColor="FCE4D6"),
        "VALUE_MISMATCH": PatternFill("solid", fgColor="F8CBAD"),
        "DUPLICATE_SOURCE": PatternFill("solid", fgColor="E2D5F1"),
        "DUPLICATE_TARGET": PatternFill("solid", fgColor="E2D5F1"),
        "Yes": PatternFill("solid", fgColor="F8CBAD"),
        "No": PatternFill("solid", fgColor="C6EFCE"),
        "Unknown": PatternFill("solid", fgColor="D9D9D9"),
    }
    status_index = next((i for i, header in enumerate(headers, start=1) if header == "Status"), None)
    diff_index = next((i for i, header in enumerate(headers, start=1) if header == "HasDifferences"), None)

    for row in written_rows:
        sheet.append([cell_value(value) for value in row])
        current = sheet.max_row
        if status_index:
            status = sheet.cell(current, status_index).value
            fill = status_fills.get(str(status) if status is not None else "")
            if fill:
                sheet.cell(current, status_index).fill = fill
        if diff_index:
            value = sheet.cell(current, diff_index).value
            fill = status_fills.get(str(value) if value is not None else "")
            if fill:
                sheet.cell(current, diff_index).fill = fill

    sheet.freeze_panes = "A2"
    for index, header in enumerate(headers, start=1):
        width = len(str(header)) + 2
        for row in sheet.iter_rows(min_row=2, min_col=index, max_col=index, max_row=min(sheet.max_row, 200)):
            value = row[0].value
            if value is not None:
                width = min(max(width, len(str(value)) + 2), 60)
        sheet.column_dimensions[get_column_letter(index)].width = width
    if sheet.max_row >= 1:
        sheet.auto_filter.ref = sheet.dimensions
    return overflow_file


def _write_csv(path: Path, headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(headers)
        for row in rows:
            writer.writerow(["" if value is None else value for value in row])


def write_workbook(path: Path, results: Sequence[TableResult]) -> None:
    from openpyxl import Workbook

    workbook = Workbook()
    default = workbook.active
    workbook.remove(default)
    used: set[str] = set()
    overflow_dir = path.with_name(f"{path.stem}-overflow")

    duplicate_rows = [row for result in results for row in result.duplicate_rows]
    if duplicate_rows:
        write_sheet(workbook, "_Duplicates", used, DUPLICATE_HEADERS, duplicate_rows, overflow_dir)

    used_titles = {name.lower() for name in RESERVED_SHEETS}
    for result in results:
        if result.status != "OK":
            continue
        title = result.job.table_name
        if title.lower() in used_titles:
            title = f"{result.schema_name}.{result.job.table_name}"
        overflow = write_sheet(
            workbook,
            title,
            used,
            result.detail_columns,
            result.detail_rows,
            overflow_dir,
            table_name=result.job.table_name,
        )
        if overflow:
            result.overflow_file = overflow
        used_titles.add(title.lower())

    write_sheet(
        workbook,
        "_Summary",
        used,
        SUMMARY_HEADERS,
        [summary_row(result) for result in results],
        overflow_dir,
    )
    workbook.move_sheet("_Summary", offset=-(len(workbook.sheetnames) - 1))

    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Read TableName, KeyColumns, and ExcludedColumns from a CSV or Excel "
            "file, run dbo.CompareTables for each row, and write one workbook "
            "with a _Summary sheet plus one sheet per table."
        )
    )
    parser.add_argument("--tables", required=True, type=Path, help="CSV or Excel control file.")
    parser.add_argument("--server", required=True, help="SQL Server that hosts the utility database.")
    parser.add_argument("--database", default="DwhCompare", help="Utility database. Default: DwhCompare.")
    parser.add_argument("--source-database", required=True, help="@SourceDatabase.")
    parser.add_argument("--target-database", required=True, help="@TargetDatabase.")
    parser.add_argument("--schema", default="dbo", help="Default @SchemaName. Default: dbo.")
    parser.add_argument("--source-server", help="Optional @SourceServer linked server.")
    parser.add_argument("--target-server", help="Optional @TargetServer linked server.")
    parser.add_argument(
        "--output",
        default="ALL",
        choices=("ALL", "DETAIL", "DIFF", "DUPLICATES", "SUMMARY"),
        help="Default @Output. ALL writes detail, duplicates, and summary in one scan. Default: ALL.",
    )
    parser.add_argument(
        "--include-matches",
        action="store_true",
        help="Include MATCH rows in detail sheets. Default is to omit them. Ignored for DIFF.",
    )
    parser.add_argument(
        "--workbook",
        type=Path,
        help="Output .xlsx path. Default: compare-results-YYYYmmdd-HHMMSS.xlsx.",
    )
    parser.add_argument("--driver", help="ODBC driver name. The first installed supported driver is used if omitted.")
    parser.add_argument("--username", help="SQL login. Omit to use Windows / trusted authentication.")
    parser.add_argument("--password", help="SQL login password.")
    parser.add_argument("--timeout", type=int, default=0, help="Query timeout in seconds. 0 means no timeout.")
    parser.add_argument(
        "--no-trust-cert",
        action="store_true",
        help="Require a trusted TLS certificate. Default is TrustServerCertificate=yes.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print the resolved table list and exit.")
    return parser.parse_args(argv)


def default_workbook_path() -> Path:
    return Path(f"compare-results-{datetime.now().strftime('%Y%m%d-%H%M%S')}.xlsx")


def run_jobs(jobs: Iterable[TableJob], args: argparse.Namespace) -> list[TableResult]:
    driver = pick_driver(args.driver)
    print(f"Connecting to {args.server} / {args.database} with {driver}")
    connection = connect(
        server=args.server,
        database=args.database,
        driver=driver,
        username=args.username,
        password=args.password,
        timeout=args.timeout,
        trust_cert=not args.no_trust_cert,
    )
    results: list[TableResult] = []
    try:
        cursor = connection.cursor()
        job_list = list(jobs)
        for index, job in enumerate(job_list, start=1):
            schema = job.schema_name or args.schema
            output = job.output or args.output
            print(f"[{index}/{len(job_list)}] {schema}.{job.table_name} ({output})")
            started = datetime.now()
            try:
                result = compare_table(cursor, connection, job, args)
                print(
                    f"  {result.status} in {result.duration_sec:.1f}s "
                    f"({len(result.detail_rows)} detail, {len(result.duplicate_rows)} duplicate)"
                )
            except Exception as exc:
                result = TableResult(
                    job=job,
                    status="FAILED",
                    schema_name=schema,
                    duration_sec=(datetime.now() - started).total_seconds(),
                    error=str(exc).splitlines()[0],
                )
                print(f"  FAILED: {result.error}")
            results.append(result)
        cursor.close()
    finally:
        connection.close()
    return results


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    if not args.tables.exists():
        print(f"Table list not found: {args.tables}", file=sys.stderr)
        return 1

    try:
        jobs = read_table_list(args.tables)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    print(f"Loaded {len(jobs)} table(s) from {args.tables}")
    if args.dry_run:
        for job in jobs:
            print(
                f"  {job.schema_name or args.schema}.{job.table_name} "
                f"keys={job.key_columns} excluded={job.excluded_columns or ''}"
            )
        return 0

    results = run_jobs(jobs, args)
    workbook = args.workbook or default_workbook_path()
    if workbook.suffix.lower() != ".xlsx":
        workbook = workbook.with_suffix(".xlsx")
    write_workbook(workbook, results)
    print(f"Wrote {workbook}")

    failed = sum(1 for result in results if result.status != "OK")
    if failed:
        print(f"{failed} of {len(results)} table(s) failed.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
