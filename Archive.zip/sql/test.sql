/*
    Self-checking test for the comparison framework.

    Run this in the database where sql/install.sql was installed:

        sqlcmd -S localhost,14333 -U sa -d DwhCompare -i sql/test.sql

    It creates DwhCompare_Src and DwhCompare_Tgt, loads a small fixture, and
    throws if a result does not match the expected comparison.
*/

SET NOCOUNT ON;
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;

IF OBJECT_ID(N'dbo.CompareTables', N'P') IS NULL
    THROW 50001, N'Run sql/install.sql in this database before sql/test.sql.', 1;
GO

IF DB_ID(N'DwhCompare_Src') IS NULL
    CREATE DATABASE DwhCompare_Src;
GO

IF DB_ID(N'DwhCompare_Tgt') IS NULL
    CREATE DATABASE DwhCompare_Tgt;
GO

ALTER DATABASE DwhCompare_Src SET RECOVERY SIMPLE;
ALTER DATABASE DwhCompare_Tgt SET RECOVERY SIMPLE;
GO

USE DwhCompare_Src;
GO

DROP TABLE IF EXISTS dbo.BAD_TYPE;
DROP TABLE IF EXISTS dbo.CUSTOMER;
DROP TABLE IF EXISTS dbo.POLICY_LIMIT;
GO

CREATE TABLE dbo.CUSTOMER (
    CUSTOMER_ID int NOT NULL,
    NAME nvarchar(100) NULL,
    STATUS varchar(20) NULL,
    COUNTRY char(2) NULL,
    FEE money NULL,
    CREATED_DATE datetime NOT NULL,
    NOTES varchar(100) NULL
);

INSERT INTO dbo.CUSTOMER (CUSTOMER_ID, NAME, STATUS, COUNTRY, FEE, CREATED_DATE, NOTES)
VALUES
    (1001, N'Ahmed', 'ACTIVE',   'JO', 10.50, '20240101', 'source-note'),
    (1002, N'Sara',  'ACTIVE',   'JO',  0.00, '20240102', NULL),
    (1004, N'Ahmed', 'ACTIVE',   'JO',  1.25, '20240104', NULL),
    (1005, N'Noor',  NULL,       'JO',  NULL, '20240105', NULL),
    (1006, NULL,     'ACTIVE',   'JO',  0.00, '20240106', NULL),
    (1007, N'Dup',   'ACTIVE',   'JO',  1.00, '20240107', NULL),
    (1007, N'Dup2',  'INACTIVE', 'PS',  2.00, '20240108', NULL),
    (1008, N'Same',  'ACTIVE',   'JO',  3.00, '20240109', NULL),
    (1010, N'Ann',   'ACTIVE',   'JO',  0.00, '20240110', NULL);

CREATE TABLE dbo.POLICY_LIMIT (
    POLICY_BK varchar(20) NULL,
    LIMIT_BK varchar(20) NOT NULL,
    AMOUNT decimal(18, 2) NULL,
    RATE decimal(10, 2) NULL
);

INSERT INTO dbo.POLICY_LIMIT (POLICY_BK, LIMIT_BK, AMOUNT, RATE)
VALUES
    ('P1',  'L1',   10.50, 1.50),
    ('P1',  'L2',   50.00, 1.00),
    ('P2',  'L1',   10.00, 2.00),
    ('P3',  'L1',   NULL,  1.00),
    ('P4',  'L1',   NULL,  1.00),
    ('P5',  'L1',    1.00, 1.00),
    ('P5',  'L1',    2.00, 1.00),
    (NULL,  'L9',    5.00, 1.00),
    (NULL,  'ONLY',  1.00, 1.00),
    ('P8',  'L1',  101.00, 1.00);

CREATE TABLE dbo.BAD_TYPE (
    ID int NOT NULL,
    QTY varchar(20) NULL
);
GO

USE DwhCompare_Tgt;
GO

DROP TABLE IF EXISTS dbo.BAD_TYPE;
DROP TABLE IF EXISTS dbo.CUSTOMER;
DROP TABLE IF EXISTS dbo.POLICY_LIMIT;
GO

CREATE TABLE dbo.CUSTOMER (
    CUSTOMER_ID bigint NOT NULL,
    NAME nvarchar(100) NULL,
    STATUS varchar(20) NULL,
    COUNTRY char(2) NULL,
    FEE money NULL,
    CREATED_DATE datetime NOT NULL,
    UPDATED_DATE datetime NULL
);

INSERT INTO dbo.CUSTOMER (CUSTOMER_ID, NAME, STATUS, COUNTRY, FEE, CREATED_DATE, UPDATED_DATE)
VALUES
    (1001, N'Ahmed',  'ACTIVE',   'JO', 10.50, '20240601', '20240602'),
    (1003, N'Omar',   'ACTIVE',   'AE',  0.00, '20240103', NULL),
    (1004, N'Ahmad',  'INACTIVE', 'JO',  9.00, '20240104', NULL),
    (1005, N'Noor',   NULL,       'JO',  NULL, '20240105', NULL),
    (1006, N'Hana',   'ACTIVE',   'JO',  0.00, '20240106', NULL),
    (1008, N'Same',   'ACTIVE',   'JO',  3.00, '20240701', NULL),
    (1009, N'Zaid',   'ACTIVE',   'JO',  4.00, '20240111', NULL),
    (1009, N'Zaid',   'ACTIVE',   'JO',  4.00, '20240112', NULL),
    (1010, N'Ann ',   'ACTIVE',   'JO',  0.00, '20240110', NULL);

CREATE TABLE dbo.POLICY_LIMIT (
    POLICY_BK varchar(40) NULL,
    LIMIT_BK varchar(20) NOT NULL,
    AMOUNT decimal(18, 4) NULL,
    RATE decimal(10, 4) NULL
);

INSERT INTO dbo.POLICY_LIMIT (POLICY_BK, LIMIT_BK, AMOUNT, RATE)
VALUES
    ('P1',  'L1',   10.5000, 1.5000),
    ('P2',  'L1',   15.0000, 2.0000),
    ('P3',  'L1',     NULL,  1.0000),
    ('P4',  'L1',    5.0000, 1.0000),
    ('P6',  'L1',    9.0000, 1.0000),
    ('P7',  'L1',    1.0000, 1.0000),
    ('P7',  'L1',    1.0000, 1.0000),
    (NULL,  'L9',    5.0000, 1.0000),
    (NULL,  'TGT',   1.0000, 1.0000),
    ('P8',  'L1',  110.0000, 1.0000);

CREATE TABLE dbo.BAD_TYPE (
    ID int NOT NULL,
    QTY int NULL
);
GO

USE DwhCompare;
GO

DECLARE @Failed bit;

/* ------------------------------------------------------------------ */
/* Validation                                                         */
/* ------------------------------------------------------------------ */

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = NULL;
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%At least one key column is required%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Empty key list should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DoesNotExist',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%does not exist%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Missing database should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'NO_SUCH_TABLE',
        @KeyColumns = N'CUSTOMER_ID';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%does not exist%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Missing table should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'NO_SUCH_COLUMN';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%does not exist%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Missing key column should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID, CUSTOMER_ID';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%more than once%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Duplicate key specification should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @ExcludedColumns = N'NO_SUCH_COLUMN';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%does not exist%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Missing excluded column should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'BAD_TYPE',
        @KeyColumns = N'ID';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%QTY%not compatible%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Incompatible column types should have failed.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER; DROP TABLE dbo.CUSTOMER;--',
        @KeyColumns = N'CUSTOMER_ID';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%does not exist%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Injected table name should have failed validation.', 1;

IF OBJECT_ID(N'DwhCompare_Src.dbo.CUSTOMER', N'U') IS NULL
    THROW 50999, N'Injected table name dropped CUSTOMER.', 1;

SET @Failed = 0;
BEGIN TRY
    EXEC dbo.CompareTables
        @SourceDatabase = N'DwhCompare_Src',
        @TargetDatabase = N'DwhCompare_Tgt',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID]; DROP TABLE dbo.CUSTOMER;--';
    SET @Failed = 1;
END TRY
BEGIN CATCH
    IF ERROR_MESSAGE() NOT LIKE N'%does not exist%'
        THROW;
END CATCH;
IF @Failed = 1 THROW 50999, N'Injected key name should have failed validation.', 1;

IF OBJECT_ID(N'DwhCompare_Src.dbo.CUSTOMER', N'U') IS NULL
    THROW 50999, N'Injected key name dropped CUSTOMER.', 1;

/* ------------------------------------------------------------------ */
/* CUSTOMER: single key, exclusions, NULL, trailing space, duplicates */
/* ------------------------------------------------------------------ */

CREATE TABLE #Summary (
    [Table] nvarchar(128) NULL,
    SourceRowCount bigint NULL,
    TargetRowCount bigint NULL,
    CountDifference bigint NULL,
    MatchingRows bigint NULL,
    OnlyInSource bigint NULL,
    OnlyInTarget bigint NULL,
    ValueMismatch bigint NULL,
    DuplicateSourceKeys bigint NULL,
    DuplicateTargetKeys bigint NULL
);

CREATE TABLE #Detail (
    [Table] nvarchar(128) NULL,
    [Key] nvarchar(max) NULL,
    [Status] varchar(32) NULL,
    [Column] nvarchar(128) NULL,
    SourceValue nvarchar(max) NULL,
    TargetValue nvarchar(max) NULL
);

CREATE TABLE #Dups (
    [Table] nvarchar(128) NULL,
    [Key] nvarchar(max) NULL,
    [Status] varchar(32) NULL,
    RecordCount bigint NULL
);

INSERT INTO #Summary
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @ExcludedColumns = N'CREATED_DATE',
    @Output = N'SUMMARY';

IF NOT EXISTS (
    SELECT 1
    FROM #Summary
    WHERE [Table] = N'CUSTOMER'
      AND SourceRowCount = 9
      AND TargetRowCount = 9
      AND CountDifference = 0
      AND MatchingRows = 3
      AND OnlyInSource = 1
      AND OnlyInTarget = 1
      AND ValueMismatch = 3
      AND DuplicateSourceKeys = 1
      AND DuplicateTargetKeys = 1
)
BEGIN
    SELECT * FROM #Summary;
    THROW 50999, N'CUSTOMER summary did not match the expected counts.', 1;
END;

INSERT INTO #Detail
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @ExcludedColumns = N'CREATED_DATE',
    @Output = N'DETAIL';

IF (SELECT COUNT(*) FROM #Detail WHERE [Status] = 'MATCH') <> 3
    THROW 50999, N'CUSTOMER should have 3 MATCH rows.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'1001' AND [Status] = 'MATCH' AND [Column] IS NULL)
    THROW 50999, N'1001 should match after CREATED_DATE is excluded.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'1005' AND [Status] = 'MATCH')
    THROW 50999, N'1005 should match when STATUS and FEE are NULL on both sides.', 1;

IF EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'1005' AND [Column] = N'STATUS')
    THROW 50999, N'NULL STATUS should not be reported as a mismatch.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'1002' AND [Status] = 'ONLY_IN_SOURCE')
    THROW 50999, N'1002 should be ONLY_IN_SOURCE.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'1003' AND [Status] = 'ONLY_IN_TARGET')
    THROW 50999, N'1003 should be ONLY_IN_TARGET.', 1;

IF EXISTS (SELECT 1 FROM #Detail WHERE [Key] IN (N'1007', N'1009'))
    THROW 50999, N'Duplicate keys should not appear in the comparison detail.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'1004' AND [Column] = N'NAME'
      AND SourceValue = N'Ahmed' AND TargetValue = N'Ahmad'
)
    THROW 50999, N'1004 NAME mismatch was not returned.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'1004' AND [Column] = N'STATUS'
      AND SourceValue = N'ACTIVE' AND TargetValue = N'INACTIVE'
)
    THROW 50999, N'1004 STATUS mismatch was not returned.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'1004' AND [Column] = N'FEE'
      AND SourceValue = N'1.2500' AND TargetValue = N'9.0000'
)
    THROW 50999, N'1004 FEE mismatch was not returned.', 1;

IF EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'1004' AND [Column] = N'COUNTRY')
    THROW 50999, N'1004 COUNTRY should match.', 1;

IF EXISTS (SELECT 1 FROM #Detail WHERE [Column] IN (N'CREATED_DATE', N'NOTES', N'UPDATED_DATE'))
    THROW 50999, N'Excluded or one-sided columns should not be compared.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'1006' AND [Column] = N'NAME'
      AND SourceValue IS NULL AND TargetValue = N'Hana'
)
    THROW 50999, N'NULL versus a value should be a NAME mismatch on 1006.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'1010' AND [Column] = N'NAME'
      AND SourceValue = N'Ann'
      AND TargetValue = N'Ann '
      AND DATALENGTH(TargetValue) = DATALENGTH(N'Ann ')
)
    THROW 50999, N'Trailing space on 1010 should be a mismatch.', 1;

IF (SELECT COUNT(*) FROM #Detail WHERE [Status] = 'VALUE_MISMATCH') <> 5
    THROW 50999, N'CUSTOMER should return 5 column-level mismatch rows.', 1;

DELETE FROM #Detail;

INSERT INTO #Detail
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @ExcludedColumns = N'CREATED_DATE',
    @IncludeMatches = 0,
    @Output = N'DETAIL';

IF EXISTS (SELECT 1 FROM #Detail WHERE [Status] = 'MATCH')
    THROW 50999, N'@IncludeMatches = 0 should omit MATCH rows.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Status] = 'ONLY_IN_SOURCE')
    THROW 50999, N'@IncludeMatches = 0 should still return ONLY_IN_SOURCE.', 1;

INSERT INTO #Dups
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID',
    @ExcludedColumns = N'CREATED_DATE',
    @Output = N'DUPLICATES';

IF NOT EXISTS (
    SELECT 1 FROM #Dups
    WHERE [Key] = N'1007' AND [Status] = 'DUPLICATE_SOURCE' AND RecordCount = 2
)
    THROW 50999, N'1007 should be a duplicate source key with count 2.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Dups
    WHERE [Key] = N'1009' AND [Status] = 'DUPLICATE_TARGET' AND RecordCount = 2
)
    THROW 50999, N'1009 should be a duplicate target key with count 2.', 1;

IF (SELECT COUNT(*) FROM #Dups) <> 2
    THROW 50999, N'CUSTOMER duplicate result should contain exactly two keys.', 1;

CREATE TABLE #Counts (
    [Table] nvarchar(128) NULL,
    SourceRowCount bigint NULL,
    TargetRowCount bigint NULL,
    CountDifference bigint NULL
);

INSERT INTO #Counts
EXEC dbo.CompareTableCounts
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER';

IF NOT EXISTS (
    SELECT 1 FROM #Counts
    WHERE SourceRowCount = 9 AND TargetRowCount = 9 AND CountDifference = 0
)
    THROW 50999, N'CompareTableCounts returned unexpected CUSTOMER counts.', 1;

CREATE TABLE #Found (
    [Table] nvarchar(128) NULL,
    [Key] nvarchar(max) NULL,
    RecordCount bigint NULL
);

INSERT INTO #Found
EXEC dbo.FindDuplicates
    @DatabaseName = N'DwhCompare_Src',
    @SchemaName = N'dbo',
    @TableName = N'CUSTOMER',
    @KeyColumns = N'CUSTOMER_ID';

IF NOT EXISTS (SELECT 1 FROM #Found WHERE [Key] = N'1007' AND RecordCount = 2)
   OR (SELECT COUNT(*) FROM #Found) <> 1
    THROW 50999, N'FindDuplicates should return only CUSTOMER_ID 1007.', 1;

/* ------------------------------------------------------------------ */
/* POLICY_LIMIT: composite key, NULL key part, decimal scale          */
/* ------------------------------------------------------------------ */

DELETE FROM #Summary;
DELETE FROM #Detail;
DELETE FROM #Dups;

INSERT INTO #Summary
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'POLICY_LIMIT',
    @KeyColumns = N'POLICY_BK, LIMIT_BK',
    @Output = N'SUMMARY';

IF NOT EXISTS (
    SELECT 1
    FROM #Summary
    WHERE [Table] = N'POLICY_LIMIT'
      AND SourceRowCount = 10
      AND TargetRowCount = 10
      AND CountDifference = 0
      AND MatchingRows = 3
      AND OnlyInSource = 2
      AND OnlyInTarget = 2
      AND ValueMismatch = 3
      AND DuplicateSourceKeys = 1
      AND DuplicateTargetKeys = 1
)
BEGIN
    SELECT * FROM #Summary;
    THROW 50999, N'POLICY_LIMIT summary did not match the expected counts.', 1;
END;

INSERT INTO #Detail
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'POLICY_LIMIT',
    @KeyColumns = N'POLICY_BK, LIMIT_BK',
    @Output = N'DETAIL';

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'P1 | L1' AND [Status] = 'MATCH')
    THROW 50999, N'P1 | L1 should match across decimal scales.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'<NULL> | L9' AND [Status] = 'MATCH')
    THROW 50999, N'A NULL composite key part should match NULL on the other side.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'P3 | L1' AND [Status] = 'MATCH')
    THROW 50999, N'P3 | L1 should match when AMOUNT is NULL on both sides.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'P1 | L2' AND [Status] = 'ONLY_IN_SOURCE')
    THROW 50999, N'P1 | L2 should be ONLY_IN_SOURCE.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'<NULL> | ONLY' AND [Status] = 'ONLY_IN_SOURCE')
    THROW 50999, N'<NULL> | ONLY should be ONLY_IN_SOURCE.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'P6 | L1' AND [Status] = 'ONLY_IN_TARGET')
    THROW 50999, N'P6 | L1 should be ONLY_IN_TARGET.', 1;

IF NOT EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'<NULL> | TGT' AND [Status] = 'ONLY_IN_TARGET')
    THROW 50999, N'<NULL> | TGT should be ONLY_IN_TARGET.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'P2 | L1' AND [Column] = N'AMOUNT'
      AND SourceValue = N'10.00' AND TargetValue = N'15.0000'
)
    THROW 50999, N'P2 | L1 AMOUNT mismatch was not returned.', 1;

IF EXISTS (SELECT 1 FROM #Detail WHERE [Key] = N'P2 | L1' AND [Column] = N'RATE')
    THROW 50999, N'P2 | L1 RATE should match after scale normalization.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'P4 | L1' AND [Column] = N'AMOUNT'
      AND SourceValue IS NULL AND TargetValue = N'5.0000'
)
    THROW 50999, N'P4 | L1 should show NULL versus 5.0000.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Detail
    WHERE [Key] = N'P8 | L1' AND [Column] = N'AMOUNT'
      AND SourceValue = N'101.00' AND TargetValue = N'110.0000'
)
    THROW 50999, N'P8 | L1 should keep internal zeros distinct (101 versus 110).', 1;

IF EXISTS (SELECT 1 FROM #Detail WHERE [Key] LIKE N'P5 %' OR [Key] LIKE N'P7 %')
    THROW 50999, N'Duplicate composite keys should not appear in the comparison detail.', 1;

INSERT INTO #Dups
EXEC dbo.CompareTables
    @SourceDatabase = N'DwhCompare_Src',
    @TargetDatabase = N'DwhCompare_Tgt',
    @SchemaName = N'dbo',
    @TableName = N'POLICY_LIMIT',
    @KeyColumns = N'POLICY_BK, LIMIT_BK',
    @Output = N'DUPLICATES';

IF NOT EXISTS (
    SELECT 1 FROM #Dups
    WHERE [Key] = N'P5 | L1' AND [Status] = 'DUPLICATE_SOURCE' AND RecordCount = 2
)
    THROW 50999, N'P5 | L1 should be a duplicate source key.', 1;

IF NOT EXISTS (
    SELECT 1 FROM #Dups
    WHERE [Key] = N'P7 | L1' AND [Status] = 'DUPLICATE_TARGET' AND RecordCount = 2
)
    THROW 50999, N'P7 | L1 should be a duplicate target key.', 1;

PRINT 'All comparison framework tests passed.';
GO
