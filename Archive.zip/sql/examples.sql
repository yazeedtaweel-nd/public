/*
    Example calls
    -------------
    These are the supported entry points. They run only when both DWH and DWH2
    are on this instance. sql/test.sql is the executable demonstration and does
    not require those databases.

    SourceValue is the value from @SourceDatabase (DWH in the calls below).
    TargetValue is the value from @TargetDatabase (DWH2).

    Two views in one database:
        EXEC dbo.CompareTables
            @SourceDatabase = N'DWH',
            @TargetDatabase = N'DWH',
            @SchemaName     = N'dbo',
            @TableName      = N'VW_COUNTRY_SRC',
            @TargetTableName = N'VW_COUNTRY_TGT',
            @KeyColumns     = N'CTRY_COUNTRY_CODE';
*/

IF DB_ID(N'DWH') IS NOT NULL AND DB_ID(N'DWH2') IS NOT NULL
BEGIN
    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'POLICY_LIMIT',
        @KeyColumns = N'POLICY_BK,LIMIT_BK';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @ExcludedColumns = N'CREATED_DATE,UPDATED_DATE';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @IncludedColumns = N'NAME,STATUS,COUNTRY',
        @ExcludePatterns = N'*_SRGT,CREATED_*,UPDATED_*';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @Output = N'DIFF';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @IgnoreCase = 1;

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @IgnoreBlank = 1;

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @Output = N'PREFLIGHT';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @Filter = N'CREATED_DATE >= ''2026-01-01''',
        @MaxDetailRows = 5000;

    -- Value-compare the first 1000 keys that exist on both sides.
    -- Missing keys and duplicate keys are still counted in full.
    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @MaxMatchedRows = 1000;

    EXEC dbo.CompareTableCounts
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER';

    EXEC dbo.FindDuplicates
        @DatabaseName = N'DWH',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID';

    IF EXISTS (
        SELECT 1
        FROM sys.servers AS s
        WHERE s.name = N'DWH2_LINK'
          AND s.is_data_access_enabled = 1
          AND (
              s.product = N'SQL Server'
              OR s.provider LIKE N'MSOLEDBSQL%'
              OR s.provider LIKE N'SQLNCLI%'
              OR s.provider = N'SQLOLEDB'
          )
    )
        EXEC dbo.CompareTables
            @SourceDatabase = N'DWH',
            @TargetDatabase = N'DWH',
            @SchemaName = N'dbo',
            @TableName = N'CUSTOMER',
            @KeyColumns = N'CUSTOMER_ID',
            @TargetServer = N'DWH2_LINK';
END
ELSE
    PRINT 'DWH and DWH2 are not on this instance. Use the calls in this file as templates, or run sql/test.sql.';
GO

/*
    History written by python/compare_from_csv.py --persist

    SELECT TOP 20
        r.RunId,
        r.StartedAt,
        r.ExitCode,
        t.GroupName,
        t.TableName,
        t.HasDifferences,
        t.OnlyInSource,
        t.OnlyInTarget,
        t.ValueMismatch
    FROM compare.Run AS r
    INNER JOIN compare.RunTable AS t
        ON t.RunId = r.RunId
    ORDER BY r.StartedAt DESC, t.TableName;
*/
GO
