/*
    SQL Server data comparison framework
    ------------------------------------
    Public procedures:
        dbo.CompareTables
        dbo.FindDuplicates
        dbo.CompareTableCounts

    Supporting objects:
        dbo.SplitCsv
        dbo.Compare_TypeFamily
        dbo.Compare_TypesAreCompatible
        dbo.Compare_ResolveTable

    Requirements: SQL Server 2016 SP1 or later
    (CREATE OR ALTER, HASHBYTES over varbinary(max), DROP TABLE IF EXISTS).

    Deploy by running this script in a utility database. The procedures compare
    tables in other databases through three-part names; they do not need to live
    in DWH or DWH2.

    Example:
        EXEC dbo.CompareTables
            @SourceDatabase = N'DWH',
            @TargetDatabase = N'DWH2',
            @SchemaName     = N'dbo',
            @TableName      = N'CUSTOMER',
            @KeyColumns     = N'CUSTOMER_ID';
*/

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION dbo.SplitCsv (@Csv nvarchar(max))
RETURNS @Items TABLE (
    Ordinal int NOT NULL,
    Item nvarchar(4000) NOT NULL
)
AS
BEGIN
    IF @Csv IS NULL
        RETURN;

    DECLARE @Work nvarchar(max) = REPLACE(REPLACE(REPLACE(@Csv, CHAR(13), N''), CHAR(10), N''), CHAR(9), N'');
    DECLARE @Pos int;
    DECLARE @Ordinal int = 0;
    DECLARE @Item nvarchar(4000);

    WHILE @Work IS NOT NULL AND LEN(@Work) > 0
    BEGIN
        SET @Pos = CHARINDEX(N',', @Work);

        IF @Pos = 0
        BEGIN
            SET @Item = LTRIM(RTRIM(@Work));
            SET @Work = N'';
        END
        ELSE
        BEGIN
            SET @Item = LTRIM(RTRIM(SUBSTRING(@Work, 1, @Pos - 1)));
            /* Large length avoids LEN() dropping trailing spaces. */
            SET @Work = SUBSTRING(@Work, @Pos + 1, 400000);
        END;

        IF LEFT(@Item, 1) = N'[' AND RIGHT(@Item, 1) = N']' AND LEN(@Item) >= 2
            SET @Item = REPLACE(SUBSTRING(@Item, 2, LEN(@Item) - 2), N']]', N']');

        SET @Ordinal += 1;
        INSERT INTO @Items (Ordinal, Item)
        VALUES (@Ordinal, @Item);
    END;

    RETURN;
END;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION dbo.Compare_TypeFamily (@BaseType sysname)
RETURNS varchar(30)
WITH SCHEMABINDING
AS
BEGIN
    RETURN CASE
        WHEN @BaseType IN (N'tinyint', N'smallint', N'int', N'bigint') THEN 'integer'
        WHEN @BaseType IN (N'decimal', N'numeric') THEN 'decimal'
        WHEN @BaseType IN (N'money', N'smallmoney') THEN 'money'
        WHEN @BaseType IN (N'char', N'varchar', N'nchar', N'nvarchar', N'text', N'ntext') THEN 'string'
        WHEN @BaseType IN (
            N'bit', N'float', N'real', N'date', N'time', N'datetime', N'smalldatetime',
            N'datetime2', N'datetimeoffset', N'uniqueidentifier', N'binary', N'varbinary',
            N'image', N'timestamp', N'xml'
        ) THEN CONVERT(varchar(30), @BaseType)
        ELSE NULL
    END;
END;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER FUNCTION dbo.Compare_TypesAreCompatible (
    @Family varchar(30),
    @BaseType sysname,
    @MaxLength int,
    @Scale int,
    @OtherFamily varchar(30),
    @OtherBaseType sysname,
    @OtherMaxLength int,
    @OtherScale int
)
RETURNS bit
WITH SCHEMABINDING
AS
BEGIN
    IF @Family IS NULL OR @OtherFamily IS NULL OR @Family <> @OtherFamily
        RETURN 0;

    /* Same value, different storage width or character type. */
    IF @Family IN ('integer', 'decimal', 'money', 'string')
        RETURN 1;

    IF @BaseType IN (N'datetime2', N'time', N'datetimeoffset')
       AND ISNULL(@Scale, -1) <> ISNULL(@OtherScale, -1)
        RETURN 0;

    IF @BaseType IN (N'binary', N'varbinary')
       AND ISNULL(@MaxLength, -2) <> ISNULL(@OtherMaxLength, -2)
        RETURN 0;

    RETURN 1;
END;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.Compare_ResolveTable
    @Side sysname,
    @DatabaseName sysname,
    @SchemaName sysname,
    @TableName sysname,
    @ResolvedDatabase sysname OUTPUT,
    @ResolvedSchema sysname OUTPUT,
    @ResolvedTable sysname OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Message nvarchar(2048);
    DECLARE @Sql nvarchar(max);

    SET @ResolvedDatabase = NULL;
    SET @ResolvedSchema = NULL;
    SET @ResolvedTable = NULL;
    SET @Side = ISNULL(NULLIF(LTRIM(RTRIM(@Side)), N''), N'Referenced');
    SET @DatabaseName = LTRIM(RTRIM(@DatabaseName));
    SET @SchemaName = LTRIM(RTRIM(@SchemaName));
    SET @TableName = LTRIM(RTRIM(@TableName));

    IF @DatabaseName IS NULL OR @DatabaseName = N''
    BEGIN
        SET @Message = @Side + N' database is required.';
        THROW 50001, @Message, 1;
    END;

    IF @SchemaName IS NULL OR @SchemaName = N''
    BEGIN
        SET @Message = @Side + N' schema is required.';
        THROW 50001, @Message, 1;
    END;

    IF @TableName IS NULL OR @TableName = N''
    BEGIN
        SET @Message = @Side + N' table is required.';
        THROW 50001, @Message, 1;
    END;

    SELECT @ResolvedDatabase = name
    FROM sys.databases
    WHERE name = @DatabaseName;

    IF @ResolvedDatabase IS NULL
    BEGIN
        SET @Message = @Side + N' database ''' + REPLACE(@DatabaseName, N'''', N'''''') + N''' does not exist.';
        THROW 50001, @Message, 1;
    END;

    SET @Sql = N'
        SELECT @SchemaOut = s.name
        FROM ' + QUOTENAME(@ResolvedDatabase) + N'.sys.schemas AS s
        WHERE s.name = @SchemaName;';

    EXEC sys.sp_executesql
        @Sql,
        N'@SchemaName sysname, @SchemaOut sysname OUTPUT',
        @SchemaName = @SchemaName,
        @SchemaOut = @ResolvedSchema OUTPUT;

    IF @ResolvedSchema IS NULL
    BEGIN
        SET @Message = @Side + N' schema ''' + REPLACE(@SchemaName, N'''', N'''''')
            + N''' does not exist in database ''' + REPLACE(@ResolvedDatabase, N'''', N'''''') + N'''.';
        THROW 50001, @Message, 1;
    END;

    SET @Sql = N'
        SELECT @TableOut = t.name
        FROM ' + QUOTENAME(@ResolvedDatabase) + N'.sys.tables AS t
        INNER JOIN ' + QUOTENAME(@ResolvedDatabase) + N'.sys.schemas AS s
            ON s.schema_id = t.schema_id
        WHERE s.name = @SchemaName
          AND t.name = @TableName;';

    EXEC sys.sp_executesql
        @Sql,
        N'@SchemaName sysname, @TableName sysname, @TableOut sysname OUTPUT',
        @SchemaName = @SchemaName,
        @TableName = @TableName,
        @TableOut = @ResolvedTable OUTPUT;

    IF @ResolvedTable IS NULL
    BEGIN
        SET @Message = @Side + N' table ''' + REPLACE(@TableName, N'''', N'''''')
            + N''' does not exist in schema ''' + REPLACE(@ResolvedSchema, N'''', N'''''')
            + N''' of database ''' + REPLACE(@ResolvedDatabase, N'''', N'''''') + N'''.';
        THROW 50001, @Message, 1;
    END;
END;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.CompareTableCounts
    @SourceDatabase sysname,
    @TargetDatabase sysname,
    @SchemaName sysname = N'dbo',
    @TableName sysname
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SourceDb sysname;
    DECLARE @SourceSchema sysname;
    DECLARE @SourceTable sysname;
    DECLARE @TargetDb sysname;
    DECLARE @TargetSchema sysname;
    DECLARE @TargetTable sysname;
    DECLARE @Sql nvarchar(max);

    EXEC dbo.Compare_ResolveTable
        @Side = N'Source',
        @DatabaseName = @SourceDatabase,
        @SchemaName = @SchemaName,
        @TableName = @TableName,
        @ResolvedDatabase = @SourceDb OUTPUT,
        @ResolvedSchema = @SourceSchema OUTPUT,
        @ResolvedTable = @SourceTable OUTPUT;

    EXEC dbo.Compare_ResolveTable
        @Side = N'Target',
        @DatabaseName = @TargetDatabase,
        @SchemaName = @SchemaName,
        @TableName = @TableName,
        @ResolvedDatabase = @TargetDb OUTPUT,
        @ResolvedSchema = @TargetSchema OUTPUT,
        @ResolvedTable = @TargetTable OUTPUT;

    SET @Sql = N'
        DECLARE @SourceRowCount bigint;
        DECLARE @TargetRowCount bigint;

        SELECT @SourceRowCount = COUNT_BIG(*)
        FROM ' + QUOTENAME(@SourceDb) + N'.' + QUOTENAME(@SourceSchema) + N'.' + QUOTENAME(@SourceTable) + N';

        SELECT @TargetRowCount = COUNT_BIG(*)
        FROM ' + QUOTENAME(@TargetDb) + N'.' + QUOTENAME(@TargetSchema) + N'.' + QUOTENAME(@TargetTable) + N';

        SELECT
            @TableName AS [Table],
            @SourceRowCount AS SourceRowCount,
            @TargetRowCount AS TargetRowCount,
            @SourceRowCount - @TargetRowCount AS CountDifference;';

    EXEC sys.sp_executesql
        @Sql,
        N'@TableName sysname',
        @TableName = @SourceTable;
END;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.FindDuplicates
    @DatabaseName sysname,
    @SchemaName sysname = N'dbo',
    @TableName sysname,
    @KeyColumns nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ResolvedDb sysname;
    DECLARE @ResolvedSchema sysname;
    DECLARE @ResolvedTable sysname;
    DECLARE @Message nvarchar(2048);
    DECLARE @Sql nvarchar(max);
    DECLARE @Object nvarchar(500);
    DECLARE @GroupBy nvarchar(max) = N'';
    DECLARE @KeyDisplay nvarchar(max) = N'';
    DECLARE @Ordinal int;
    DECLARE @Item nvarchar(4000);
    DECLARE @ResolvedName sysname;
    DECLARE @BaseType sysname;
    DECLARE @Family varchar(30);

    IF @KeyColumns IS NULL OR LTRIM(RTRIM(@KeyColumns)) = N''
        THROW 50001, N'At least one key column is required.', 1;

    EXEC dbo.Compare_ResolveTable
        @Side = N'Referenced',
        @DatabaseName = @DatabaseName,
        @SchemaName = @SchemaName,
        @TableName = @TableName,
        @ResolvedDatabase = @ResolvedDb OUTPUT,
        @ResolvedSchema = @ResolvedSchema OUTPUT,
        @ResolvedTable = @ResolvedTable OUTPUT;

    CREATE TABLE #Columns (
        ColumnName sysname NOT NULL,
        BaseType sysname NOT NULL
    );

    SET @Sql = N'
        INSERT INTO #Columns (ColumnName, BaseType)
        SELECT c.name, bt.name
        FROM ' + QUOTENAME(@ResolvedDb) + N'.sys.columns AS c
        INNER JOIN ' + QUOTENAME(@ResolvedDb) + N'.sys.tables AS t
            ON t.object_id = c.object_id
        INNER JOIN ' + QUOTENAME(@ResolvedDb) + N'.sys.schemas AS s
            ON s.schema_id = t.schema_id
        INNER JOIN ' + QUOTENAME(@ResolvedDb) + N'.sys.types AS bt
            ON bt.system_type_id = c.system_type_id
           AND bt.user_type_id = bt.system_type_id
        WHERE s.name = @SchemaName
          AND t.name = @TableName;';

    EXEC sys.sp_executesql
        @Sql,
        N'@SchemaName sysname, @TableName sysname',
        @SchemaName = @ResolvedSchema,
        @TableName = @ResolvedTable;

    DECLARE @Keys TABLE (
        Ordinal int NOT NULL,
        Item nvarchar(4000) NOT NULL,
        ResolvedName sysname NULL,
        BaseType sysname NULL
    );

    INSERT INTO @Keys (Ordinal, Item)
    SELECT Ordinal, Item
    FROM dbo.SplitCsv(@KeyColumns);

    IF EXISTS (SELECT 1 FROM @Keys WHERE Item = N'')
        THROW 50001, N'Key column list contains an empty name.', 1;

    IF EXISTS (SELECT Item FROM @Keys GROUP BY Item HAVING COUNT(*) > 1)
        THROW 50001, N'A key column was specified more than once.', 1;

    IF NOT EXISTS (SELECT 1 FROM @Keys)
        THROW 50001, N'At least one key column is required.', 1;

    UPDATE k
    SET ResolvedName = c.ColumnName,
        BaseType = c.BaseType
    FROM @Keys AS k
    INNER JOIN #Columns AS c
        ON c.ColumnName = k.Item;

    IF EXISTS (SELECT 1 FROM @Keys WHERE ResolvedName IS NULL)
    BEGIN
        SELECT @Item = MIN(Item)
        FROM @Keys
        WHERE ResolvedName IS NULL;

        SET @Message = N'Key column ''' + REPLACE(@Item, N'''', N'''''') + N''' does not exist in '
            + QUOTENAME(@ResolvedDb) + N'.' + QUOTENAME(@ResolvedSchema) + N'.' + QUOTENAME(@ResolvedTable) + N'.';
        THROW 50001, @Message, 1;
    END;

    DECLARE key_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT Ordinal, ResolvedName, BaseType
        FROM @Keys
        ORDER BY Ordinal;

    OPEN key_cursor;
    FETCH NEXT FROM key_cursor INTO @Ordinal, @ResolvedName, @BaseType;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Family = dbo.Compare_TypeFamily(@BaseType);

        IF @Family IS NULL OR @BaseType IN (N'text', N'ntext', N'image', N'xml')
        BEGIN
            SET @Message = N'Key column ''' + REPLACE(@ResolvedName, N'''', N'''''')
                + N''' uses type ' + @BaseType + N', which cannot be used as a business key.';
            THROW 50001, @Message, 1;
        END;

        IF @GroupBy <> N''
        BEGIN
            SET @GroupBy += N', ';
            SET @KeyDisplay += N' + N'' | '' + ';
        END;

        SET @GroupBy += QUOTENAME(@ResolvedName);
        SET @KeyDisplay += N'ISNULL(CONVERT(nvarchar(max), ' + QUOTENAME(@ResolvedName) + N'), N''<NULL>'')';

        FETCH NEXT FROM key_cursor INTO @Ordinal, @ResolvedName, @BaseType;
    END;

    CLOSE key_cursor;
    DEALLOCATE key_cursor;

    SET @Object = QUOTENAME(@ResolvedDb) + N'.' + QUOTENAME(@ResolvedSchema) + N'.' + QUOTENAME(@ResolvedTable);

    SET @Sql = N'
        SELECT
            @TableName AS [Table],
            ' + @KeyDisplay + N' AS [Key],
            COUNT_BIG(*) AS RecordCount
        FROM ' + @Object + N'
        GROUP BY ' + @GroupBy + N'
        HAVING COUNT_BIG(*) > 1
        ORDER BY [Key];';

    EXEC sys.sp_executesql
        @Sql,
        N'@TableName sysname',
        @TableName = @ResolvedTable;
END;
GO

SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE dbo.CompareTables
    @SourceDatabase sysname,
    @TargetDatabase sysname,
    @SchemaName sysname = N'dbo',
    @TableName sysname,
    @KeyColumns nvarchar(max),
    @ExcludedColumns nvarchar(max) = NULL,
    @IncludeMatches bit = 1,
    @Output varchar(20) = 'ALL',
    @Debug bit = 0
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @SourceDb sysname;
    DECLARE @SourceSchema sysname;
    DECLARE @SourceTable sysname;
    DECLARE @TargetDb sysname;
    DECLARE @TargetSchema sysname;
    DECLARE @TargetTable sysname;
    DECLARE @SourceObject nvarchar(776);
    DECLARE @TargetObject nvarchar(776);
    DECLARE @Message nvarchar(max);
    DECLARE @Sql nvarchar(max);
    DECLARE @LoadSql nvarchar(max);
    DECLARE @Norm nvarchar(max);
    DECLARE @ColumnName sysname;
    DECLARE @BaseType sysname;
    DECLARE @Family varchar(30);
    DECLARE @KeyOrdinal int;
    DECLARE @IsKey bit;
    DECLARE @IsCompare bit;
    DECLARE @Q nvarchar(258);
    DECLARE @Ref nvarchar(300);
    DECLARE @Inner nvarchar(max);
    DECLARE @Canon nvarchar(max);
    DECLARE @Display nvarchar(max);
    DECLARE @HashArg nvarchar(max);
    DECLARE @Fingerprint nvarchar(max);
    DECLARE @KeyNumber varchar(10);
    DECLARE @SourceKeySelect nvarchar(max) = N'';
    DECLARE @TargetKeySelect nvarchar(max) = N'';
    DECLARE @GroupBy nvarchar(max) = N'';
    DECLARE @NullSafeJoin nvarchar(max) = N'';
    DECLARE @NullSafeDelete nvarchar(max) = N'';
    DECLARE @MismatchJoin nvarchar(max) = N'';
    DECLARE @SrcDisplay nvarchar(max) = N'';
    DECLARE @TgtDisplay nvarchar(max) = N'';
    DECLARE @DupDisplay nvarchar(max) = N'';
    DECLARE @KeyFingerprints nvarchar(max) = N'';
    DECLARE @RowFingerprints nvarchar(max) = N'';
    DECLARE @DiffApply nvarchar(max) = N'';
    DECLARE @KeyHashExpr nvarchar(max);
    DECLARE @RowHashExpr nvarchar(max);
    DECLARE @Plan nvarchar(max);
    DECLARE @Offset int;
    DECLARE @Total int;

    SET @IncludeMatches = ISNULL(@IncludeMatches, 1);
    SET @Debug = ISNULL(@Debug, 0);
    SET @Output = UPPER(LTRIM(RTRIM(ISNULL(@Output, 'ALL'))));
    SET @SchemaName = LTRIM(RTRIM(ISNULL(@SchemaName, N'dbo')));

    IF @Output NOT IN ('ALL', 'DETAIL', 'DUPLICATES', 'SUMMARY')
        THROW 50001, N'@Output must be ALL, DETAIL, DUPLICATES, or SUMMARY.', 1;

    IF @IncludeMatches NOT IN (0, 1)
        THROW 50001, N'@IncludeMatches must be 0 or 1.', 1;

    IF @KeyColumns IS NULL OR LTRIM(RTRIM(@KeyColumns)) = N''
        THROW 50001, N'At least one key column is required.', 1;

    EXEC dbo.Compare_ResolveTable
        @Side = N'Source',
        @DatabaseName = @SourceDatabase,
        @SchemaName = @SchemaName,
        @TableName = @TableName,
        @ResolvedDatabase = @SourceDb OUTPUT,
        @ResolvedSchema = @SourceSchema OUTPUT,
        @ResolvedTable = @SourceTable OUTPUT;

    EXEC dbo.Compare_ResolveTable
        @Side = N'Target',
        @DatabaseName = @TargetDatabase,
        @SchemaName = @SchemaName,
        @TableName = @TableName,
        @ResolvedDatabase = @TargetDb OUTPUT,
        @ResolvedSchema = @TargetSchema OUTPUT,
        @ResolvedTable = @TargetTable OUTPUT;

    SET @SourceObject = QUOTENAME(@SourceDb) + N'.' + QUOTENAME(@SourceSchema) + N'.' + QUOTENAME(@SourceTable);
    SET @TargetObject = QUOTENAME(@TargetDb) + N'.' + QUOTENAME(@TargetSchema) + N'.' + QUOTENAME(@TargetTable);

    CREATE TABLE #SourceCols (
        ColumnName sysname NOT NULL,
        BaseType sysname NOT NULL,
        MaxLength int NOT NULL,
        [Precision] int NOT NULL,
        Scale int NOT NULL,
        TypeDescription nvarchar(200) NOT NULL,
        Family varchar(30) NULL
    );

    CREATE TABLE #TargetCols (
        ColumnName sysname NOT NULL,
        BaseType sysname NOT NULL,
        MaxLength int NOT NULL,
        [Precision] int NOT NULL,
        Scale int NOT NULL,
        TypeDescription nvarchar(200) NOT NULL,
        Family varchar(30) NULL
    );

    SET @LoadSql = N'
        INSERT INTO #COLS# (ColumnName, BaseType, MaxLength, [Precision], Scale, TypeDescription)
        SELECT
            c.name,
            bt.name,
            c.max_length,
            c.[precision],
            c.scale,
            bt.name + CASE
                WHEN bt.name IN (N''decimal'', N''numeric'')
                    THEN N''('' + CONVERT(nvarchar(10), c.[precision]) + N'','' + CONVERT(nvarchar(10), c.scale) + N'')''
                WHEN bt.name IN (N''varchar'', N''char'', N''varbinary'', N''binary'')
                    THEN N''('' + CASE WHEN c.max_length = -1 THEN N''max'' ELSE CONVERT(nvarchar(10), c.max_length) END + N'')''
                WHEN bt.name IN (N''nvarchar'', N''nchar'')
                    THEN N''('' + CASE WHEN c.max_length = -1 THEN N''max'' ELSE CONVERT(nvarchar(10), c.max_length / 2) END + N'')''
                WHEN bt.name IN (N''datetime2'', N''datetimeoffset'', N''time'')
                    THEN N''('' + CONVERT(nvarchar(10), c.scale) + N'')''
                ELSE N''''
            END
        FROM #DB#.sys.columns AS c
        INNER JOIN #DB#.sys.tables AS t
            ON t.object_id = c.object_id
        INNER JOIN #DB#.sys.schemas AS s
            ON s.schema_id = t.schema_id
        INNER JOIN #DB#.sys.types AS bt
            ON bt.system_type_id = c.system_type_id
           AND bt.user_type_id = bt.system_type_id
        WHERE s.name = @SchemaName
          AND t.name = @TableName;';

    SET @Sql = REPLACE(REPLACE(@LoadSql, N'#COLS#', N'#SourceCols'), N'#DB#', QUOTENAME(@SourceDb));
    EXEC sys.sp_executesql
        @Sql,
        N'@SchemaName sysname, @TableName sysname',
        @SchemaName = @SourceSchema,
        @TableName = @SourceTable;

    SET @Sql = REPLACE(REPLACE(@LoadSql, N'#COLS#', N'#TargetCols'), N'#DB#', QUOTENAME(@TargetDb));
    EXEC sys.sp_executesql
        @Sql,
        N'@SchemaName sysname, @TableName sysname',
        @SchemaName = @TargetSchema,
        @TableName = @TargetTable;

    IF NOT EXISTS (SELECT 1 FROM #SourceCols)
        THROW 50001, N'No columns are visible on the source table. SELECT permission is required.', 1;

    IF NOT EXISTS (SELECT 1 FROM #TargetCols)
        THROW 50001, N'No columns are visible on the target table. SELECT permission is required.', 1;

    UPDATE #SourceCols SET Family = dbo.Compare_TypeFamily(BaseType);
    UPDATE #TargetCols SET Family = dbo.Compare_TypeFamily(BaseType);

    CREATE TABLE #Keys (
        Ordinal int NOT NULL,
        Item nvarchar(4000) NOT NULL,
        ResolvedName sysname NULL
    );

    CREATE TABLE #Excluded (
        Ordinal int NOT NULL,
        Item nvarchar(4000) NOT NULL,
        ResolvedName sysname NULL
    );

    INSERT INTO #Keys (Ordinal, Item)
    SELECT Ordinal, Item
    FROM dbo.SplitCsv(@KeyColumns);

    INSERT INTO #Excluded (Ordinal, Item)
    SELECT Ordinal, Item
    FROM dbo.SplitCsv(@ExcludedColumns);

    IF EXISTS (SELECT 1 FROM #Keys WHERE Item = N'')
        THROW 50001, N'Key column list contains an empty name.', 1;

    IF EXISTS (SELECT 1 FROM #Excluded WHERE Item = N'')
        THROW 50001, N'Excluded column list contains an empty name.', 1;

    IF NOT EXISTS (SELECT 1 FROM #Keys)
        THROW 50001, N'At least one key column is required.', 1;

    IF (SELECT COUNT(*) FROM #Keys) > 32
        THROW 50001, N'At most 32 key columns are supported.', 1;

    IF EXISTS (SELECT Item FROM #Keys GROUP BY Item HAVING COUNT(*) > 1)
        THROW 50001, N'A key column was specified more than once.', 1;

    IF EXISTS (SELECT Item FROM #Excluded GROUP BY Item HAVING COUNT(*) > 1)
        THROW 50001, N'An excluded column was specified more than once.', 1;

    UPDATE k
    SET ResolvedName = c.ColumnName
    FROM #Keys AS k
    INNER JOIN #SourceCols AS c
        ON c.ColumnName = k.Item;

    UPDATE e
    SET ResolvedName = COALESCE(s.ColumnName, t.ColumnName)
    FROM #Excluded AS e
    LEFT JOIN #SourceCols AS s
        ON s.ColumnName = e.Item
    LEFT JOIN #TargetCols AS t
        ON t.ColumnName = e.Item;

    CREATE TABLE #Issues (
        Issue nvarchar(2000) NOT NULL
    );

    INSERT INTO #Issues (Issue)
    SELECT N'Key column ''' + REPLACE(Item, N'''', N'''''') + N''' does not exist in the source table.'
    FROM #Keys
    WHERE ResolvedName IS NULL;

    INSERT INTO #Issues (Issue)
    SELECT N'Key column ''' + REPLACE(k.ResolvedName, N'''', N'''''') + N''' does not exist in the target table.'
    FROM #Keys AS k
    WHERE k.ResolvedName IS NOT NULL
      AND NOT EXISTS (
          SELECT 1
          FROM #TargetCols AS t
          WHERE t.ColumnName = k.ResolvedName
      );

    INSERT INTO #Issues (Issue)
    SELECT N'Excluded column ''' + REPLACE(Item, N'''', N'''''') + N''' does not exist in either table.'
    FROM #Excluded
    WHERE ResolvedName IS NULL;

    INSERT INTO #Issues (Issue)
    SELECT N'Key column ''' + REPLACE(k.ResolvedName, N'''', N'''''') + N''' cannot be excluded.'
    FROM #Keys AS k
    INNER JOIN #Excluded AS e
        ON e.ResolvedName = k.ResolvedName;

    INSERT INTO #Issues (Issue)
    SELECT N'Key column ''' + REPLACE(k.ResolvedName, N'''', N'''''') + N''' uses type '
        + s.BaseType + N', which cannot be used as a business key.'
    FROM #Keys AS k
    INNER JOIN #SourceCols AS s
        ON s.ColumnName = k.ResolvedName
    WHERE s.Family IS NULL
       OR s.BaseType IN (N'text', N'ntext', N'image', N'xml');

    INSERT INTO #Issues (Issue)
    SELECT N'Key column ''' + REPLACE(k.ResolvedName, N'''', N'''''')
        + N''' is not compatible. Source type: ' + s.TypeDescription
        + N'. Target type: ' + t.TypeDescription + N'.'
    FROM #Keys AS k
    INNER JOIN #SourceCols AS s
        ON s.ColumnName = k.ResolvedName
    INNER JOIN #TargetCols AS t
        ON t.ColumnName = k.ResolvedName
    WHERE s.Family IS NOT NULL
      AND s.BaseType NOT IN (N'text', N'ntext', N'image', N'xml')
      AND dbo.Compare_TypesAreCompatible(
            s.Family, s.BaseType, s.MaxLength, s.Scale,
            t.Family, t.BaseType, t.MaxLength, t.Scale
          ) = 0;

    /* Common non-key columns that were not excluded must be comparable. */
    INSERT INTO #Issues (Issue)
    SELECT N'Column ''' + REPLACE(s.ColumnName, N'''', N'''''') + N''' uses unsupported type '
        + s.TypeDescription + N'. Exclude it with @ExcludedColumns.'
    FROM #SourceCols AS s
    INNER JOIN #TargetCols AS t
        ON t.ColumnName = s.ColumnName
    WHERE s.Family IS NULL
      AND NOT EXISTS (SELECT 1 FROM #Keys AS k WHERE k.ResolvedName = s.ColumnName)
      AND NOT EXISTS (SELECT 1 FROM #Excluded AS e WHERE e.ResolvedName = s.ColumnName);

    INSERT INTO #Issues (Issue)
    SELECT N'Column ''' + REPLACE(s.ColumnName, N'''', N'''''')
        + N''' is not compatible. Source type: ' + s.TypeDescription
        + N'. Target type: ' + t.TypeDescription
        + N'. Align the types or exclude the column.'
    FROM #SourceCols AS s
    INNER JOIN #TargetCols AS t
        ON t.ColumnName = s.ColumnName
    WHERE s.Family IS NOT NULL
      AND t.Family IS NOT NULL
      AND dbo.Compare_TypesAreCompatible(
            s.Family, s.BaseType, s.MaxLength, s.Scale,
            t.Family, t.BaseType, t.MaxLength, t.Scale
          ) = 0
      AND NOT EXISTS (SELECT 1 FROM #Keys AS k WHERE k.ResolvedName = s.ColumnName)
      AND NOT EXISTS (SELECT 1 FROM #Excluded AS e WHERE e.ResolvedName = s.ColumnName);

    IF EXISTS (SELECT 1 FROM #Issues)
    BEGIN
        SELECT @Message = STUFF((
            SELECT N' ' + Issue
            FROM #Issues
            ORDER BY Issue
            FOR XML PATH(''), TYPE
        ).value(N'.', N'nvarchar(max)'), 1, 1, N'');

        IF LEN(@Message) > 2048
            SET @Message = LEFT(@Message, 2045) + N'...';

        THROW 50001, @Message, 1;
    END;

    CREATE TABLE #Common (
        ColumnName sysname NOT NULL,
        BaseType sysname NOT NULL,
        Family varchar(30) NOT NULL,
        IsKey bit NOT NULL,
        KeyOrdinal int NULL,
        IsCompare bit NOT NULL
    );

    INSERT INTO #Common (ColumnName, BaseType, Family, IsKey, KeyOrdinal, IsCompare)
    SELECT
        s.ColumnName,
        s.BaseType,
        s.Family,
        CASE WHEN k.ResolvedName IS NOT NULL THEN 1 ELSE 0 END,
        k.Ordinal,
        CASE
            WHEN k.ResolvedName IS NULL AND e.ResolvedName IS NULL THEN 1
            ELSE 0
        END
    FROM #SourceCols AS s
    INNER JOIN #TargetCols AS t
        ON t.ColumnName = s.ColumnName
    LEFT JOIN #Keys AS k
        ON k.ResolvedName = s.ColumnName
    LEFT JOIN #Excluded AS e
        ON e.ResolvedName = s.ColumnName
    WHERE s.Family IS NOT NULL;

    /*
        Strip trailing fractional zeros without touching zeros that are part of the
        number. 10.50 and 10.5000 both become 10.5; 101.00 stays distinct from 110.00.
    */
    SET @Norm = N'CASE WHEN CHARINDEX(N''.'', {raw}) = 0 THEN {raw} ELSE CASE WHEN RIGHT(LEFT({raw}, LEN({raw}) - PATINDEX(N''%[^0]%'', REVERSE({raw})) + 1), 1) = N''.'' THEN LEFT(LEFT({raw}, LEN({raw}) - PATINDEX(N''%[^0]%'', REVERSE({raw})) + 1), LEN(LEFT({raw}, LEN({raw}) - PATINDEX(N''%[^0]%'', REVERSE({raw})) + 1)) - 1) ELSE LEFT({raw}, LEN({raw}) - PATINDEX(N''%[^0]%'', REVERSE({raw})) + 1) END END';

    DECLARE column_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT ColumnName, BaseType, Family, KeyOrdinal, IsKey, IsCompare
        FROM #Common
        WHERE IsKey = 1 OR IsCompare = 1
        ORDER BY IsKey DESC, ISNULL(KeyOrdinal, 0), ColumnName;

    OPEN column_cursor;
    FETCH NEXT FROM column_cursor INTO @ColumnName, @BaseType, @Family, @KeyOrdinal, @IsKey, @IsCompare;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Q = QUOTENAME(@ColumnName);
        SET @Ref = N'#A#.' + @Q;
        SET @Canon = NULL;
        SET @Inner = NULL;

        IF @BaseType IN (N'binary', N'varbinary', N'image', N'timestamp')
        BEGIN
            SET @HashArg = N'CONVERT(varbinary(max), ' + @Ref + N')';
            SET @Display = N'CASE WHEN ' + @Ref + N' IS NULL THEN CAST(NULL AS nvarchar(max)) WHEN DATALENGTH('
                + @Ref + N') <= 64 THEN CONVERT(nvarchar(max), ' + @Ref
                + N', 1) ELSE CONVERT(nvarchar(200), SUBSTRING(' + @Ref
                + N', 1, 64), 1) + N''... ('' + CONVERT(nvarchar(20), DATALENGTH(' + @Ref
                + N')) + N'' bytes)'' END';
        END
        ELSE
        BEGIN
            SET @Inner = CASE
                WHEN @Family = 'integer' OR @BaseType = N'bit'
                    THEN N'CONVERT(nvarchar(30), ' + @Ref + N')'
                WHEN @Family = 'decimal'
                    THEN N'CONVERT(nvarchar(100), ' + @Ref + N')'
                WHEN @BaseType = N'money'
                    THEN N'CONVERT(nvarchar(100), CONVERT(decimal(19,4), ' + @Ref + N'))'
                WHEN @BaseType = N'smallmoney'
                    THEN N'CONVERT(nvarchar(100), CONVERT(decimal(10,4), ' + @Ref + N'))'
                WHEN @BaseType IN (N'float', N'real')
                    THEN N'CONVERT(nvarchar(50), ' + @Ref + N', 3)'
                WHEN @BaseType = N'date'
                    THEN N'CONVERT(nvarchar(10), ' + @Ref + N', 23)'
                WHEN @BaseType = N'time'
                    THEN N'CONVERT(nvarchar(20), ' + @Ref + N', 121)'
                WHEN @BaseType IN (N'datetime', N'smalldatetime', N'datetime2')
                    THEN N'CONVERT(nvarchar(40), ' + @Ref + N', 121)'
                WHEN @BaseType = N'datetimeoffset'
                    THEN N'CONVERT(nvarchar(40), ' + @Ref + N', 127)'
                WHEN @BaseType = N'uniqueidentifier'
                    THEN N'CONVERT(nvarchar(36), ' + @Ref + N')'
                ELSE N'CONVERT(nvarchar(max), ' + @Ref + N')'
            END;

            IF @Family IN ('decimal', 'money')
                SET @Canon = REPLACE(@Norm, N'{raw}', @Inner);
            ELSE
                SET @Canon = @Inner;

            SET @HashArg = N'CONVERT(varbinary(max), ' + @Canon + N')';
            SET @Display = N'CONVERT(nvarchar(max), ' + @Inner + N')';
        END;

        SET @Fingerprint = N'CONVERT(varbinary(max), CASE WHEN ' + @Ref
            + N' IS NULL THEN CONVERT(binary(33), 0x00) ELSE CONVERT(binary(33), 0x01 + HASHBYTES(''SHA2_256'', '
            + @HashArg + N')) END)';

        IF @IsKey = 1
        BEGIN
            SET @KeyNumber = CONVERT(varchar(10), @KeyOrdinal);

            IF @SourceKeySelect <> N''
            BEGIN
                SET @SourceKeySelect += N',' + NCHAR(10) + N'        ';
                SET @TargetKeySelect += N',' + NCHAR(10) + N'        ';
                SET @GroupBy += N', ';
                SET @NullSafeJoin += N' AND ';
                SET @NullSafeDelete += N' AND ';
                SET @MismatchJoin += N' AND ';
                SET @SrcDisplay += N' + N'' | '' + ';
                SET @TgtDisplay += N' + N'' | '' + ';
                SET @DupDisplay += N' + N'' | '' + ';
                SET @KeyFingerprints += N' + ';
            END;

            SET @SourceKeySelect += N's.' + @Q + N' AS K' + @KeyNumber;
            SET @TargetKeySelect += N't.' + @Q + N' AS K' + @KeyNumber;
            SET @GroupBy += N'K' + @KeyNumber;
            SET @NullSafeJoin += N'(s.K' + @KeyNumber + N' = t.K' + @KeyNumber
                + N' OR (s.K' + @KeyNumber + N' IS NULL AND t.K' + @KeyNumber + N' IS NULL))';
            SET @NullSafeDelete += N'(s.K' + @KeyNumber + N' = d.K' + @KeyNumber
                + N' OR (s.K' + @KeyNumber + N' IS NULL AND d.K' + @KeyNumber + N' IS NULL))';
            SET @MismatchJoin += N'(c.K' + @KeyNumber + N' = #ROW#.' + @Q
                + N' OR (c.K' + @KeyNumber + N' IS NULL AND #ROW#.' + @Q + N' IS NULL))';
            SET @SrcDisplay += N'ISNULL(CONVERT(nvarchar(max), s.K' + @KeyNumber + N'), N''<NULL>'')';
            SET @TgtDisplay += N'ISNULL(CONVERT(nvarchar(max), t.K' + @KeyNumber + N'), N''<NULL>'')';
            SET @DupDisplay += N'ISNULL(CONVERT(nvarchar(max), d.K' + @KeyNumber + N'), N''<NULL>'')';
            SET @KeyFingerprints += @Fingerprint;
        END
        ELSE
        BEGIN
            IF @RowFingerprints <> N''
                SET @RowFingerprints += N' + ';

            SET @RowFingerprints += @Fingerprint;

            IF @DiffApply <> N''
                SET @DiffApply += NCHAR(10) + N'            UNION ALL' + NCHAR(10);

            SET @DiffApply += N'            SELECT CONVERT(nvarchar(128), N'''
                + REPLACE(@ColumnName, N'''', N'''''') + N''') AS ColumnName, '
                + REPLACE(@Display, N'#A#', N'src') + N' AS SourceValue, '
                + REPLACE(@Display, N'#A#', N'tgt') + N' AS TargetValue, ';

            IF @BaseType IN (N'binary', N'varbinary', N'image', N'timestamp')
            BEGIN
                SET @DiffApply += N'CASE WHEN src.' + @Q + N' IS NULL AND tgt.' + @Q
                    + N' IS NULL THEN 0 WHEN src.' + @Q + N' IS NULL OR tgt.' + @Q
                    + N' IS NULL THEN 1 WHEN src.' + @Q + N' = tgt.' + @Q
                    + N' THEN 0 ELSE 1 END AS IsDiff';
            END
            ELSE
            BEGIN
                SET @DiffApply += N'CASE WHEN src.' + @Q + N' IS NULL AND tgt.' + @Q
                    + N' IS NULL THEN 0 WHEN src.' + @Q + N' IS NULL OR tgt.' + @Q
                    + N' IS NULL THEN 1 WHEN '
                    + REPLACE(@Canon, N'#A#', N'src') + N' = ' + REPLACE(@Canon, N'#A#', N'tgt')
                    + N' AND DATALENGTH(' + REPLACE(@Canon, N'#A#', N'src') + N') = DATALENGTH('
                    + REPLACE(@Canon, N'#A#', N'tgt') + N') THEN 0 ELSE 1 END AS IsDiff';
            END;
        END;

        FETCH NEXT FROM column_cursor INTO @ColumnName, @BaseType, @Family, @KeyOrdinal, @IsKey, @IsCompare;
    END;

    CLOSE column_cursor;
    DEALLOCATE column_cursor;

    /* binary(32) keeps the join key indexable. HASHBYTES over varbinary(max) is otherwise typed as varbinary(8000). */
    SET @KeyHashExpr = N'CONVERT(binary(32), HASHBYTES(''SHA2_256'', ' + @KeyFingerprints + N'))';

    IF @RowFingerprints = N''
        SET @RowHashExpr = N'CONVERT(binary(32), HASHBYTES(''SHA2_256'', 0x))';
    ELSE
        SET @RowHashExpr = N'CONVERT(binary(32), HASHBYTES(''SHA2_256'', ' + @RowFingerprints + N'))';

    SELECT @Plan = N'CompareTables: ' + @SourceObject + N' -> ' + @TargetObject
        + N'. Keys: ' + ISNULL(STUFF((
            SELECT N', ' + ColumnName
            FROM #Common
            WHERE IsKey = 1
            ORDER BY KeyOrdinal
            FOR XML PATH(''), TYPE
        ).value(N'.', N'nvarchar(max)'), 1, 2, N''), N'(none)')
        + N'. Comparing: ' + ISNULL(NULLIF(STUFF((
            SELECT N', ' + ColumnName
            FROM #Common
            WHERE IsCompare = 1
            ORDER BY ColumnName
            FOR XML PATH(''), TYPE
        ).value(N'.', N'nvarchar(max)'), 1, 2, N''), N''), N'(key only)')
        + CASE
            WHEN EXISTS (SELECT 1 FROM #Excluded WHERE ResolvedName IS NOT NULL)
                THEN N'. Excluded: ' + STUFF((
                    SELECT N', ' + ResolvedName
                    FROM #Excluded
                    WHERE ResolvedName IS NOT NULL
                    ORDER BY ResolvedName
                    FOR XML PATH(''), TYPE
                ).value(N'.', N'nvarchar(max)'), 1, 2, N'')
            ELSE N''
          END;

    PRINT @Plan;

    IF EXISTS (
        SELECT 1
        FROM #SourceCols AS s
        WHERE NOT EXISTS (SELECT 1 FROM #TargetCols AS t WHERE t.ColumnName = s.ColumnName)
    )
    BEGIN
        SET @Message = N'Source-only columns were not compared: ' + STUFF((
            SELECT N', ' + s.ColumnName
            FROM #SourceCols AS s
            WHERE NOT EXISTS (SELECT 1 FROM #TargetCols AS t WHERE t.ColumnName = s.ColumnName)
            ORDER BY s.ColumnName
            FOR XML PATH(''), TYPE
        ).value(N'.', N'nvarchar(max)'), 1, 2, N'');
        PRINT @Message;
    END;

    IF EXISTS (
        SELECT 1
        FROM #TargetCols AS t
        WHERE NOT EXISTS (SELECT 1 FROM #SourceCols AS s WHERE s.ColumnName = t.ColumnName)
    )
    BEGIN
        SET @Message = N'Target-only columns were not compared: ' + STUFF((
            SELECT N', ' + t.ColumnName
            FROM #TargetCols AS t
            WHERE NOT EXISTS (SELECT 1 FROM #SourceCols AS s WHERE s.ColumnName = t.ColumnName)
            ORDER BY t.ColumnName
            FOR XML PATH(''), TYPE
        ).value(N'.', N'nvarchar(max)'), 1, 2, N'');
        PRINT @Message;
    END;

    SET @Sql = N'
SET NOCOUNT ON;

SELECT
        ' + @SourceKeySelect + N',
        ' + REPLACE(@KeyHashExpr, N'#A#', N's') + N' AS KeyHash,
        ' + REPLACE(@RowHashExpr, N'#A#', N's') + N' AS RowHash,
        CAST(1 AS bit) AS HasRow
INTO #SourceHash
FROM ' + @SourceObject + N' AS s;

SELECT
        ' + @TargetKeySelect + N',
        ' + REPLACE(@KeyHashExpr, N'#A#', N't') + N' AS KeyHash,
        ' + REPLACE(@RowHashExpr, N'#A#', N't') + N' AS RowHash,
        CAST(1 AS bit) AS HasRow
INTO #TargetHash
FROM ' + @TargetObject + N' AS t;

DECLARE @SourceRowCount bigint;
DECLARE @TargetRowCount bigint;
SELECT @SourceRowCount = COUNT_BIG(*) FROM #SourceHash;
SELECT @TargetRowCount = COUNT_BIG(*) FROM #TargetHash;

SELECT ' + @GroupBy + N', COUNT_BIG(*) AS RecordCount
INTO #DupSource
FROM #SourceHash
GROUP BY ' + @GroupBy + N'
HAVING COUNT_BIG(*) > 1;

SELECT ' + @GroupBy + N', COUNT_BIG(*) AS RecordCount
INTO #DupTarget
FROM #TargetHash
GROUP BY ' + @GroupBy + N'
HAVING COUNT_BIG(*) > 1;

DELETE s
FROM #SourceHash AS s
INNER JOIN #DupSource AS d
    ON ' + @NullSafeDelete + N';

DELETE t
FROM #TargetHash AS t
INNER JOIN #DupTarget AS d
    ON ' + REPLACE(@NullSafeDelete, N's.', N't.') + N';

CREATE CLUSTERED INDEX IX_SourceHash_KeyHash ON #SourceHash (KeyHash);
CREATE CLUSTERED INDEX IX_TargetHash_KeyHash ON #TargetHash (KeyHash);

SELECT
    CASE WHEN s.HasRow = 1 THEN ' + @SrcDisplay + N' ELSE ' + @TgtDisplay + N' END AS KeyDisplay,
    CASE
        WHEN s.HasRow IS NULL THEN ''ONLY_IN_TARGET''
        WHEN t.HasRow IS NULL THEN ''ONLY_IN_SOURCE''
        WHEN s.RowHash = t.RowHash THEN ''MATCH''
        ELSE ''VALUE_MISMATCH''
    END AS [Status],
    ' + REPLACE(@GroupBy, N'K', N's.K') + N'
INTO #Classified
FROM #SourceHash AS s
FULL OUTER JOIN #TargetHash AS t
    ON s.KeyHash = t.KeyHash
   AND ' + @NullSafeJoin + N';

IF @Output IN (''ALL'', ''DETAIL'')
BEGIN
    SELECT
        [Table],
        [Key],
        [Status],
        [Column],
        SourceValue,
        TargetValue
    FROM (
        SELECT
            @TableName AS [Table],
            c.KeyDisplay AS [Key],
            c.[Status],
            CAST(NULL AS nvarchar(128)) AS [Column],
            CAST(NULL AS nvarchar(max)) AS SourceValue,
            CAST(NULL AS nvarchar(max)) AS TargetValue,
            CASE c.[Status]
                WHEN ''MATCH'' THEN 1
                WHEN ''ONLY_IN_SOURCE'' THEN 2
                WHEN ''ONLY_IN_TARGET'' THEN 3
                ELSE 4
            END AS SortStatus
        FROM #Classified AS c
        WHERE c.[Status] <> ''VALUE_MISMATCH''
          AND (@IncludeMatches = 1 OR c.[Status] <> ''MATCH'')
        ' + CASE
            WHEN @DiffApply = N'' THEN N''
            ELSE N'
        UNION ALL
        SELECT
            @TableName,
            c.KeyDisplay,
            ''VALUE_MISMATCH'',
            v.ColumnName,
            v.SourceValue,
            v.TargetValue,
            4
        FROM #Classified AS c
        INNER JOIN ' + @SourceObject + N' AS src
            ON ' + REPLACE(@MismatchJoin, N'#ROW#', N'src') + N'
        INNER JOIN ' + @TargetObject + N' AS tgt
            ON ' + REPLACE(@MismatchJoin, N'#ROW#', N'tgt') + N'
        CROSS APPLY (
' + @DiffApply + N'
        ) AS v
        WHERE c.[Status] = ''VALUE_MISMATCH''
          AND v.IsDiff = 1'
        END + N'
    ) AS compared
    ORDER BY
        CASE [Status]
            WHEN ''MATCH'' THEN 1
            WHEN ''ONLY_IN_SOURCE'' THEN 2
            WHEN ''ONLY_IN_TARGET'' THEN 3
            ELSE 4
        END,
        [Key],
        [Column];
END;

IF @Output IN (''ALL'', ''DUPLICATES'')
BEGIN
    SELECT
        @TableName AS [Table],
        ' + @DupDisplay + N' AS [Key],
        CONVERT(varchar(32), ''DUPLICATE_SOURCE'') AS [Status],
        d.RecordCount
    FROM #DupSource AS d
    UNION ALL
    SELECT
        @TableName,
        ' + @DupDisplay + N',
        CONVERT(varchar(32), ''DUPLICATE_TARGET''),
        d.RecordCount
    FROM #DupTarget AS d
    ORDER BY [Status], [Key];
END;

IF @Output IN (''ALL'', ''SUMMARY'')
BEGIN
    SELECT
        @TableName AS [Table],
        @SourceRowCount AS SourceRowCount,
        @TargetRowCount AS TargetRowCount,
        @SourceRowCount - @TargetRowCount AS CountDifference,
        ISNULL(SUM(CASE WHEN [Status] = ''MATCH'' THEN CONVERT(bigint, 1) ELSE 0 END), 0) AS MatchingRows,
        ISNULL(SUM(CASE WHEN [Status] = ''ONLY_IN_SOURCE'' THEN CONVERT(bigint, 1) ELSE 0 END), 0) AS OnlyInSource,
        ISNULL(SUM(CASE WHEN [Status] = ''ONLY_IN_TARGET'' THEN CONVERT(bigint, 1) ELSE 0 END), 0) AS OnlyInTarget,
        ISNULL(SUM(CASE WHEN [Status] = ''VALUE_MISMATCH'' THEN CONVERT(bigint, 1) ELSE 0 END), 0) AS ValueMismatch,
        (SELECT COUNT_BIG(*) FROM #DupSource) AS DuplicateSourceKeys,
        (SELECT COUNT_BIG(*) FROM #DupTarget) AS DuplicateTargetKeys
    FROM #Classified;
END;';

    IF @Debug = 1
    BEGIN
        SET @Offset = 1;
        SET @Total = DATALENGTH(@Sql) / 2;
        WHILE @Offset <= @Total
        BEGIN
            PRINT SUBSTRING(@Sql, @Offset, 4000);
            SET @Offset += 4000;
        END;
    END;

    BEGIN TRY
        EXEC sys.sp_executesql
            @Sql,
            N'@IncludeMatches bit, @Output varchar(20), @TableName sysname',
            @IncludeMatches = @IncludeMatches,
            @Output = @Output,
            @TableName = @SourceTable;
    END TRY
    BEGIN CATCH
        IF ERROR_NUMBER() IN (229, 230)
        BEGIN
            SET @Message = N'SELECT permission is required on both tables. ' + ERROR_MESSAGE();
            IF LEN(@Message) > 2048
                SET @Message = LEFT(@Message, 2045) + N'...';
            THROW 50001, @Message, 1;
        END;

        THROW;
    END CATCH;
END;
GO
