/*
    Example calls
    -------------
    These are the supported entry points. They run only when both DWH and DWH2
    are on this instance. sql/test.sql is the executable demonstration and does
    not require those databases.

    SourceValue is the value from @SourceDatabase (DWH in the calls below).
    TargetValue is the value from @TargetDatabase (DWH2).
*/

IF DB_ID(N'DWH') IS NOT NULL AND DB_ID(N'DWH2') IS NOT NULL
BEGIN
    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'POLICY_LIMIT',
        @KeyColumns = N'POLICY_BK,LIMIT_BK';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @ExcludedColumns = N'CREATED_DATE,UPDATED_DATE';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @Output = N'DIFF';

    EXEC dbo.CompareTables
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID',
        @IgnoreCase = 1;

    EXEC dbo.CompareTableCounts
        @SourceDatabase = N'DWH',
        @TargetDatabase = N'DWH2',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER';

    EXEC dbo.FindDuplicates
        @DatabaseName = N'DWH',
        @SchemaName = N'dbo',
        @TableName = N'CUSTOMER',
        @KeyColumns = N'CUSTOMER_ID';

    IF EXISTS (
        SELECT 1
        FROM sys.servers AS s
        WHERE s.name = N'DWH2_LINK'
          AND s.is_data_access_enabled = 1
          AND (
              s.product = N'SQL Server'
              OR s.provider LIKE N'MSOLEDBSQL%'
              OR s.provider LIKE N'SQLNCLI%'
              OR s.provider = N'SQLOLEDB'
          )
    )
        EXEC dbo.CompareTables
            @SourceDatabase = N'DWH',
            @TargetDatabase = N'DWH',
            @SchemaName = N'dbo',
            @TableName = N'CUSTOMER',
            @KeyColumns = N'CUSTOMER_ID',
            @TargetServer = N'DWH2_LINK';
END
ELSE
    PRINT 'DWH and DWH2 are not on this instance. Use the calls in this file as templates, or run sql/test.sql.';
GO
