/*
    Drops the databases created by sql/test.sql.
    Does not drop the utility database that holds the procedures.
*/

IF DB_ID(N'DwhCompare_Src') IS NOT NULL
BEGIN
    ALTER DATABASE DwhCompare_Src SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE DwhCompare_Src;
END;
GO

IF DB_ID(N'DwhCompare_Tgt') IS NOT NULL
BEGIN
    ALTER DATABASE DwhCompare_Tgt SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE DwhCompare_Tgt;
END;
GO
